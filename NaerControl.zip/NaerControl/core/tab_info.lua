local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña "Información": consulta y muestra, formateada dentro del addon,
-- la ficha de un personaje (.player info), sus CDs de raid (.raid list, por
-- objetivo) y la info de una banda por número (.raid info). Las respuestas
-- del servidor se ocultan del chat y se pintan aquí.
------------------------------------------------------------

local panel, searchBox, cardScroll, cardContent
local raidIdBox
local ui = {}   -- referencias a los FontStrings de la ficha
local recentList = {}   -- historial de consultas: SOLO de esta sesión (no se guarda)
local removeRecent      -- forward-declare (se usa en BuildPanel; se define abajo)
local BuildCard, BuildRaidInfoSection   -- forward declaration

-- Colores de clase (aproximados, WotLK)
local CLASS_COLOR = {
    ["Guerrero"]   = "C79C6E", ["Paladín"] = "F58CBA", ["Cazador"] = "ABD473",
    ["Pícaro"]     = "FFF569", ["Sacerdote"] = "FFFFFF", ["Caballero de la Muerte"] = "C41F3B",
    ["Chamán"]     = "0070DE", ["Mago"] = "69CCF0", ["Brujo"] = "9482C9", ["Druida"] = "FF7D0A",
}

local function classColor(cls)
    return (cls and CLASS_COLOR[cls]) or "FFD100"
end

-- Color del GearScore por tramos (gradiente por millares). Ajustable.
local function gsColor(gs)
    local n = tonumber(gs and string.match(tostring(gs), "%d+"))
    if not n then return "ffd100" end
    if n < 1500 then return "9d9d9d"      -- ~1000: gris
    elseif n < 2500 then return "1eff00"  -- ~2000: verde
    elseif n < 3500 then return "3366ff"  -- ~3000: azul marino
    elseif n < 4500 then return "a335ee"  -- ~4000: morado
    elseif n < 5500 then return "ff8000"  -- ~5000: naranja
    else return "ff2020" end               -- ~6000+: rojo
end

------------------------------------------------------------
-- Construcción del panel
------------------------------------------------------------
local function BuildPanel()
    if panel then return end
    panel = CreateFrame("Frame", nil, NC.Content)
    panel:SetAllPoints(NC.Content)

    -- Cabecera: título
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 6, -6)
    title:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "Información|r")

    -- Caja de búsqueda de personaje
    local lbl = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("TOPLEFT", 8, -34)
    lbl:SetText("Personaje:")
    lbl:SetTextColor(0.7, 0.72, 0.78)

    searchBox = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    searchBox:SetSize(160, 20)
    searchBox:SetPoint("LEFT", lbl, "RIGHT", 10, 0)
    searchBox:SetAutoFocus(false)
    searchBox:SetScript("OnEnterPressed", function(self)
        NC.Info:QueryPlayer(strtrim(self:GetText() or ""))
        self:ClearFocus()
    end)

    local btnGo = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnGo:SetSize(80, 22)
    btnGo:SetPoint("LEFT", searchBox, "RIGHT", 8, 0)
    btnGo:SetText("Consultar")
    btnGo:SetScript("OnClick", function()
        NC.Info:QueryPlayer(strtrim(searchBox:GetText() or ""))
        searchBox:ClearFocus()
    end)

    -- Botón "Consultar objetivo": consulta la ficha COMPLETA del jugador que
    -- tengas seleccionado (ficha + CDs), sin teclear el nombre.
    local cdBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    cdBtn:SetSize(160, 22)
    cdBtn:SetPoint("LEFT", btnGo, "RIGHT", 16, 0)
    cdBtn:SetText("Consultar objetivo")
    cdBtn:SetScript("OnClick", function()
        if not (UnitExists("target") and UnitIsPlayer("target")) then
            if NC.SetStatus then NC.SetStatus("Selecciona a un jugador como objetivo.", true) end
            return
        end
        local tname = UnitName("target")
        if searchBox then searchBox:SetText(tname) end
        NC.Info:QueryPlayer(tname)
    end)
    cdBtn:SetScript("OnUpdate", function(self, elapsed)
        self._acc = (self._acc or 0) + (elapsed or 0)
        if self._acc < 0.25 then return end
        self._acc = 0
        if UnitExists("target") and UnitIsPlayer("target") then
            NC.SetButtonEnabled(self, true)
        else
            NC.SetButtonEnabled(self, false)
        end
    end)
    ui.cdBtnTop = cdBtn

    -- Botón "Recientes": menú con las últimas consultas (re-consulta rápida)
    local recentBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    recentBtn:SetSize(90, 22)
    recentBtn:SetPoint("LEFT", cdBtn, "RIGHT", 8, 0)
    recentBtn:SetText("Recientes")
    recentBtn:SetScript("OnClick", function(self)
        local list = recentList
        if #list == 0 then
            if NC.SetStatus then NC.SetStatus("Sin consultas recientes todavía.", true) end
            return
        end
        local menu = { { text = "Consultas recientes", isTitle = true, notCheckable = true } }
        for _, nm in ipairs(list) do
            local name = nm
            local function doQuery()
                if searchBox then searchBox:SetText(name) end
                NC.Info:QueryPlayer(name)
            end
            local function doShow()
                if searchBox then searchBox:SetText(name) end
                -- muestra la info guardada de la sesión sin reenviar comandos;
                -- si no hay nada cacheado, entonces sí consulta.
                if not (NC.Info.ShowCached and NC.Info:ShowCached(name)) then
                    doQuery()
                end
            end
            table.insert(menu, {
                text = name, notCheckable = true, func = doShow, hasArrow = true,
                menuList = {
                    { text = "Ver", notCheckable = true, func = doShow },
                    { text = "Susurrar", notCheckable = true, func = function()
                        if ChatFrame_SendTell then ChatFrame_SendTell(name, DEFAULT_CHAT_FRAME) end
                    end },
                    { text = "Invitar", notCheckable = true, func = function()
                        if InviteUnit then InviteUnit(name) end
                    end },
                    { text = "|cffff4040X|r  Borrar de recientes", notCheckable = true,
                      func = function()
                          removeRecent(name)
                          -- reabrir el menú al instante con la lista actualizada
                          local btn = ui.recentBtn
                          if btn then
                              local fr = NC._recentReopen or CreateFrame("Frame")
                              NC._recentReopen = fr
                              fr._t = 0
                              fr:SetScript("OnUpdate", function(self, e)
                                  self._t = self._t + (e or 0)
                                  if self._t < 0.05 then return end
                                  self:SetScript("OnUpdate", nil)
                                  if #recentList > 0 then
                                      local oc = btn:GetScript("OnClick")
                                      if oc then oc(btn) end
                                  elseif CloseDropDownMenus then
                                      CloseDropDownMenus()
                                  end
                              end)
                          end
                      end },
                },
            })
        end
        table.insert(menu, { text = "", isTitle = true, notCheckable = true })
        table.insert(menu, {
            text = "|cffff8080Borrar todo el historial|r", notCheckable = true,
            func = function()
                for i = #recentList, 1, -1 do recentList[i] = nil end
                if NC.Info.ForgetCached then NC.Info:ForgetCached(nil) end  -- limpia toda la cache
                if NC.Info.ClearInfo then NC.Info:ClearInfo() end            -- vacia las tablas
                if NC.SetStatus then NC.SetStatus("Historial de consultas vaciado.") end
            end,
        })
        if not NC._recentMenu then
            NC._recentMenu = CreateFrame("Frame", "NaerControlRecentMenu", UIParent, "UIDropDownMenuTemplate")
        end
        EasyMenu(menu, NC._recentMenu, self, 0, 0, "MENU")

        -- cerrar el menú al hacer clic fuera (sin consumir el clic)
        if not NC._recentWatcher then
            local wf = CreateFrame("Frame")
            wf:Hide()
            wf:SetScript("OnUpdate", function(self2)
                local l1 = _G["DropDownList1"]
                if not (l1 and l1:IsShown()) then self2:Hide(); return end
                local down = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
                if down and not self2._wasDown then
                    local l2 = _G["DropDownList2"]
                    local over = MouseIsOver(l1) or (l2 and l2:IsShown() and MouseIsOver(l2))
                    if not over then
                        if CloseDropDownMenus then CloseDropDownMenus() end
                        self2:Hide()
                    end
                end
                self2._wasDown = down
            end)
            NC._recentWatcher = wf
        end
        NC._recentWatcher._wasDown = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
        NC._recentWatcher:Show()
    end)
    recentBtn:SetScript("OnUpdate", function(self, elapsed)
        self._acc = (self._acc or 0) + (elapsed or 0)
        if self._acc < 0.3 then return end
        self._acc = 0
        NC.SetButtonEnabled(self, table.getn(recentList) > 0)
    end)
    ui.recentBtn = recentBtn

    -- Fila 2: buscador de "Info de banda" por ID (entrada arriba; el resultado
    -- sigue en el scroll, en su propio frame reservado).
    local rlbl = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    rlbl:SetPoint("TOPLEFT", 8, -60)
    rlbl:SetText("Banda (ID):")
    rlbl:SetTextColor(0.7, 0.72, 0.78)

    raidIdBox = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    raidIdBox:SetSize(80, 20)
    raidIdBox:SetPoint("LEFT", rlbl, "RIGHT", 10, 0)
    raidIdBox:SetAutoFocus(false)
    raidIdBox:SetNumeric(true)
    raidIdBox:SetScript("OnEnterPressed", function(self)
        NC.Info:QueryRaidInfo(strtrim(self:GetText() or "")); self:ClearFocus()
    end)
    local rb = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    rb:SetSize(90, 22); rb:SetPoint("LEFT", raidIdBox, "RIGHT", 8, 0)
    rb:SetText("Consultar")
    rb:SetScript("OnClick", function()
        NC.Info:QueryRaidInfo(strtrim(raidIdBox:GetText() or "")); raidIdBox:ClearFocus()
    end)

    -- Zona con scroll para la ficha y resultados
    cardScroll, cardContent = NC.CreateScroll(panel)
    cardScroll:SetPoint("TOPLEFT", 4, -90)
    cardScroll:SetPoint("BOTTOMRIGHT", -26, 8)
    cardContent:SetWidth(560)

    BuildCard()
    BuildRaidInfoSection()
end

-- Tarjeta de ficha del personaje (oculta hasta que haya datos)
BuildCard = function()
    local c = CreateFrame("Frame", nil, cardContent)
    c:SetPoint("TOPLEFT", 0, 0)
    c:SetPoint("TOPRIGHT", 0, 0)
    c:SetHeight(230)
    c:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
    })
    c:SetBackdropColor(0.10, 0.12, 0.16, 0.9)
    c:SetBackdropBorderColor(0.25, 0.30, 0.40, 0.8)
    c:Hide()
    ui.card = c

    -- Nombre grande (coloreado por clase)
    ui.name = c:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    ui.name:SetPoint("TOPLEFT", 14, -12)

    -- Botones de acción sobre el jugador consultado (arriba a la derecha)
    ui.btnInvite = CreateFrame("Button", nil, c, "UIPanelButtonTemplate")
    ui.btnInvite:SetSize(76, 20)
    ui.btnInvite:SetPoint("TOPRIGHT", -8, -10)
    ui.btnInvite:SetText("Invitar")
    ui.btnInvite:SetScript("OnClick", function()
        if ui._curName and ui._curName ~= "" and InviteUnit then InviteUnit(ui._curName) end
    end)
    ui.btnWhisper = CreateFrame("Button", nil, c, "UIPanelButtonTemplate")
    ui.btnWhisper:SetSize(80, 20)
    ui.btnWhisper:SetPoint("RIGHT", ui.btnInvite, "LEFT", -6, 0)
    ui.btnWhisper:SetText("Susurrar")
    ui.btnWhisper:SetScript("OnClick", function()
        if ui._curName and ui._curName ~= "" and ChatFrame_SendTell then
            ChatFrame_SendTell(ui._curName, DEFAULT_CHAT_FRAME)
        end
    end)

    -- Hermandad
    ui.guild = c:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.guild:SetPoint("TOPLEFT", 14, -34)
    ui.guild:SetTextColor(0.7, 0.72, 0.78)

    -- Raza/clase
    ui.classrace = c:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    ui.classrace:SetPoint("TOPLEFT", 14, -52)

    -- Separador
    local sep = c:CreateTexture(nil, "ARTWORK")
    sep:SetTexture("Interface\\Buttons\\WHITE8X8")
    sep:SetVertexColor(0.3, 0.35, 0.45, 0.5)
    sep:SetPoint("TOPLEFT", 14, -74); sep:SetPoint("TOPRIGHT", -14, -74)
    sep:SetHeight(1)

    -- Columna PvE (izquierda)
    ui.pveTitle = c:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.pveTitle:SetPoint("TOPLEFT", 14, -84)
    ui.pveTitle:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "PvE|r")
    ui.pve = c:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.pve:SetPoint("TOPLEFT", 14, -102)
    ui.pve:SetWidth(250); ui.pve:SetJustifyH("LEFT")
    ui.pve:SetSpacing(4)
    ui.pve:SetTextColor(0.85, 0.87, 0.92)

    -- Columna PvP (derecha)
    ui.pvpTitle = c:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.pvpTitle:SetPoint("TOPLEFT", 290, -84)
    ui.pvpTitle:SetText("|cffff8080PvP|r")
    ui.pvp = c:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.pvp:SetPoint("TOPLEFT", 290, -102)
    ui.pvp:SetWidth(250); ui.pvp:SetJustifyH("LEFT")
    ui.pvp:SetSpacing(4)
    ui.pvp:SetTextColor(0.85, 0.87, 0.92)

    -- (El botón "Ver CDs de raids" ahora está en la cabecera, es independiente
    -- del personaje inspeccionado y actúa sobre el objetivo.)

    -- Zona de CDs (bajo la ficha)
    local cds = CreateFrame("Frame", nil, cardContent)
    cds:SetPoint("TOPLEFT", c, "BOTTOMLEFT", 0, -8)
    cds:SetPoint("TOPRIGHT", c, "BOTTOMRIGHT", 0, -8)
    cds:SetHeight(120)
    cds:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
    })
    cds:SetBackdropColor(0.10, 0.12, 0.16, 0.9)
    cds:SetBackdropBorderColor(0.25, 0.30, 0.40, 0.8)
    cds:Hide()
    ui.cds = cds
    ui.cdsTitle = cds:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.cdsTitle:SetPoint("TOPLEFT", 14, -10)
    ui.cdsTitle:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "Bloqueos de banda|r")
    ui.cdsText = cds:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.cdsText:SetPoint("TOPLEFT", 14, -30)
    ui.cdsText:SetWidth(520); ui.cdsText:SetJustifyH("LEFT")
    ui.cdsText:SetSpacing(4)
    ui.cdsText:SetTextColor(0.85, 0.87, 0.92)
end

-- Sección de resultado de "Info de banda" (la entrada está en la cabecera).
-- Mantiene su propio frame reservado, debajo de los bloqueos.
BuildRaidInfoSection = function()
    local f = CreateFrame("Frame", nil, cardContent)
    f:SetPoint("TOPLEFT", ui.cds, "BOTTOMLEFT", 0, -12)
    f:SetPoint("TOPRIGHT", ui.cds, "BOTTOMRIGHT", 0, -12)
    f:SetHeight(128)
    ui.raidBox = f

    local rtitle = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    rtitle:SetPoint("TOPLEFT", 0, 0)
    rtitle:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "Composición de banda|r")

    local card = CreateFrame("Frame", nil, f)
    card:SetPoint("TOPLEFT", 0, -18); card:SetPoint("TOPRIGHT", 0, -18)
    card:SetHeight(105)
    card:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
    })
    card:SetBackdropColor(0.10, 0.12, 0.16, 0.9)
    card:SetBackdropBorderColor(0.25, 0.30, 0.40, 0.8)
    card:Hide()
    ui.riCard = card
    ui.riText = card:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.riText:SetPoint("TOPLEFT", 14, -10)
    ui.riText:SetWidth(520); ui.riText:SetJustifyH("LEFT")
    ui.riText:SetSpacing(4)
    ui.riText:SetTextColor(0.85, 0.87, 0.92)
end

------------------------------------------------------------
-- Pintado de la ficha con los datos parseados
------------------------------------------------------------
-- Muestra/oculta los botones Susurrar/Invitar y fija sobre quién actúan.
local function setActions(name)
    ui._curName = name
    local show = name and name ~= ""
    if ui.btnWhisper then if show then ui.btnWhisper:Show() else ui.btnWhisper:Hide() end end
    if ui.btnInvite  then if show then ui.btnInvite:Show()  else ui.btnInvite:Hide()  end end
end

-- Historial de últimas consultas SOLO de la sesión (no persiste). Añade un
-- nombre al frente, sin duplicados, con tope de 25.
local function pushRecent(name)
    if not name or name == "" then return end
    for i = #recentList, 1, -1 do
        if strlower(recentList[i]) == strlower(name) then table.remove(recentList, i) end
    end
    table.insert(recentList, 1, name)
    while #recentList > 25 do table.remove(recentList) end
end

-- Quita un nombre concreto del historial de la sesión.
removeRecent = function(name)
    if not name then return end
    for i = #recentList, 1, -1 do
        if strlower(recentList[i]) == strlower(name) then table.remove(recentList, i) end
    end
    if NC.Info.ForgetCached then NC.Info:ForgetCached(name) end
    -- si la ficha mostrada es la de este jugador, vaciar las tablas
    local shown = NC.Info.player and (NC.Info.player.name or NC.Info._queriedName)
    if shown and strlower(shown) == strlower(name) and NC.Info.ClearInfo then
        NC.Info:ClearInfo()
    end
    if NC.SetStatus then NC.SetStatus("Quitado de recientes: " .. name) end
end

local function RefreshCard()
    local p = NC.Info.player
    if NC._infoDiag and NC.Console and NC.Console.LogInfo then
        NC.Console:LogInfo("[diag] RefreshCard: p=" .. tostring(p ~= nil)
            .. " card=" .. tostring(ui.card ~= nil)
            .. " name=" .. tostring(p and p.name))
    end
    if not p then ui.card:Hide(); return end
    ui.card:Show()
    -- por defecto mostramos los títulos de columna; el passthrough los oculta
    if ui.pveTitle then ui.pveTitle:Show() end
    if ui.pvpTitle then ui.pvpTitle:Show() end

    -- respuesta vacía: jugador offline o sin datos
    if p.empty then
        ui.name:SetText("|cffff8080Sin respuesta|r")
        ui.guild:SetText("")
        local quien = p.queried and ("\"" .. p.queried .. "\" ") or "El jugador "
        ui.classrace:SetText("|cff888888" .. quien .. "no está conectado o no existe.|r")
        ui.pve:SetText("")
        ui.pvp:SetText("")
        setActions(nil)
        return
    end

    -- Passthrough: si el parseo por campos no dio nombre pero llegó el bloque
    -- crudo del servidor, lo mostramos tal cual. Inmune a NBSP/cambios de
    -- etiqueta: enseña lo que llega sin interpretarlo.
    if not p.name and p.raw then
        ui.name:SetText("|cffffd100" .. (p.queried or "Jugador") .. "|r")
        ui.guild:SetText("|cff33ff99(datos del servidor)|r")
        ui.classrace:SetText("|cffffffff" .. p.raw .. "|r")
        ui.pve:SetText("")
        ui.pvp:SetText("")
        -- ocultamos los títulos de columna para que el texto crudo no se solape
        if ui.pveTitle then ui.pveTitle:Hide() end
        if ui.pvpTitle then ui.pvpTitle:Hide() end
        setActions(p.queried)
        pushRecent(p.queried)
        return
    end

    local col = classColor(p.class)
    ui.name:SetText("|cff" .. col .. (p.name or "?") .. "|r")
    ui.guild:SetText(p.guild and ("<" .. p.guild .. ">") or "")
    ui.classrace:SetText((p.race or "") .. "  |cff" .. col .. (p.class or "") .. "|r")

    -- PvE
    local pve = {}
    if p.gs then table.insert(pve, "|cff888888GearScore:|r  |cff" .. gsColor(p.gs) .. p.gs .. "|r") end
    if p.ilvl then table.insert(pve, "|cff888888iLvl equipado:|r  |cffffffff" .. p.ilvl .. "|r") end
    if p.talents then table.insert(pve, "|cff888888Talentos:|r  |cffffffff" .. p.talents .. "|r") end
    if p.role then table.insert(pve, "|cff888888Rol:|r  |cff9fd98f" .. p.role .. "|r") end
    if p.pveRating then table.insert(pve, "|cff888888PvE Rating:|r  |cffffffff" .. p.pveRating .. "|r") end
    ui.pve:SetText(table.concat(pve, "\n"))

    -- PvP
    local pvp = {}
    for _, a in ipairs(p.arenas or {}) do
        local hasTeam = a.team and a.team ~= "" and not string.find(strlower(a.team), "sin equipo")
        if hasTeam then
            pvp[#pvp+1] = "|cffffd100" .. a.bracket .. "|r " .. a.team
            pvp[#pvp+1] = "   |cff888888Rating:|r " .. (a.pr or "?") .. "  |cff888888MMR:|r " .. (a.mmr or "?")
        else
            pvp[#pvp+1] = "|cff888888" .. a.bracket .. ":|r sin equipo"
        end
    end
    if p.bgRating then pvp[#pvp+1] = "|cff888888BG puntuado:|r " .. p.bgRating end
    if #pvp == 0 then pvp[1] = "|cff707070Sin datos de PvP|r" end
    ui.pvp:SetText(table.concat(pvp, "\n"))

    setActions(p.name)
    pushRecent(p.name)
end

local function RefreshCDs()
    local rl = NC.Info.raidList
    if not rl then
        if ui.cds then ui.cds:Hide() end
        return
    end
    ui.cds:Show()
    local quien = rl.player and rl.player ~= "" and (" de |cffffffff" .. rl.player .. "|r") or ""
    if not rl.locks or #rl.locks == 0 then
        -- consulta resuelta pero sin bloqueos: damos feedback en vez de ocultar
        ui.cdsText:SetText("|cff888888Sin bloqueos de banda/mazmorra" .. quien .. ".|r")
        return
    end
    -- Por defecto solo BANDAS (10/25/40); las mazmorras (5) se ocultan salvo que
    -- se active en Ajustes.
    local showDun = (NC.db and NC.db.showDungeonLocks == true) or false
    local lines = {}
    local hidden = 0
    for _, k in ipairs(rl.locks) do
        local isRaid = (NC.IsRaidLock == nil) or NC.IsRaidLock(k.diff)
        if isRaid or showDun then
            local estado = k.active and " |cff4fdf4f[activo]|r" or ""
            local mapes = (NC.LocalizeInstance and NC.LocalizeInstance(k.map or "?")) or (k.map or "?")
            table.insert(lines, "|cffffffff" .. mapes .. "|r  |cffffd100" .. (k.diff or "") .. "|r" .. estado)
        else
            hidden = hidden + 1
        end
    end
    if #lines == 0 then
        local extra = (hidden > 0)
            and (" |cff888888(" .. hidden .. " mazmorra" .. (hidden == 1 and "" or "s")
                 .. " oculta" .. (hidden == 1 and "" or "s") .. " \226\128\148 Ajustes)|r") or ""
        ui.cdsText:SetText("|cff888888Sin bloqueos de banda" .. quien .. ".|r" .. extra)
        return
    end
    if hidden > 0 then
        lines[#lines + 1] = "|cff707070+ " .. hidden .. " mazmorra" .. (hidden == 1 and "" or "s")
            .. " oculta" .. (hidden == 1 and "" or "s") .. " (Ajustes)|r"
    end
    ui.cdsText:SetText(table.concat(lines, "\n"))
end

local function RefreshRaidInfo()
    local ri = NC.Info.raidInfo
    if not ri or not ri.raidId then
        if ui.riCard then ui.riCard:Hide() end
        return
    end
    ui.riCard:Show()
    local lines = {}
    local mapes = (NC.LocalizeInstance and NC.LocalizeInstance(ri.map or "?")) or (ri.map or "?")
    table.insert(lines, "|cffffffff" .. mapes .. "|r  |cffffd100" .. (ri.diff or "") .. "|r   |cff888888(ID " .. ri.raidId .. ")|r")
    if ri.encounters then table.insert(lines, "|cff888888Encuentros:|r " .. ri.encounters) end
    if ri.leader then table.insert(lines, "|cff888888Líder:|r " .. ri.leader) end
    if ri.players then table.insert(lines, "|cff888888Jugadores:|r " .. ri.players) end
    if ri.roles then table.insert(lines, "|cff888888Roles:|r " .. ri.roles) end
    if ri.gs then table.insert(lines, "|cff888888GS medio:|r |cffffd100" .. ri.gs .. "|r   |cff888888iLvl:|r " .. (ri.ilvl or "?")) end
    ui.riText:SetText(table.concat(lines, "\n"))
end

local function RefreshAll()
    if NC._infoDiag and NC.Console and NC.Console.LogInfo then
        NC.Console:LogInfo("[diag] RefreshAll: panel=" .. tostring(panel ~= nil)
            .. " player=" .. tostring(NC.Info.player ~= nil)
            .. " name=" .. tostring(NC.Info.player and NC.Info.player.name))
    end
    if not panel then return end
    RefreshCard()
    RefreshCDs()
    RefreshRaidInfo()
end

-- callback desde el módulo de datos
NC.Info.OnChanged = RefreshAll

------------------------------------------------------------
-- Mostrar / ocultar la vista
------------------------------------------------------------
function NC.ShowInfoView()
    BuildPanel()
    panel:Show()
    RefreshAll()
end

function NC.HideInfoView()
    if panel then panel:Hide() end
end

-- Rellena el campo de búsqueda de la pestaña Información con 'name' y abre la
-- ventana en esa pestaña. Si doQuery es true, consulta directamente; si no,
-- solo deja el nombre listo en el campo. Lo usa la integración con el chat
-- (shift+click y menú contextual "Información").
function NC.SetInfoSearch(name, doQuery)
    if not name or name == "" then return end
    -- quita posibles adornos del enlace (reino, etc.): nos quedamos con el nombre
    name = string.match(name, "^[^-]+") or name
    if NC.OpenInfoTab then NC.OpenInfoTab() end   -- abre la ventana en la pestaña Info
    BuildPanel()                                    -- asegura que existe searchBox
    if searchBox then searchBox:SetText(name) end
    if doQuery then
        NC.Info:QueryPlayer(name)
    elseif searchBox then
        searchBox:SetFocus()
        searchBox:HighlightText()
    end
end
