local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña "Chat": incrusta la interfaz de NaerChat (dos columnas) dentro
-- del panel de contenido de NaerControl. La ventana es grande y fija, así
-- que las dos columnas caben sin scroll. Los botones de acción van en una
-- barra inferior propia, a tamaño normal.
------------------------------------------------------------

local chatPanel      -- el panel con los filtros
local actionBar      -- barra inferior con los botones

function NC.ShowChatView()
    local Chat = NC.Chat
    if not Chat or not Chat.BuildUI then
        NC.Content:Hide()
        return
    end

    if not chatPanel then
        chatPanel = Chat.BuildUI(NC.Content)
        Chat.configFrame = chatPanel

        -- barra inferior para los botones de accion del chat
        actionBar = CreateFrame("Frame", nil, NC.Content)
        actionBar:SetPoint("BOTTOMLEFT", 0, -2)
        actionBar:SetPoint("BOTTOMRIGHT", 0, -2)
        actionBar:SetHeight(26)
        if Chat.MakeActionButtons then
            Chat.MakeActionButtons(actionBar)
        end
    end

    if chatPanel then chatPanel:Show() end
    if actionBar then actionBar:Show() end

    -- sincroniza las casillas con la config guardada
    local onShow = chatPanel:GetScript("OnShow")
    if onShow then onShow(chatPanel) end
end

function NC.HideChatView()
    if chatPanel then chatPanel:Hide() end
    if actionBar then actionBar:Hide() end
end

-- Abre la ventana de NaerControl directamente en la pestaña de chat.
function NC.OpenChatTab()
    local idx
    for i, t in ipairs(NC.TABS) do
        if t.render == "chat" then idx = i break end
    end
    if not idx then return end
    if not NC.Frame:IsShown() then NC.Frame:Show() end
    NC.ShowTab(idx)
end
