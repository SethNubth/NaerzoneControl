local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña "Ayuda": secciones navegables (botones arriba) con contenido
-- scrolleable debajo. El contenido está definido como datos (SECTIONS) para
-- poder pulirlo fácilmente más adelante. Cada sección es una lista de bloques:
--   { h = "Título" }            -> encabezado
--   { t = "texto" }             -> párrafo
--   { c = "/comando", d = "descripción" }  -> línea de comando
--   { link = "https://...", d = "etiqueta" } -> enlace (por rellenar)
--   { sp = true }               -> espacio
------------------------------------------------------------

local A = NC.COL and NC.COL.accent or "|cff7ec8e3"
local R = "|r"

local SECTIONS = {
    {
        id = "comandos", label = "Comandos",
        blocks = {
            { h = "Comandos del addon" },
            { t = "Todos empiezan por /naer (también valen /nc y /naercontrol)." },
            { sp = true },
            { h = "General" },
            { c = "/naer",             d = "abre o cierra la ventana" },
            { c = "/naer consola",     d = "abre la consola de comandos" },
            { c = "/naer escala <0.5-1.5|auto>", d = "ajusta el tamaño de la ventana" },
            { c = "/naer flotante",    d = "botón de minimapa en modo flotante (Carbonite)" },
            { c = "/naer icono",       d = "oculta o muestra el botón del minimapa" },
            { sp = true },
            { h = "Experiencia" },
            { c = "/naer rate quest <1-8>", d = "rate de misiones" },
            { c = "/naer rate kill <1-8>",  d = "rate de criaturas" },
            { sp = true },
            { h = "Eventos" },
            { c = "/naer eventos chat", d = "muestra u oculta las respuestas de eventos en el chat" },
            { sp = true },
            { h = "Diagnósticos (avanzado)" },
            { c = "/naer instdiag",     d = "diagnóstico de entradas a mazmorras" },
            { c = "/naer eventdiag",    d = "diagnóstico de respuestas de eventos" },
        },
    },
    {
        id = "servidor", label = "Servidor",
        blocks = {
            { h = "Comandos útiles de NAERZONE" },
            { c = ".event activelist",  d = "lista los eventos activos" },
            { c = ".event info <id>",   d = "detalle de un evento" },
            { c = ".player iteminfo <id>", d = "busca un objeto en tus personajes" },
            { sp = true },
            { h = "Límites y reglas" },
            { t = "Mazmorras: máximo " .. A .. "5 por hora" .. R .. " (de cuenta). Las aleatorias del buscador no cuentan." },
            { t = "Consultas de objeto: " .. A .. "2 cada 5 segundos" .. R .. ". Pasarse silencia el chat unos segundos." },
            { t = "Reinicio de bloqueos: heroicas cada día a las " .. A .. "9:00" .. R .. ", raids los " .. A .. "martes a las 9:00" .. R .. " (hora española)." },
            { t = "Rate de fin de semana: aumenta ligeramente (más cuanto mayor sea el rate elegido)." },
        },
    },
    {
        id = "guia", label = "Guía",
        blocks = {
            { h = "Guía de las pestañas" },
            { t = "(Por rellenar) Aquí irá una explicación breve de cada pestaña: Experiencia, Escáner, Eventos, Mazmorras, Chat…" },
            { sp = true },
            { t = A .. "Mazmorras" .. R .. ": el semáforo pinta cada personaje en verde (disponible), rojo (bloqueado) o gris (sin datos) para la instancia que elijas." },
            { t = A .. "Eventos" .. R .. ": muestra los eventos activos con su fecha de fin. Los datos se guardan para verlos al instante." },
        },
    },
    {
        id = "enlaces", label = "Enlaces",
        blocks = {
            { h = "Enlaces de NAERZONE" },
            { t = "(Por rellenar) Aquí irán los enlaces al Discord, foro y web del servidor." },
            { link = "",  d = "Discord (pendiente)" },
            { link = "",  d = "Foro (pendiente)" },
            { link = "",  d = "Web (pendiente)" },
        },
    },
    {
        id = "acerca", label = "Acerca de",
        blocks = {
            { h = "NaerControl" },
            { t = "Versión " .. A .. (NC.VERSION or "?") .. R },
            { t = "Autor: " .. A .. "Vyr" .. R },
            { sp = true },
            { t = "Suite de utilidades para NaerZone: escáner de botín, comandos, "
                .. "filtro de chat, experiencia, mazmorras y eventos." },
        },
    },
}

local panel, secButtons, scroll, content
local secFrames = {}
local currentSection = "comandos"

local function BuildSectionContent(host, blocks)
    local y = -4
    for _, b in ipairs(blocks) do
        if b.sp then
            y = y - 8
        elseif b.h then
            local fs = host:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
            fs:SetPoint("TOPLEFT", 4, y)
            fs:SetText((NC.COL and NC.COL.accent or "|cff7ec8e3") .. b.h .. "|r")
            y = y - 24
        elseif b.c then
            local cmd = host:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            cmd:SetPoint("TOPLEFT", 8, y)
            cmd:SetText("|cffffd100" .. b.c .. "|r")
            cmd:SetWidth(230); cmd:SetJustifyH("LEFT")
            local desc = host:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            desc:SetPoint("TOPLEFT", 244, y - 1)
            desc:SetWidth(300); desc:SetJustifyH("LEFT")
            desc:SetText("|cffcccccc" .. (b.d or "") .. "|r")
            y = y - 20
        elseif b.link then
            local fs = host:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            fs:SetPoint("TOPLEFT", 8, y)
            if b.link ~= "" then
                fs:SetText("|cff44aaff" .. b.link .. "|r  |cff888888" .. (b.d or "") .. "|r")
            else
                fs:SetText("|cff888888" .. (b.d or "") .. "|r")
            end
            y = y - 20
        elseif b.t then
            local fs = host:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            fs:SetPoint("TOPLEFT", 8, y)
            fs:SetWidth(540); fs:SetJustifyH("LEFT")
            fs:SetText("|cffdddddd" .. b.t .. "|r")
            -- altura aproximada según longitud
            local lines = math.max(1, math.ceil(string.len(b.t) / 75))
            y = y - (14 * lines) - 6
        end
    end
    host:SetHeight(-y + 10)
    return -y + 10
end

local function ShowSection(id)
    currentSection = id
    for sid, f in pairs(secFrames) do
        if sid == id then f:Show() else f:Hide() end
    end
    -- resaltar el botón activo
    for _, b in ipairs(secButtons) do
        if b._id == id then b:LockHighlight() else b:UnlockHighlight() end
    end
    -- ajustar altura del content al de la sección visible
    if secFrames[id] then
        content:SetHeight(secFrames[id]:GetHeight())
    end
end

local function BuildPanel()
    if panel then return end
    panel = CreateFrame("Frame", nil, NC.Content)
    panel:SetAllPoints(NC.Content)

    -- botones de sección (arriba)
    secButtons = {}
    local x = 4
    for _, sec in ipairs(SECTIONS) do
        local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        b:SetSize(96, 22)
        b:SetPoint("TOPLEFT", x, -4)
        b:SetText(sec.label)
        b._id = sec.id
        b:SetScript("OnClick", function(self) ShowSection(self._id) end)
        table.insert(secButtons, b)
        x = x + 100
    end

    -- área scrolleable
    scroll, content = NC.CreateScroll(panel)
    scroll:SetPoint("TOPLEFT", 4, -34)
    scroll:SetPoint("BOTTOMRIGHT", -26, 8)
    content:SetWidth(560)

    -- una sub-frame por sección, dentro del content
    for _, sec in ipairs(SECTIONS) do
        local f = CreateFrame("Frame", nil, content)
        f:SetPoint("TOPLEFT", 0, 0)
        f:SetPoint("TOPRIGHT", 0, 0)
        BuildSectionContent(f, sec.blocks)
        secFrames[sec.id] = f
    end

    ShowSection(currentSection)
end

function NC.ShowHelpView()
    BuildPanel()
    panel:Show()
    ShowSection(currentSection)
end

function NC.HideHelpView()
    if panel then panel:Hide() end
end
