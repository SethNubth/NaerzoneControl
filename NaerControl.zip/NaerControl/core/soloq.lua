local ADDON, NC = ...

------------------------------------------------------------
-- SoloQ (arenas 1c1 que puntúan por el slot de 5c5 en NAERZONE).
-- Lee equipo/personal vía GetArenaTeam(3) y registra partidas (compañeros,
-- rivales y resultado) leyendo el grupo y arena1..arena5 durante la arena.
------------------------------------------------------------

NC.SoloQ = NC.SoloQ or {}
NC.SoloQ.queue = { state = "idle" }

local MAX_DAYS = 30
local MIN_ILVL = 251
local SCORED_SLOTS = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 }

local function DB()
    NaerControlCharDB = NaerControlCharDB or {}
    local d = NaerControlCharDB.soloq or {}
    d.days    = d.days or {}
    d.allies  = d.allies or {}
    d.enemies = d.enemies or {}
    NaerControlCharDB.soloq = d
    return d
end
NC.SoloQ.DB = DB

-- Lectura del slot de 5c5: equipo + personal.
function NC.SoloQ:Read()
    if not GetArenaTeam then return nil end
    local a = { GetArenaTeam(3) }
    if not a[1] then return nil end
    return {
        teamName     = a[1],
        teamRating   = a[3] or 0,
        weekPlayed   = a[4] or 0,
        weekWins     = a[5] or 0,
        seasonPlayed = a[6] or 0,
        seasonWins   = a[7] or 0,
        playerRating = a[11] or a[3] or 0,
    }
end

-- Entrada del día actual (crea una nueva al cambiar de fecha).
local function Today(db)
    local today = date("%d-%m-%Y")
    local last = db.days[table.getn(db.days)]
    if not last or last.date ~= today then
        last = { date = today, wins = 0, losses = 0, matches = {},
                 startRating = db.rating or 0, rating = db.rating or 0 }
        table.insert(db.days, last)
        while table.getn(db.days) > MAX_DAYS do table.remove(db.days, 1) end
    end
    return last
end

-- Recalcula agregados (rating, W/L del día, racha) por deltas de temporada.
function NC.SoloQ:Update()
    local r = self:Read()
    if not r then return end
    self._last = r
    local db = DB()
    local day = Today(db)

    if not db.snap then
        db.snap = { seasonPlayed = r.seasonPlayed, seasonWins = r.seasonWins }
        db.rating = r.playerRating
        db.best = math.max(db.best or r.playerRating, r.playerRating)
        day.rating = r.playerRating
        if self.OnChanged then self:OnChanged() end
        return
    end

    local dPlayed = (r.seasonPlayed or 0) - (db.snap.seasonPlayed or 0)
    local dWins   = (r.seasonWins   or 0) - (db.snap.seasonWins   or 0)
    if dPlayed > 0 then
        local wins   = math.max(0, math.min(dWins, dPlayed))
        local losses = dPlayed - wins
        day.wins   = (day.wins or 0) + wins
        day.losses = (day.losses or 0) + losses
        if wins > 0 and losses == 0 then
            db.streak = ((db.streak and db.streak > 0) and db.streak or 0) + wins
        elseif losses > 0 and wins == 0 then
            db.streak = ((db.streak and db.streak < 0) and db.streak or 0) - losses
        else
            db.streak = 0
        end
        db.snap.seasonPlayed = r.seasonPlayed
        db.snap.seasonWins   = r.seasonWins
    end

    db.rating = r.playerRating
    db.best = math.max(db.best or r.playerRating, r.playerRating)
    day.rating = r.playerRating
    if self.OnChanged then self:OnChanged() end
end

------------------------------------------------------------
-- Consultas
------------------------------------------------------------
function NC.SoloQ:GetTeam()   return self._last end
function NC.SoloQ:GetRating() return DB().rating or 0 end
function NC.SoloQ:GetBest()   return DB().best or DB().rating or 0 end
function NC.SoloQ:GetStreak() return DB().streak or 0 end
function NC.SoloQ:GetDays()   return DB().days or {} end

function NC.SoloQ:GetToday()
    local db = DB(); local day = Today(db)
    return {
        wins   = day.wins or 0,
        losses = day.losses or 0,
        delta  = (db.rating or 0) - (day.startRating or db.rating or 0),
    }
end

local function topN(tbl, n)
    local arr = {}
    for name, v in pairs(tbl or {}) do
        local games, wins
        if type(v) == "table" then games = v.games or 0; wins = v.wins or 0
        else games = tonumber(v) or 0; wins = 0 end
        table.insert(arr, { name = name, count = games, games = games, wins = wins })
    end
    table.sort(arr, function(a, b) return a.count > b.count end)
    while table.getn(arr) > (n or 5) do table.remove(arr) end
    return arr
end
function NC.SoloQ:GetTopAllies(n)  return topN(DB().allies, n or 5) end
function NC.SoloQ:GetTopEnemies(n) return topN(DB().enemies, n or 5) end

function NC.SoloQ:IsTopOff() return DB().topOff and true or false end
function NC.SoloQ:SetTopOff(v)
    DB().topOff = v and true or false
    if self.OnChanged then self:OnChanged() end
end
function NC.SoloQ:ClearHistory()
    local db = DB()
    db.days = {}
    if self.OnChanged then self:OnChanged() end
end

------------------------------------------------------------
-- Requisitos para anotar (talentos gastados + equipo >= 251)
------------------------------------------------------------
function NC.SoloQ:CheckEligibility()
    local res = { minILvl = MIN_ILVL, badItems = {}, talentPoints = 0, ok = true }
    if GetUnspentTalentPoints then
        res.talentPoints = GetUnspentTalentPoints(false) or 0
    end
    for _, slot in ipairs(SCORED_SLOTS) do
        local link = GetInventoryItemLink("player", slot)
        if link then
            local name, _, _, ilvl = GetItemInfo(link)
            if ilvl and ilvl < MIN_ILVL then
                table.insert(res.badItems, { slot = slot, name = name or link, ilvl = ilvl })
            end
        end
    end
    res.ok = (res.talentPoints == 0) and (table.getn(res.badItems) == 0)
    return res
end

------------------------------------------------------------
-- Cola / unirse
------------------------------------------------------------
function NC.SoloQ:Join()
    if NC.Send then NC.Send(".player joinarenasoloq") end
    self.queue.state = "queued"
    self.queue.since = GetTime()
    if self.OnChanged then self:OnChanged() end
end

function NC.SoloQ:QueueText()
    local q = self.queue or {}
    if q.state == "arena" then return "|cff40ff40En arena|r"
    elseif q.state == "queued" then return "|cffffd100En cola…|r"
    elseif q.state == "unavailable" then return "|cffff5040No disponible|r" end
    return "|cff888888Fuera de cola|r"
end

------------------------------------------------------------
-- Registro de partidas (compañeros / rivales / resultado)
------------------------------------------------------------
local function collectRoster(sess)
    if not sess then return end
    local me = UnitName("player")
    if GetNumRaidMembers and GetNumRaidMembers() > 0 then
        for i = 1, GetNumRaidMembers() do
            local nm = UnitName("raid" .. i)
            if nm and nm ~= "" and nm ~= me then sess.allies[nm] = true end
        end
    elseif GetNumPartyMembers then
        for i = 1, GetNumPartyMembers() do
            local nm = UnitName("party" .. i)
            if nm and nm ~= "" then sess.allies[nm] = true end
        end
    end
    for i = 1, 5 do
        local nm = UnitName("arena" .. i)
        if nm and nm ~= "" and nm ~= UNKNOWNOBJECT and nm ~= "Unknown" then
            sess.enemies[nm] = true
        end
    end
end

local function startArena()
    local r = NC.SoloQ:Read()
    NC.SoloQ._arena = {
        startRating = (r and r.playerRating) or (DB().rating or 0),
        startWins   = (r and r.seasonWins) or (DB().snap and DB().snap.seasonWins) or 0,
        allies = {}, enemies = {}, t = time(),
    }
    collectRoster(NC.SoloQ._arena)
end

local function finishArena()
    local sess = NC.SoloQ._arena
    NC.SoloQ._arena = nil
    if not sess then return end
    collectRoster(sess)
    local r = NC.SoloQ:Read()
    local endRating = (r and r.playerRating) or DB().rating or 0
    local endWins   = (r and r.seasonWins) or 0
    local win = (endWins > (sess.startWins or 0)) or (endRating > (sess.startRating or 0))

    local allies, enemies = {}, {}
    for nm in pairs(sess.allies) do table.insert(allies, nm) end
    for nm in pairs(sess.enemies) do table.insert(enemies, nm) end

    local db = DB()
    if not db.topOff then
        local function bump(tbl, nm)
            local e = tbl[nm]
            if type(e) ~= "table" then e = { games = tonumber(e) or 0, wins = 0 }; tbl[nm] = e end
            e.games = e.games + 1
            if win then e.wins = e.wins + 1 end
        end
        for _, nm in ipairs(allies)  do bump(db.allies, nm) end
        for _, nm in ipairs(enemies) do bump(db.enemies, nm) end
    end

    local day = Today(db)
    table.insert(day.matches, {
        t = sess.t, win = win and true or false,
        delta = endRating - (sess.startRating or endRating),
        allies = allies, enemies = enemies,
    })
    if NC.SoloQ.OnChanged then NC.SoloQ:OnChanged() end
end

------------------------------------------------------------
-- Eventos
------------------------------------------------------------
local poll = CreateFrame("Frame"); poll:Hide()
poll:SetScript("OnUpdate", function(self, elapsed)
    self._t = (self._t or 0) + (elapsed or 0)
    if self._t < 2 then return end
    self._t = 0
    pcall(collectRoster, NC.SoloQ._arena)
end)

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("ARENA_TEAM_UPDATE")
f:RegisterEvent("ARENA_TEAM_ROSTER_UPDATE")
f:RegisterEvent("UPDATE_BATTLEFIELD_STATUS")
f:RegisterEvent("CHAT_MSG_SYSTEM")
f:SetScript("OnEvent", function(_, event, arg1)
    if event == "CHAT_MSG_SYSTEM" then
        if NC.SoloQ.queue.state == "queued" and NC.Normalize then
            local m = NC.Normalize(arg1 or "")
            if string.find(m, "no ha sido posible unirte", 1, true) then
                NC.SoloQ.queue.state = "idle"
                if NC.SoloQ.OnChanged then NC.SoloQ:OnChanged() end
            elseif string.find(m, "usage", 1, true) and string.find(m, ".player", 1, true) then
                NC.SoloQ.queue.state = "unavailable"
                NC.SoloQ.queue.since = GetTime()
                if NC.SoloQ.OnChanged then NC.SoloQ:OnChanged() end
            end
        end
        return
    end
    if event == "PLAYER_ENTERING_WORLD" then
        local inInst, kind = IsInInstance()
        if inInst and kind == "arena" then
            NC.SoloQ.queue.state = "arena"
            if not NC.SoloQ._arena then startArena() end
            poll._t = 0; poll:Show()
        else
            poll:Hide()
            if NC.SoloQ._arena then pcall(finishArena) end
            if NC.SoloQ.queue.state == "arena" then NC.SoloQ.queue.state = "idle" end
        end
    end
    local ok = pcall(function() NC.SoloQ:Update() end)
    if not ok and NC.SoloQ.OnChanged then NC.SoloQ:OnChanged() end
end)
