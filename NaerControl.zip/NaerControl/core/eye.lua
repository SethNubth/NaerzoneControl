local ADDON, NC = ...

local COL = NC.COL

local eye, panel, box, preview, previewHover, checkBtn, resultFS, menuFrame

------------------------------------------------------------
-- Captura de enlaces
-- Guardamos el ultimo objeto que ha pasado por el chat para que
-- comprobarlo sea un clic, sin escribir ni arrastrar nada.
------------------------------------------------------------
NC.LastLink = nil
NC.LinkHistory = {}          -- los ultimos objetos vistos, el mas reciente primero
local HISTORY_MAX = 10

-- El enlace ya trae el nombre y el color de calidad dentro, asi que no
-- dependemos de que el cliente tenga el objeto en cache.
local function LinkName(link)
    local nombre = string.match(link or "", "|h%[(.-)%]|h")
    if not nombre then return nil end
    local color = string.match(link, "|c(%x%x%x%x%x%x%x%x)")
    if color then return "|c" .. color .. nombre .. "|r" end
    return nombre
end

-- Solo lo que se dice en la propia banda. Fuera quedan los canales
-- personalizados (taberna y demas), hermandad, susurros y grito: ahi se
-- enlazan objetos que no tienen nada que ver con el reparto.
local CHAT_EVENTS = {
    "CHAT_MSG_LOOT",
    "CHAT_MSG_SAY",
    "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
}

local function RememberLink(link)
    local id = tonumber(string.match(link, "Hitem:(%d+)"))
    if not id then return end
    -- si ya estaba, sube al principio en vez de duplicarse
    for i, e in ipairs(NC.LinkHistory) do
        if e.id == id then table.remove(NC.LinkHistory, i) break end
    end
    table.insert(NC.LinkHistory, 1, {
        id = id, link = link, name = LinkName(link), time = GetTime(),
    })
    while table.getn(NC.LinkHistory) > HISTORY_MAX do
        table.remove(NC.LinkHistory)
    end
end

function NC.CaptureLink(msg)
    if type(msg) ~= "string" then return end

    -- Un mismo mensaje puede traer varios objetos enlazados (el master
    -- suele soltar todo el botin de golpe): los guardamos TODOS, en orden.
    -- RememberLink mete cada uno al principio, asi que recorriendo de
    -- izquierda a derecha el ultimo objeto del mensaje acaba arriba del
    -- historial, que es el mas reciente.
    local found = {}
    for link in string.gmatch(msg, "|c%x+|Hitem:%d+[^|]*|h%[[^%]]*%]|h|r") do
        table.insert(found, link)
        RememberLink(link)
    end
    if table.getn(found) == 0 then return end

    local last = found[table.getn(found)]

    NC.LastLink = last

    if panel and panel:IsShown() and box:GetText() == "" then
        NC.Eye:SetItem(last)
    end
    return last, table.getn(found)
end

------------------------------------------------------------
NC.Eye = {}

-- Aplica al ojo los ajustes guardados (escala, opacidad, fundido, bloqueo).
function NC.Eye:ApplySettings()
    if not eye then return end
    local db = NC.db or {}
    eye:SetScale(db.eyeScale or 1)
    self._baseAlpha = db.eyeAlpha or 1
    local a = self._baseAlpha
    if db.eyeFade and not eye._hover then a = math.min(a, 0.35) end
    eye:SetAlpha(a)
    if db.eyeLock then eye:RegisterForDrag() else eye:RegisterForDrag("LeftButton") end
    -- si se desactiva "ocultar en combate" y estaba oculto por eso, recupéralo
    if not db.eyeHideCombat and eye._combatHidden then
        eye._combatHidden = false
        if db.eyeShown then eye:Show() end
    end
end

-- Refresca los textos de porcentaje en la pestaña Ajustes.
function NC.SyncEyeSettings()
    if NC._eyeScaleFS then NC._eyeScaleFS:SetText(string.format("%.0f%%", (NC.db and NC.db.eyeScale or 1) * 100)) end
    if NC._eyeAlphaFS then NC._eyeAlphaFS:SetText(string.format("%.0f%%", (NC.db and NC.db.eyeAlpha or 1) * 100)) end
end

function NC.EyeAddScale(delta)
    if not NC.db then return end
    local v = (NC.db.eyeScale or 1) + delta
    if v < 0.6 then v = 0.6 elseif v > 2 then v = 2 end
    NC.db.eyeScale = v
    NC.Eye:ApplySettings(); NC.SyncEyeSettings()
end

function NC.EyeAddAlpha(delta)
    if not NC.db then return end
    local v = (NC.db.eyeAlpha or 1) + delta
    if v < 0.2 then v = 0.2 elseif v > 1 then v = 1 end
    NC.db.eyeAlpha = v
    NC.Eye:ApplySettings(); NC.SyncEyeSettings()
end

-- Devuelve el ojo a su posición por defecto (por si se pierde de vista).
function NC.ResetEyePosition()
    if not eye then return end
    eye:ClearAllPoints()
    eye:SetPoint("CENTER", UIParent, "CENTER", 260, -120)
    if NC.cdb then NC.cdb.eyeX, NC.cdb.eyeY = 260, -120 end
    if NC.db and NC.db.eyeShown and not eye:IsShown() then eye:Show() end
end

function NC.Eye:GetItemID()
    local text = box and box:GetText() or ""
    local id = tonumber(text)
    if not id then id = tonumber(string.match(text, "Hitem:(%d+)")) end
    return id
end

function NC.Eye:SetItem(textOrID)
    if not box then return end
    box:SetText(textOrID or "")
    self:RefreshPreview()
end

function NC.Eye:RefreshPreview()
    local id = self:GetItemID()
    if id then
        preview:SetTexture(NC.ItemIcon(id))
        preview:Show()
    else
        preview:Hide()
    end
    resultFS:SetText("")
end

function NC.Eye:Check()
    local id = self:GetItemID()
    if not id then
        resultFS:SetTextColor(1, 0.4, 0.4)
        resultFS:SetText("Escribe un ID o enlaza un objeto.")
        return
    end

    local target, err = NC.GetValidTarget()
    if not target then
        -- sin objetivo: si hay vigilados, se los ofrecemos
        if NC.Watch and NC.Watch:Count() > 0 then
            NC.Watch.pendingItem = id
            NC.Watch:Show()
            resultFS:SetTextColor(1, 0.82, 0)
            resultFS:SetText("Sin objetivo: pincha en la lista de vigilados.")
            return
        end
        resultFS:SetTextColor(1, 0.4, 0.4)
        resultFS:SetText(err)
        return
    end

    if NC.Watch then NC.Watch.pendingItem = id end
    NC.Scanner:AskItem(id, nil)
    resultFS:SetTextColor(0.7, 0.7, 0.7)
    resultFS:SetText("Preguntando a " .. target .. "...")
end

-- Llamado desde el escaner cuando llega una respuesta
function NC.Eye:OnResult(player, itemID, state, place, count)
    if not resultFS then return end
    if self:GetItemID() ~= itemID then return end
    if state == "sold" then
        resultFS:SetTextColor(1, 0.5, 0)
        resultFS:SetText(player .. ": VENDIDO PARA RECUPERAR")
    elseif state == "yes" then
        resultFS:SetTextColor(1, 0.4, 0.4)
        resultFS:SetText(player .. ": LO TIENE" .. (place and (" (" .. place .. ")") or ""))
    elseif state == "no" then
        resultFS:SetTextColor(0.4, 1, 0.4)
        resultFS:SetText(player .. ": no lo tiene")
    end
end

-- Muestra un error/estado en rojo en el panel del ojo.
function NC.Eye:Fail(text)
    if not resultFS then return end
    resultFS:SetTextColor(1, 0.4, 0.4)
    resultFS:SetText(text or "Error.")
end

------------------------------------------------------------
-- Historial: los ultimos objetos que han pasado por el chat
------------------------------------------------------------
local histFrame

function NC.Eye:ShowHistory()
    local n = table.getn(NC.LinkHistory)
    if n == 0 then
        resultFS:SetTextColor(1, 0.82, 0)
        resultFS:SetText("No he visto ningún objeto en el chat todavía.")
        return
    end

    local menu = { { text = "Últimos objetos vistos", isTitle = true, notCheckable = true } }
    for _, e in ipairs(NC.LinkHistory) do
        local entry = e
        local nombre = entry.name or NC.ItemName(entry.id)
        table.insert(menu, {
            text = nombre,
            notCheckable = true,
            func = function() NC.Eye:SetItem(entry.link) end,
        })
    end
    table.insert(menu, {
        text = "Vaciar la lista",
        notCheckable = true,
        func = function()
            StaticPopup_Show("NAERCONTROL_CLEAR_HISTORY")
        end,
    })

    if not histFrame then
        histFrame = CreateFrame("Frame", "NaerControlHistMenu", UIParent, "UIDropDownMenuTemplate")
    end
    EasyMenu(menu, histFrame, "cursor", 0, 0, "MENU")
end

------------------------------------------------------------
-- Ventana independiente de IDs (bloqueos de banda/mazmorra del objetivo).
-- Es una ventana propia, separada de la principal del addon.
------------------------------------------------------------
local idsWin
local RefreshIdsWindow, DoIdsQuery, RefreshRoster, showList, showRoster   -- forward-declare

local function BuildIdsWindow()
    local w = CreateFrame("Frame", "NaerControlIdsWindow", UIParent)
    w:SetWidth(340)
    w:SetHeight(320)
    if NC.cdb and NC.cdb.idsX then
        w:SetPoint("CENTER", UIParent, "CENTER", NC.cdb.idsX, NC.cdb.idsY)
    else
        w:SetPoint("CENTER")
    end
    w:SetFrameStrata("DIALOG")
    w:SetToplevel(true)
    w:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 14,
        insets   = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    w:SetBackdropColor(0, 0, 0, 0.92)
    if NC.RegisterThemeable then
        NC.RegisterThemeable(function(t)
            if t and t.name == "modern" and t.accent then
                w:SetBackdropBorderColor(t.accent[1], t.accent[2], t.accent[3], 0.9)
            else
                w:SetBackdropBorderColor(1, 1, 1, 1)
            end
        end)
    end
    w:EnableMouse(true)
    w:SetMovable(true)
    w:RegisterForDrag("LeftButton")
    w:SetScript("OnDragStart", w.StartMoving)
    w:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x, y = self:GetCenter()
        local px, py = UIParent:GetCenter()
        if x and px and NC.cdb then NC.cdb.idsX, NC.cdb.idsY = x - px, y - py end
    end)

    local title = w:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 12, -12)
    title:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "IDs|r")
    w.title = title

    local close = CreateFrame("Button", nil, w, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 2, 2)
    close:SetScript("OnClick", function() w:Hide() end)

    -- Área con scroll para el contenido (lista de IDs y composición).
    local scroll, content = NC.CreateScroll(w)
    scroll:SetPoint("TOPLEFT", 12, -40)
    scroll:SetPoint("BOTTOMRIGHT", -28, 44)
    content:SetWidth(300)
    scroll:SetScript("OnSizeChanged", function(_, ww) if content then content:SetWidth(ww or 1) end end)
    w.scroll, w.content = scroll, content

    local body = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    body:SetPoint("TOPLEFT", 0, -2)
    body:SetPoint("RIGHT", content, "RIGHT", 0, 0)
    body:SetJustifyH("LEFT")
    body:SetJustifyV("TOP")
    body:SetSpacing(5)
    body:SetTextColor(0.85, 0.87, 0.92)
    w.body = body

    -- Vista de composición (.raid info) dentro del mismo scroll.
    local roster = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    roster:SetPoint("TOPLEFT", 0, -2)
    roster:SetPoint("RIGHT", content, "RIGHT", 0, 0)
    roster:SetJustifyH("LEFT"); roster:SetJustifyV("TOP"); roster:SetSpacing(5)
    roster:SetTextColor(0.85, 0.87, 0.92)
    roster:Hide()
    w.roster = roster

    -- Botón "< Volver" (solo visible en la vista de composición).
    local back = CreateFrame("Button", nil, w, "UIPanelButtonTemplate")
    back:SetSize(72, 18)
    back:SetPoint("TOPLEFT", 10, -10)
    back:SetText("< Volver")
    back:Hide()
    back:SetScript("OnClick", function() if showList then showList() end end)
    if NC.SkinButton then NC.SkinButton(back) end
    w.back = back

    w.rows = {}   -- pool de filas clicables

    -- Botón interno: reconsulta los IDs del objetivo actual sin salir de aquí.
    local btn = CreateFrame("Button", nil, w, "UIPanelButtonTemplate")
    btn:SetWidth(180)
    btn:SetHeight(22)
    btn:SetPoint("BOTTOM", 0, 12)
    btn:SetText("Inspeccionar IDs (objetivo)")
    btn._label = "Inspeccionar IDs (objetivo)"
    btn:SetScript("OnClick", function()
        local t = UnitExists("target") and UnitIsPlayer("target") and UnitName("target") or nil
        DoIdsQuery(t)
    end)
    -- Límite global de envíos (2 / 10 s): mientras no se pueda enviar, el botón
    -- se pone en gris con una cuenta atrás. Se reactiva solo al liberarse.
    btn:SetScript("OnUpdate", function(self, elapsed)
        self._acc = (self._acc or 0) + (elapsed or 0)
        if self._acc < 0.25 then return end
        self._acc = 0
        local hasT = UnitExists("target") and UnitIsPlayer("target")
        local wait = NC.SendWaitTime and NC.SendWaitTime() or 0
        if not hasT then
            NC.SetButtonEnabled(self, false)
            self:SetText("Sin objetivo")
        elseif wait and wait > 0.1 then
            NC.SetButtonEnabled(self, false)
            self:SetText(string.format("Espera %ds", math.ceil(wait)))
        else
            NC.SetButtonEnabled(self, true)
            self:SetText(self._label)
        end
    end)
    if NC.SkinButton then NC.SkinButton(btn) end
    w.btn = btn

    return w
end

-- Oculta todas las filas del pool.
local function hideRows()
    if not idsWin or not idsWin.rows then return end
    for _, r in ipairs(idsWin.rows) do r:Hide() end
end

-- Devuelve (creando si hace falta) la fila i del pool.
local function getRow(i)
    local w = idsWin
    local r = w.rows[i]
    if not r then
        r = CreateFrame("Button", nil, w.content)
        r:SetHeight(16)
        r:SetPoint("TOPLEFT", w.content, "TOPLEFT", 0, -(i - 1) * 17)
        r:SetPoint("RIGHT", w.content, "RIGHT", 0, 0)
        local fs = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        fs:SetPoint("LEFT", 0, 0); fs:SetJustifyH("LEFT")
        r.fs = fs
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints(r); hl:SetTexture("Interface\\Buttons\\WHITE8X8")
        hl:SetVertexColor(1, 1, 1, 0.10)
        w.rows[i] = r
    end
    r:Show()
    return r
end

-- Refresca la ventana de IDs (vista LISTA) desde NC.Info.raidList. Cada banda
-- con ID real es una fila clicable que consulta su composición (.raid info).
RefreshIdsWindow = function()
    if not idsWin or not idsWin:IsShown() then return end
    if idsWin.roster then idsWin.roster:Hide() end
    if idsWin.back then idsWin.back:Hide() end
    -- restaurar el título a su posición normal (vista de lista)
    idsWin.title:ClearAllPoints()
    idsWin.title:SetPoint("TOPLEFT", 12, -12)
    idsWin.body:Show()
    if idsWin.scroll then idsWin.scroll:SetVerticalScroll(0) end
    hideRows()
    local rl = NC.Info and NC.Info.raidList
    local quien = (NC.Info and NC.Info._rlQueried) or "?"
    idsWin.title:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "IDs de|r |cffffffff" .. quien .. "|r")
    if not rl then
        idsWin.body:SetText("|cff888888Consultando…|r")
        idsWin.content:SetHeight(40)
        return
    end
    if not rl.locks or #rl.locks == 0 then
        idsWin.body:SetText("|cff888888Sin bloqueos de banda/mazmorra.|r")
        idsWin.content:SetHeight(40)
        return
    end
    local showDun = (NC.db and NC.db.showDungeonLocks == true) or false
    local i, hidden = 0, 0
    for _, k in ipairs(rl.locks) do
        local isRaid = (NC.IsRaidLock == nil) or NC.IsRaidLock(k.diff)
        if isRaid or showDun then
            i = i + 1
            local id = tonumber(k.raidId)
            local head = (id and id > 0) and ("|cffffd100ID " .. id .. "|r  ") or ""
            local mapes = (NC.LocalizeInstance and NC.LocalizeInstance(k.map or "?")) or (k.map or "?")
            local row = getRow(i)
            local txt = head .. "|cffffffff" .. mapes .. "|r  |cff888888(" .. (k.diff or "") .. ")|r"
            if id and id > 0 then
                row.fs:SetText(txt .. "  |cff4fc3f7\194\187|r")
                row:EnableMouse(true)
                row:SetScript("OnClick", function()
                    NC.Info.OnRaidInfo = RefreshRoster
                    NC.Info.raidInfo = nil
                    NC.Info:QueryRaidInfo(id)
                    showRoster(id)
                end)
            else
                row.fs:SetText(txt)
                row:EnableMouse(false)
                row:SetScript("OnClick", nil)
            end
        else
            hidden = hidden + 1
        end
    end
    if i == 0 then
        idsWin.body:SetText("|cff888888Sin bloqueos de banda.|r")
        idsWin.content:SetHeight(40)
        return
    end
    idsWin.body:Hide()
    if hidden > 0 then
        i = i + 1
        local row = getRow(i)
        row:EnableMouse(false); row:SetScript("OnClick", nil)
        row.fs:SetText("|cff707070+ " .. hidden .. " mazmorra" .. (hidden == 1 and "" or "s")
            .. " oculta" .. (hidden == 1 and "" or "s") .. " (Ajustes)|r")
    end
    idsWin.content:SetHeight(i * 17 + 8)
end

-- Muestra la vista de COMPOSICIÓN (.raid info) del ID pulsado.
showRoster = function(id)
    if not idsWin then return end
    hideRows()
    idsWin.body:Hide()
    idsWin.roster:Show()
    idsWin.back:Show()
    -- el título arranca a la derecha del botón "< Volver" para que no se solapen
    idsWin.title:ClearAllPoints()
    idsWin.title:SetPoint("LEFT", idsWin.back, "RIGHT", 8, 0)
    idsWin.title:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "Composición · ID |r|cffffd100" .. tostring(id) .. "|r")
    idsWin.roster:SetText("|cff888888Consultando composición…|r")
    idsWin.content:SetHeight(40)
    if idsWin.scroll then idsWin.scroll:SetVerticalScroll(0) end
end

-- Vuelve a la vista de LISTA de IDs.
showList = function()
    if not idsWin then return end
    NC.Info.OnRaidInfo = nil
    NC.Info.OnRaidList = RefreshIdsWindow
    idsWin.roster:Hide()
    idsWin.back:Hide()
    RefreshIdsWindow()
end

-- Pinta la composición cuando llega la respuesta de .raid info.
RefreshRoster = function()
    if not idsWin or not idsWin:IsShown() or not idsWin.roster:IsShown() then return end
    local ri = NC.Info and NC.Info.raidInfo
    if ri and ri.empty then
        idsWin.roster:SetText("|cffff8080" .. (ri.reason or "Nadie conectado en este ID.") .. "|r")
        idsWin.content:SetHeight(40)
        return
    end
    if not ri or not ri.raidId then
        idsWin.roster:SetText("|cff888888Sin datos de composición (o sin respuesta).|r")
        idsWin.content:SetHeight(40)
        return
    end
    local L = {}
    local mapes = (NC.LocalizeInstance and NC.LocalizeInstance(ri.map or "?")) or (ri.map or "?")
    L[#L + 1] = "|cffffffff" .. mapes .. "|r  |cffffd100" .. (ri.diff or "") .. "|r"
    if ri.encounters then L[#L + 1] = "|cff888888Encuentros:|r " .. ri.encounters end
    if ri.leader     then L[#L + 1] = "|cff888888Líder:|r " .. ri.leader end
    if ri.players    then L[#L + 1] = "|cff888888Jugadores:|r " .. ri.players end
    if ri.roles      then L[#L + 1] = "|cff888888Roles:|r " .. ri.roles end
    if ri.gs         then L[#L + 1] = "|cff888888GS medio:|r |cffffd100" .. ri.gs
                          .. "|r  |cff888888iLvl:|r " .. (ri.ilvl or "?") end
    idsWin.roster:SetText(table.concat(L, "\n"))
    idsWin.content:SetHeight((idsWin.roster:GetStringHeight() or 120) + 12)
end

-- Lanza la consulta de IDs para 'target' y refresca la ventana.
DoIdsQuery = function(target)
    if not idsWin then return end
    NC.Info.OnRaidList = RefreshIdsWindow   -- el resultado refresca ESTA ventana
    NC.Info.raidList = nil                    -- estado "Consultando…"
    if not target or target == "" then
        idsWin.title:ClearAllPoints()
        idsWin.title:SetPoint("TOPLEFT", 12, -12)
        idsWin.title:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "IDs|r")
        if idsWin.roster then idsWin.roster:Hide() end
        if idsWin.back then idsWin.back:Hide() end
        hideRows()
        idsWin.body:Show()
        idsWin.body:SetText("|cffff8080Selecciona a un jugador como objetivo.|r")
        idsWin.content:SetHeight(40)
        return
    end
    NC.Info:QueryRaidList(target)             -- fija _rlQueried y envía
    RefreshIdsWindow()                        -- "Consultando… de <target>"
end

-- Abre la ventana de IDs (propia, no la principal) y consulta al objetivo.
function NC.OpenIdsWindow(target)
    if not idsWin then idsWin = BuildIdsWindow() end
    idsWin:Show()
    DoIdsQuery(target)
end

-- Expuesto para refrescar la ventana en vivo (p.ej. al cambiar el ajuste de
-- traducción de nombres desde la pestaña Ajustes).
NC.RefreshIdsWindow = function() RefreshIdsWindow() end

------------------------------------------------------------
-- Menu del boton derecho
------------------------------------------------------------
local function BuildMenu()
    local target = UnitExists("target") and UnitIsPlayer("target") and UnitName("target") or nil
    -- Paleta coherente con el addon
    local C = {
        titulo = "|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3"),  -- acento del tema (cabeceras)
        accion = "|cffffffff",  -- blanco (acciones normales)
        info   = "|cff4fc3f7",  -- cian (inspeccionar / consultar)
        watch  = "|cffffd100",  -- dorado (vigilados)
        malo   = "|cffff6060",  -- rojo (destructivo)
        tenue  = "|cff9aa0a8",  -- gris (secundario)
    }
    local R = "|r"
    local menu = {
        { text = C.titulo .. "NaerControl" .. R, isTitle = true, notCheckable = true },
    }

    if target then
        table.insert(menu, {
            text = C.watch .. "Añadir a vigilados: " .. R .. "|cffffffff" .. target .. R,
            notCheckable = true,
            func = function() NC.Watch:Add(target) end,
        })
        table.insert(menu, {
            text = C.info .. "Inspeccionar IDs de " .. R .. "|cffffffff" .. target .. R,
            notCheckable = true,
            func = function() if NC.OpenIdsWindow then NC.OpenIdsWindow(target) end end,
        })
    else
        table.insert(menu, { text = C.tenue .. "Añadir a vigilados" .. R, notCheckable = true, disabled = true })
        table.insert(menu, { text = C.tenue .. "Inspeccionar IDs del objetivo" .. R, notCheckable = true, disabled = true })
    end

    local inGroup = NC.Watch:InGroup()
    table.insert(menu, {
        text = (inGroup and C.watch or C.tenue) .. "Añadir toda la banda" .. R,
        notCheckable = true,
        disabled = not inGroup,
        func = function() NC.Watch:AddRaid() end,
    })
    table.insert(menu, {
        text = C.watch .. ((NC.Watch:IsShown() and "Ocultar" or "Ver") .. " vigilados ("
               .. NC.Watch:Count() .. ")") .. R,
        notCheckable = true,
        func = function() NC.Watch:Toggle() end,
    })
    table.insert(menu, {
        text = C.malo .. "Vaciar vigilados" .. R,
        notCheckable = true,
        disabled = NC.Watch:Count() == 0,
        func = function() NC.Watch:Clear() end,
    })
    table.insert(menu, { text = "", isTitle = true, notCheckable = true })
    table.insert(menu, {
        text = C.accion .. "Abrir NaerControl" .. R,
        notCheckable = true,
        func = function() NC.ToggleWindow() end,
    })
    table.insert(menu, {
        text = C.tenue .. "Ocultar el ojo" .. R,
        notCheckable = true,
        func = function() NC.ToggleEye() end,
    })
    return menu
end

------------------------------------------------------------
-- Construccion
------------------------------------------------------------
-- Coloca el panel junto al ojo eligiendo lado según el espacio en pantalla.
local function PositionPanel()
    if not panel or not eye then return end
    panel:ClearAllPoints()
    local pw, ph = panel:GetWidth(), panel:GetHeight()
    local eLeft   = eye:GetLeft() or 0
    local eBottom = eye:GetBottom() or 0
    local scrW = UIParent:GetRight() or 1024
    local below = (eBottom - (ph + 8)) >= 0
    local alignLeft = (eLeft + pw) <= scrW
    if below then
        if alignLeft then panel:SetPoint("TOPLEFT", eye, "BOTTOMLEFT", 0, -4)
        else panel:SetPoint("TOPRIGHT", eye, "BOTTOMRIGHT", 0, -4) end
    else
        if alignLeft then panel:SetPoint("BOTTOMLEFT", eye, "TOPLEFT", 0, 4)
        else panel:SetPoint("BOTTOMRIGHT", eye, "TOPRIGHT", 0, 4) end
    end
end

local function BuildPanel()
    panel = CreateFrame("Frame", "NaerControlEyePanel", UIParent)
    panel:SetWidth(320)
    panel:SetHeight(118)
    panel:SetFrameStrata("DIALOG")
    panel:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 14,
        insets   = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    panel:SetBackdropColor(0.04, 0.05, 0.07, 0.95)
    panel:EnableMouse(true)
    panel:Hide()

    -- Cabecera: título + cerrar
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 12, -10)
    title:SetText("Buscar objeto")

    local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    close:SetWidth(26); close:SetHeight(26)
    close:SetPoint("TOPRIGHT", 2, 2)
    close:SetScript("OnClick", function() panel:Hide() end)

    -- Tema: título con acento + borde con acento en Moderno
    local function themePanel(t)
        local ac = (t and t.accent) or { 0.49, 0.78, 0.89 }
        title:SetTextColor(ac[1], ac[2], ac[3])
        if t and t.name == "modern" then
            panel:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.9)
        else
            panel:SetBackdropBorderColor(1, 1, 1, 1)
        end
    end
    if NC.RegisterThemeable then NC.RegisterThemeable(themePanel) else themePanel(NC.Theme) end

    -- Icono de vista previa
    preview = panel:CreateTexture(nil, "ARTWORK")
    preview:SetWidth(30); preview:SetHeight(30)
    preview:SetPoint("TOPLEFT", 12, -32)
    preview:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    preview:Hide()

    previewHover = CreateFrame("Frame", nil, panel)
    previewHover:SetAllPoints(preview)
    previewHover:EnableMouse(true)
    previewHover:SetScript("OnEnter", function(self)
        local id = NC.Eye:GetItemID()
        if not id then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetHyperlink("item:" .. id)
        GameTooltip:Show()
    end)
    previewHover:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Botón Comprobar (derecha)
    checkBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    checkBtn:SetWidth(80); checkBtn:SetHeight(24)
    checkBtn:SetPoint("TOPRIGHT", -10, -33)
    checkBtn:SetText("Comprobar")
    checkBtn:SetScript("OnClick", function() NC.Eye:Check() end)

    -- Caja de texto (entre icono y botón)
    box = CreateFrame("EditBox", nil, panel)
    box:SetPoint("TOPLEFT", preview, "TOPRIGHT", 8, -1)
    box:SetPoint("TOPRIGHT", checkBtn, "TOPLEFT", -8, 1)
    box:SetHeight(26)
    box:SetFontObject("ChatFontNormal")
    box:SetAutoFocus(false)
    box:SetMaxLetters(250)
    box:SetTextInsets(6, 6, 0, 0)
    box:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 10,
        insets   = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    box:SetBackdropColor(0, 0, 0, 0.6)
    box:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)

    -- Placeholder (texto guía cuando está vacía y sin foco)
    box.ph = box:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    box.ph:SetPoint("LEFT", 8, 0)
    box.ph:SetText("ID o arrastra un objeto…")
    local function updatePH()
        if box:GetText() == "" and not box:HasFocus() then box.ph:Show() else box.ph:Hide() end
    end
    box:SetScript("OnTextChanged", function() NC.Eye:RefreshPreview(); updatePH() end)
    box:SetScript("OnEditFocusGained", function() box.ph:Hide() end)
    box:SetScript("OnEditFocusLost", updatePH)
    box:SetScript("OnEnterPressed", function(self) NC.Eye:Check(); self:ClearFocus() end)
    box:SetScript("OnEscapePressed", function(self) self:ClearFocus(); panel:Hide() end)
    NC.RegisterLinkTarget(box)
    updatePH()

    -- Resultado en su propia línea
    resultFS = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    resultFS:SetPoint("TOPLEFT", 12, -66)
    resultFS:SetPoint("TOPRIGHT", -12, -66)
    resultFS:SetHeight(28)
    resultFS:SetJustifyH("LEFT")
    resultFS:SetJustifyV("TOP")

    -- Objetos vistos (historial)
    local grab = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    grab:SetWidth(130); grab:SetHeight(20)
    grab:SetPoint("BOTTOMLEFT", 10, 10)
    grab:SetText("Objetos vistos")
    grab:SetScript("OnClick", function() NC.Eye:ShowHistory() end)

    -- Skin del tema a caja y botones
    if NC.SkinEditBox then NC.SkinEditBox(box) end
    if NC.SkinButton then NC.SkinButton(checkBtn); NC.SkinButton(grab) end
end

-- Abre/cierra el panel de búsqueda con anclaje inteligente y foco automático.
function NC.Eye:TogglePanel()
    if not panel then BuildPanel() end
    if panel:IsShown() then panel:Hide(); return end
    if box:GetText() == "" and NC.LastLink then NC.Eye:SetItem(NC.LastLink) end
    PositionPanel()
    panel:Show()
    box:SetFocus()
    box:HighlightText()
end

function NC.CreateEye()
    if eye then return eye end

    eye = CreateFrame("Button", "NaerControlEye", UIParent)
    eye:SetWidth(34)
    eye:SetHeight(34)
    eye:SetFrameStrata("MEDIUM")
    eye:SetMovable(true)
    eye:EnableMouse(true)
    eye:RegisterForDrag("LeftButton")
    eye:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    local icon = eye:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    icon:SetTexture("Interface\\Icons\\INV_Misc_Eye_01")
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    eye.icon = icon

    local border = eye:CreateTexture(nil, "OVERLAY")
    border:SetPoint("TOPLEFT", -2, 2)
    border:SetPoint("BOTTOMRIGHT", 2, -2)
    border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    border:SetTexCoord(0.2, 0.8, 0.2, 0.8)
    border:SetVertexColor(1, 1, 1, 0.5)

    local hl = eye:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
    hl:SetBlendMode("ADD")

    eye:SetScript("OnDragStart", function(self)
        if NC.db and NC.db.eyeLock then return end
        self:StartMoving()
    end)
    eye:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        -- GetCenter y no GetPoint: en marcos pequeños GetPoint devuelve un
        -- desplazamiento erroneo despues de StartMoving y el ojo se va solo.
        local x, y = self:GetCenter()
        local px, py = UIParent:GetCenter()
        if x and px then
            NC.cdb.eyeX, NC.cdb.eyeY = x - px, y - py
        end
    end)

    eye:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            if not menuFrame then
                menuFrame = CreateFrame("Frame", "NaerControlEyeMenu", UIParent, "UIDropDownMenuTemplate")
            end
            EasyMenu(BuildMenu(), menuFrame, "cursor", 0, 0, "MENU")
        else
            NC.Eye:TogglePanel()
        end
    end)

    eye:SetScript("OnEnter", function(self)
        self._hover = true
        if NC.db and NC.db.eyeFade then self:SetAlpha(NC.Eye._baseAlpha or 1) end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("NaerControl")
        GameTooltip:AddLine("Clic izquierdo: comprobar un objeto", 1, 1, 1)
        GameTooltip:AddLine("Clic derecho: vigilados y opciones", 1, 1, 1)
        GameTooltip:AddLine("Arrastrar: mover", 0.7, 0.7, 0.7)
        if NC.LastLink then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Último del chat: "
                .. (LinkName(NC.LastLink) or NC.LastLink))
        end
        GameTooltip:Show()
    end)
    eye:SetScript("OnLeave", function(self)
        self._hover = false
        if NC.db and NC.db.eyeFade then self:SetAlpha(math.min(NC.Eye._baseAlpha or 1, 0.35)) end
        GameTooltip:Hide()
    end)
    -- si el ojo se oculta (combate, /reload, opción), cierra el panel
    eye:HookScript("OnHide", function() if panel then panel:Hide() end end)

    -- posicion guardada
    if NC.cdb and NC.cdb.eyeX then
        eye:SetPoint("CENTER", UIParent, "CENTER", NC.cdb.eyeX, NC.cdb.eyeY)
    else
        eye:SetPoint("CENTER", UIParent, "CENTER", 260, -120)
    end

    if NC.db and not NC.db.eyeShown then eye:Hide() end

    -- aplica escala/opacidad/fundido/bloqueo guardados
    NC.Eye:ApplySettings()

    -- escucha de enlaces y de combate (para ocultar en combate)
    local listener = CreateFrame("Frame")
    for _, ev in ipairs(CHAT_EVENTS) do listener:RegisterEvent(ev) end
    listener:RegisterEvent("PLAYER_REGEN_DISABLED")
    listener:RegisterEvent("PLAYER_REGEN_ENABLED")
    listener:SetScript("OnEvent", function(self, event, msg)
        if event == "PLAYER_REGEN_DISABLED" then
            if NC.db and NC.db.eyeHideCombat and eye and eye:IsShown() then
                eye._combatHidden = true
                eye:Hide()
            end
        elseif event == "PLAYER_REGEN_ENABLED" then
            if eye and eye._combatHidden then
                eye._combatHidden = false
                if NC.db and NC.db.eyeShown then eye:Show() end
            end
        else
            NC.CaptureLink(msg)
        end
    end)

    return eye
end

function NC.ToggleEye()
    if not eye then return end
    if eye:IsShown() then
        eye:Hide()
        NC.db.eyeShown = false
        NC.Print("Ojo oculto. Usa " .. COL.accent .. "/nc ojo" .. COL.r .. " para recuperarlo.")
    else
        eye:Show()
        NC.db.eyeShown = true
    end
end

------------------------------------------------------------
-- Confirmacion de vaciado de la lista de objetos vistos
------------------------------------------------------------
StaticPopupDialogs["NAERCONTROL_CLEAR_HISTORY"] = {
    text = "¿Vaciar la lista de objetos vistos? Esto no afecta a los vigilados.",
    button1 = ACCEPT or "Aceptar",
    button2 = CANCEL or "Cancelar",
    OnAccept = function()
        while table.getn(NC.LinkHistory) > 0 do table.remove(NC.LinkHistory) end
        NC.LastLink = nil
        NC.Print("Lista de objetos vistos vaciada.")
    end,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
    preferredIndex = 3,
}
