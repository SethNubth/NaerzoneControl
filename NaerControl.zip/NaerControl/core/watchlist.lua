local ADDON, NC = ...

local COL = NC.COL

------------------------------------------------------------
-- Vigilados
--
-- Un addon NO puede cambiarte el objetivo: TargetUnit esta protegida
-- desde 2.0. Por eso cada fila es un SecureActionButton con una macro
-- /targetexact: al pincharla el propio cliente te selecciona (funciona
-- incluso en combate) y nosotros detectamos el cambio de objetivo para
-- lanzar la consulta sola.
--
-- Los atributos de un marco seguro no se pueden tocar en combate, asi
-- que la lista se reconstruye al salir de combate si hiciera falta.
------------------------------------------------------------

NC.Watch = {
    pendingItem = nil,   -- objeto cargado en el ojo
    fromClick   = false, -- el cambio de objetivo lo hemos provocado nosotros
    dirty       = false, -- hay que reconstruir al salir de combate
}

local frame, scroll, content
local rows = {}
local ROW_H = 26

local MARK = {
    yes  = "Interface\\RaidFrame\\ReadyCheck-NotReady",  -- lo tiene -> rojo
    no   = "Interface\\RaidFrame\\ReadyCheck-Ready",     -- no lo tiene -> verde
    sold = "Interface\\RaidFrame\\ReadyCheck-Waiting",   -- vendido -> amarillo
}

------------------------------------------------------------
local function List()
    NC.cdb.watch = NC.cdb.watch or {}
    return NC.cdb.watch
end

function NC.Watch:Count()
    return table.getn(List())
end

function NC.Watch:Has(name)
    for _, n in ipairs(List()) do
        if n == name then return true end
    end
    return false
end

------------------------------------------------------------
-- Reglas de validacion
--   1. Debes estar en grupo o banda para poder añadir.
--   2. El objetivo debe ser jugador y estar en tu grupo o banda.
-- Con esto no se puede añadir a un enemigo ni a alguien de fuera, y de
-- paso el .player iteminfo (que exige misma instancia) tiene sentido.
------------------------------------------------------------
function NC.Watch:InGroup()
    local raid = (GetNumRaidMembers and GetNumRaidMembers()) or 0
    local party = (GetNumPartyMembers and GetNumPartyMembers()) or 0
    return raid > 0 or party > 0
end

-- ¿el nombre pertenece a tu grupo o banda ahora mismo?
function NC.Watch:IsGroupMember(name)
    if not name then return false end
    if name == UnitName("player") then return false end

    local raid = (GetNumRaidMembers and GetNumRaidMembers()) or 0
    if raid > 0 then
        for i = 1, raid do
            if GetRaidRosterInfo(i) == name then return true end
        end
        return false
    end

    local party = (GetNumPartyMembers and GetNumPartyMembers()) or 0
    for i = 1, party do
        if UnitName("party" .. i) == name then return true end
    end
    return false
end

function NC.Watch:Add(name)
    if not name or name == "" then return end

    if not self:InGroup() then
        NC.Warn("Tienes que estar en un grupo o banda para añadir vigilados.")
        return
    end
    if not self:IsGroupMember(name) then
        NC.Warn(name .. " no está en tu grupo ni en tu banda.")
        return
    end
    if self:Has(name) then
        NC.Print(name .. " ya estaba en la lista.")
        return
    end
    table.insert(List(), name)
    NC.Print("Vigilado añadido: " .. COL.accent .. name .. COL.r
        .. "  (" .. self:Count() .. " en total)")
    self:Refresh()
    self:Show()
end

function NC.Watch:AddRaid()
    if not self:InGroup() then
        NC.Warn("Tienes que estar en un grupo o banda para añadir vigilados.")
        return
    end
    local n = GetNumRaidMembers and GetNumRaidMembers() or 0
    local added = 0
    if n > 0 then
        for i = 1, n do
            local nm = GetRaidRosterInfo(i)
            if nm and nm ~= UnitName("player") and not self:Has(nm) then
                table.insert(List(), nm)
                added = added + 1
            end
        end
    else
        local p = GetNumPartyMembers and GetNumPartyMembers() or 0
        for i = 1, p do
            local nm = UnitName("party" .. i)
            if nm and not self:Has(nm) then
                table.insert(List(), nm)
                added = added + 1
            end
        end
    end

    if added == 0 then
        NC.Print("No he encontrado a nadie nuevo que añadir.")
    else
        NC.Print("Añadidos " .. added .. " vigilados (" .. self:Count() .. " en total).")
        self:Refresh()
        self:Show()
    end
end

function NC.Watch:Remove(name)
    local l = List()
    for i, n in ipairs(l) do
        if n == name then
            table.remove(l, i)
            break
        end
    end
    self:Refresh()
end

function NC.Watch:Clear()
    local l = List()
    while table.getn(l) > 0 do table.remove(l) end
    NC.Print("Lista de vigilados vaciada.")
    self:Refresh()
end

------------------------------------------------------------
local function ResultFor(name, itemID)
    if not itemID then return nil end
    local t = NC.Results[name]
    return t and t[itemID]
end

local function GetRow(i)
    if rows[i] then return rows[i] end

    local row = CreateFrame("Button", "NaerControlWatchRow" .. i, content,
                            "SecureActionButtonTemplate")
    row:SetHeight(ROW_H)
    row:SetWidth(230)
    row:RegisterForClicks("LeftButtonUp")

    local bg = row:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(1, 1, 1, (i % 2 == 1) and 0.06 or 0)
    row.bg = bg

    local hl = row:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
    hl:SetBlendMode("ADD")

    row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.label:SetPoint("LEFT", 8, 0)
    row.label:SetJustifyH("LEFT")

    row.mark = row:CreateTexture(nil, "OVERLAY")
    row.mark:SetWidth(16)
    row.mark:SetHeight(16)
    row.mark:SetPoint("RIGHT", -26, 0)
    row.mark:Hide()

    row.del = CreateFrame("Button", nil, row)
    row.del:SetWidth(16)
    row.del:SetHeight(16)
    row.del:SetPoint("RIGHT", -4, 0)
    row.del:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
    row.del:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
    row.del:SetScript("OnClick", function(self)
        NC.Watch:Remove(row.playerName)
    end)
    row.del:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Quitar de vigilados")
        GameTooltip:Show()
    end)
    row.del:SetScript("OnLeave", function() GameTooltip:Hide() end)

    row:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.playerName or "Vigilado")
        GameTooltip:AddLine("Rojo: lo tiene", 1, 0.4, 0.4)
        GameTooltip:AddLine("Naranja: vendido", 1, 0.6, 0.2)
        GameTooltip:AddLine("Verde: no lo tiene", 0.4, 1, 0.4)
        GameTooltip:AddLine("Clic: seleccionar", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- PreClick no es codigo protegido: marcamos que el cambio de objetivo
    -- es nuestro para poder encadenar la consulta.
    row:SetScript("PreClick", function(self)
        NC.Watch.fromClick = true
    end)

    rows[i] = row
    return row
end

------------------------------------------------------------
local function BuildFrame()
    if frame then return end

    frame = CreateFrame("Frame", "NaerControlWatchFrame", UIParent)
    frame:SetWidth(270)
    frame:SetHeight(340)
    frame:SetPoint("CENTER", UIParent, "CENTER", 320, 0)
    frame:SetFrameStrata("HIGH")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x, y = self:GetCenter()
        local px, py = UIParent:GetCenter()
        if x and px then NC.cdb.watchX, NC.cdb.watchY = x - px, y - py end
    end)
    frame:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    frame:Hide()
    tinsert(UISpecialFrames, "NaerControlWatchFrame")

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 16, -14)
    title:SetText("Vigilados")
    title:SetTextColor(0.35, 0.8, 1)
    frame.title = title

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    frame.info = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.info:SetPoint("TOPLEFT", 16, -32)
    frame.info:SetPoint("TOPRIGHT", -16, -32)
    frame.info:SetJustifyH("LEFT")
    frame.info:SetTextColor(0.65, 0.65, 0.65)

    -- campo propio para enlazar el objeto a comprobar (independiente del ojo)
    local itemLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    itemLabel:SetPoint("TOPLEFT", 16, -60)
    itemLabel:SetText("Objeto:")
    itemLabel:SetTextColor(0.8, 0.8, 0.8)

    frame.itemBox = CreateFrame("EditBox", nil, frame)
    frame.itemBox:SetPoint("LEFT", itemLabel, "RIGHT", 8, 0)
    frame.itemBox:SetWidth(150)
    frame.itemBox:SetHeight(20)
    frame.itemBox:SetFontObject("ChatFontNormal")
    frame.itemBox:SetAutoFocus(false)
    frame.itemBox:SetMaxLetters(250)
    frame.itemBox:SetTextInsets(4, 4, 0, 0)
    frame.itemBox:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 8,
        insets   = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    frame.itemBox:SetBackdropColor(0, 0, 0, 0.6)
    frame.itemBox:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    frame.itemBox:SetScript("OnEnterPressed", function(self)
        NC.Watch:SetItemFromText(self:GetText())
        self:ClearFocus()
    end)
    frame.itemBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    NC.RegisterLinkTarget(frame.itemBox)

    local hint = frame.itemBox:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hint:SetPoint("LEFT", 5, 0)
    hint:SetText("ID o Mayús+clic")
    hint:SetTextColor(0.5, 0.5, 0.5)
    frame.itemBox:SetScript("OnTextChanged", function(self)
        if self:GetText() == "" then hint:Show() else hint:Hide() end
    end)

    scroll, content = NC.CreateScroll(frame)
    scroll:SetPoint("TOPLEFT", 14, -86)
    scroll:SetPoint("BOTTOMRIGHT", -32, 64)
    content:SetWidth(230)
    scroll:SetScript("OnSizeChanged", function(_, w) if content then content:SetWidth(w or 1) end end)

    local addBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    addBtn:SetWidth(110)
    addBtn:SetHeight(22)
    addBtn:SetPoint("BOTTOMLEFT", 16, 38)
    addBtn:SetText("Añadir objetivo")
    addBtn:SetScript("OnClick", function()
        local t = UnitExists("target") and UnitIsPlayer("target") and UnitName("target")
        if t then NC.Watch:Add(t) else NC.Print("No tienes a ningún jugador seleccionado.") end
    end)

    local raidBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    raidBtn:SetWidth(110)
    raidBtn:SetHeight(22)
    raidBtn:SetPoint("BOTTOMRIGHT", -16, 38)
    raidBtn:SetText("Añadir banda")
    raidBtn:SetScript("OnClick", function() NC.Watch:AddRaid() end)
    frame.raidBtn = raidBtn

    -- Boton "Siguiente": selecciona al proximo vigilado sin comprobar y
    -- lanza su consulta. Es un boton SEGURO porque cambia el objetivo;
    -- solo funciona pulsado por el usuario (el cliente bloquea hacerlo
    -- desde codigo). Su macro se actualiza en cada Refresh.
    frame.nextBtn = CreateFrame("Button", "NaerControlWatchNext", frame,
                                "SecureActionButtonTemplate,UIPanelButtonTemplate")
    frame.nextBtn:SetPoint("BOTTOMLEFT", 16, 12)
    frame.nextBtn:SetPoint("BOTTOMRIGHT", -16, 12)
    frame.nextBtn:SetHeight(24)
    frame.nextBtn:SetText("Siguiente")
    frame.nextBtn:RegisterForClicks("LeftButtonUp")
    frame.nextBtn:SetScript("PreClick", function()
        NC.Watch.fromClick = true
    end)

    -- Tema: título con acento, borde con acento en Moderno, y skin de
    -- botones/caja según el tema.
    if NC.RegisterThemeable then
        NC.RegisterThemeable(function(t)
            local ac = (t and t.accent) or {0.35, 0.8, 1}
            title:SetTextColor(ac[1], ac[2], ac[3])
            if t and t.name == "modern" then
                frame:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.9)
            else
                frame:SetBackdropBorderColor(1, 1, 1, 1)
            end
        end)
    end
    if NC.SkinButton then
        NC.SkinButton(addBtn); NC.SkinButton(raidBtn); NC.SkinButton(frame.nextBtn)
    end
    if NC.SkinEditBox then NC.SkinEditBox(frame.itemBox) end
end

------------------------------------------------------------
function NC.Watch:Refresh()
    if not frame then return end

    local l = List()
    local itemID = self.pendingItem

    if InCombatLockdown() then
        -- no se pueden tocar atributos seguros en combate
        self.dirty = true
        frame.info:SetText("En combate: la lista se actualizará al salir.")
        return
    end
    self.dirty = false

    if itemID then
        local name = NC.ItemName(itemID)
        frame.info:SetText("Comprobando: " .. name .. "\nPincha un nombre, o usa Siguiente para ir en orden.")
    else
        frame.info:SetText("Enlaza un objeto arriba (o cárgalo en el ojo) para empezar.")
    end

    if table.getn(l) == 0 then
        frame.info:SetText("Añade un objetivo y carga un objeto para comprobar.")
    end
    if frame.title then frame.title:SetText("Vigilados (" .. table.getn(l) .. ")") end
    if frame.raidBtn then
        NC.SetButtonEnabled(frame.raidBtn, NC.Watch:InGroup())
    end

    for _, r in ipairs(rows) do r:Hide() end

    local siguiente
    for i, name in ipairs(l) do
        local row = GetRow(i)
        row.playerName = name
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(i - 1) * ROW_H)
        row:SetPoint("RIGHT", content, "RIGHT", 0, 0)
        row:SetAttribute("type", "macro")
        row:SetAttribute("macrotext", "/targetexact " .. name)
        row:Show()

        local info = ResultFor(name, itemID)
        if info and info.state == "sold" then
            row.label:SetText(name .. "  |cffff8800(vendido)|r")
            row.label:SetTextColor(1, 0.5, 0)
            row.mark:SetTexture(MARK.sold)
            row.mark:Show()
        elseif info and info.state == "yes" then
            row.label:SetText(name)
            row.label:SetTextColor(1, 0.4, 0.4)
            row.mark:SetTexture(MARK.yes)
            row.mark:Show()
        elseif info and info.state == "no" then
            row.label:SetText(name)
            row.label:SetTextColor(0.4, 1, 0.4)
            row.mark:SetTexture(MARK.no)
            row.mark:Show()
        else
            row.label:SetText(name)
            row.label:SetTextColor(1, 1, 1)
            row.mark:Hide()
            if not siguiente and itemID then siguiente = row end
        end
    end

    -- resalta el siguiente por comprobar
    if siguiente then
        siguiente.label:SetTextColor(1, 0.82, 0)
        siguiente.label:SetText("> " .. siguiente.playerName)
    end

    -- boton "Siguiente": macro segura hacia el proximo pendiente
    if frame.nextBtn then
        if siguiente and itemID then
            frame.nextBtn:SetAttribute("type", "macro")
            frame.nextBtn:SetAttribute("macrotext", "/targetexact " .. siguiente.playerName)
            frame.nextBtn:SetText("Siguiente: " .. siguiente.playerName)
            NC.SetButtonEnabled(frame.nextBtn, true)
        else
            frame.nextBtn:SetAttribute("macrotext", "")
            if not itemID then
                frame.nextBtn:SetText("Carga un objeto primero")
            else
                frame.nextBtn:SetText("Todos comprobados")
            end
            NC.SetButtonEnabled(frame.nextBtn, false)
        end
    end

    content:SetHeight(math.max(1, table.getn(l) * ROW_H))
end

-- Enlazar objeto desde el campo de texto propio de la ventana
function NC.Watch:SetItemFromText(text)
    local ok, id = NC.ValidateInput("item", text or "")
    if not ok then
        NC.Warn(id)
        return
    end
    self.pendingItem = tonumber(id)
    if frame and frame.itemBox then frame.itemBox:SetText("") end
    self:Refresh()
    NC.Print("Vigilados: comprobando " .. NC.ItemName(self.pendingItem))
end

function NC.Watch:Show()
    BuildFrame()
    if NC.cdb.watchX then
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", UIParent, "CENTER", NC.cdb.watchX, NC.cdb.watchY)
    end
    self:Refresh()
    frame:Show()
end

function NC.Watch:IsShown()
    return frame and frame:IsShown()
end

function NC.Watch:Toggle()
    BuildFrame()
    if frame:IsShown() then frame:Hide() else self:Show() end
end

------------------------------------------------------------
-- Encadenado: hemos pinchado una fila -> el cliente cambia el objetivo
-- -> aqui lanzamos la consulta del objeto cargado.
------------------------------------------------------------
function NC.Watch:OnTargetChanged()
    if not self.fromClick then
        self:Refresh()
        return
    end
    self.fromClick = false

    local itemID = self.pendingItem
    if not itemID then
        self:Refresh()
        return
    end

    local target = NC.GetValidTarget()
    if target and self:Has(target) then
        NC.Scanner:AskItem(itemID, nil)
    end
    self:Refresh()
end

function NC.Watch:OnCombatEnd()
    if self.dirty then self:Refresh() end
end
