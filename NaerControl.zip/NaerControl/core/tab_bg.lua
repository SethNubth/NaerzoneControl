local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña "Campos de Batalla" (render = "bg").
-- Tarjetas: Aleatorio Twinks / Puntuado / Estado de cola / JcJ / Historial.
-- Los botones de unión respetan el límite global (2/10s) y muestran "Espera Ns".
------------------------------------------------------------

local HONOR_CAP, ARENA_CAP = 75000, 5000

local panel
local statusFS
local honorBar, arenaBar, todayFS, weekFS, last30FS
local histCard, histChild, totalCells
local histRows = {}
local HIST_COLS = { date = 4, honor = 96, kills = 172, wins = 232, losses = 300, wr = 372 }
local joinButtons = {}
local allButtons = {}
local prevConfirm = false

local function run(cmd) if NC.Send then NC.Send(cmd) end end
local function playerLevel() return (UnitLevel and UnitLevel("player")) or 0 end

local function fmtTime(s)
    s = math.floor(s or 0); if s < 0 then s = 0 end
    return string.format("%d:%02d", math.floor(s / 60), s - math.floor(s / 60) * 60)
end

local function winrate(d)
    local g = (d.wins or 0) + (d.losses or 0)
    if g <= 0 then return "-" end
    return math.floor((d.wins or 0) / g * 100 + 0.5) .. "%"
end

-- Traducción de los nombres de cola que manda el servidor (en inglés).
local BG_QUEUE_ES = {
    ["Random Battleground"] = "Campo de Batalla aleatorio",
    ["Rated Battleground"]  = "Campo de Batalla puntuado",
}
local function trBG(name) return (name and BG_QUEUE_ES[name]) or name or "?" end

-- Comprueba el estado nativo (índices FIJOS: GetMaxBattlefieldID devuelve 0 en
-- este core, así que no sirve para acotar). Si el estado nativo desaparece
-- (has salido de la cola o entrado a la BG), limpia el aviso de cola del addon.
local function checkNativeQueue()
    local nowInQ = false
    for i = 1, 2 do
        local st = GetBattlefieldStatus(i)
        if st and st ~= "none" then nowInQ = true end
    end
    if NC._prevInQ and not nowInQ and not NC._bgTest then
        NC._bgQueue = nil
    end
    NC._prevInQ = nowInQ
end

-- Este core NO usa la cola nativa para la ESPERA: la anuncia por chat.
-- Capturamos esos mensajes y los guardamos en NC._bgQueue.
do
    local cap = CreateFrame("Frame")
    cap:RegisterEvent("CHAT_MSG_SYSTEM")
    cap:RegisterEvent("CHAT_MSG_BG_SYSTEM_NEUTRAL")
    cap:RegisterEvent("CHAT_MSG_BG_SYSTEM_ALLIANCE")
    cap:RegisterEvent("CHAT_MSG_BG_SYSTEM_HORDE")
    cap:RegisterEvent("UPDATE_BATTLEFIELD_STATUS")
    cap:SetScript("OnEvent", function(_, event, msg)
        if event == "UPDATE_BATTLEFIELD_STATUS" then
            checkNativeQueue()
            if NC.RefreshBGStatus then NC.RefreshBGStatus() end
            return
        end
        if type(msg) ~= "string" then return end
        if NC._bgCapDebug then NC.Print("|cff888888[cap " .. event .. "]|r " .. msg) end
        if NC.StripColors then msg = NC.StripColors(msg) end
        local touched = false
        local name, mn, mx = string.match(msg, "Queue status for (.-)%s*%(Lvl:%s*(%d+)%s*to%s*(%d+)%)")
        if name then
            NC._bgQueue = NC._bgQueue or {}
            NC._bgQueue.name, NC._bgQueue.minL, NC._bgQueue.maxL = name, mn, mx
            touched = true
        end
        local aq, an = string.match(msg, "Queued alliances?:%s*(%d+)%s*%(Need at least%s*(%d+)")
        if aq then
            NC._bgQueue = NC._bgQueue or {}
            NC._bgQueue.allyQ, NC._bgQueue.allyNeed = aq, an
            touched = true
        end
        local hq, hn = string.match(msg, "Queued hordes?:%s*(%d+)%s*%(Need at least%s*(%d+)")
        if hq then
            NC._bgQueue = NC._bgQueue or {}
            NC._bgQueue.hordeQ, NC._bgQueue.hordeNeed = hq, hn
            touched = true
        end
        if touched then
            local now = GetTime and GetTime() or 0
            NC._bgQueue.at = now
            NC._bgQueue.startAt = NC._bgQueue.startAt or now   -- inicio de la cola (para el cronómetro)
            if NC.RefreshBGStatus then NC.RefreshBGStatus() end
        end
    end)
end

-- ---------- helpers de UI ----------
local function makeCard(parent, titleText, y, h)
    local c = CreateFrame("Frame", nil, parent)
    c:SetPoint("TOPLEFT", 6, y)
    c:SetPoint("RIGHT", parent, "RIGHT", -6, 0)
    c:SetHeight(h)
    c:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1, insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    local accent = c:CreateTexture(nil, "ARTWORK")
    accent:SetPoint("TOPLEFT", 8, -8); accent:SetSize(3, 16)
    local t = c:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOPLEFT", 16, -6)
    local function skin(th)
        c:SetBackdropColor(th.cardBg[1], th.cardBg[2], th.cardBg[3], th.cardBg[4] or 1)
        c:SetBackdropBorderColor(th.cardBorder[1], th.cardBorder[2], th.cardBorder[3], th.cardBorder[4] or 1)
        accent:SetTexture(th.accent[1], th.accent[2], th.accent[3], 1)
        t:SetText("|cff" .. (NC.ThemeHex and NC.ThemeHex("accent") or "7ec8e3") .. titleText .. "|r")
    end
    if NC.RegisterThemeable then NC.RegisterThemeable(skin) else skin(NC.Theme or NC.THEMES.modern) end
    return c
end

local function setBtnEnabled(b, on)
    b._enabled = on
    if on then if b.Enable then b:Enable() end else if b.Disable then b:Disable() end end
    if b._ncApply then b._ncApply() end   -- re-aplica el skin del tema (enabled/disabled)
end

local function styledButton(parent, label, x, y, w, h, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, h or 26); b:SetPoint("TOPLEFT", x, y)
    b:SetText(label)
    b.fs = b:GetFontString()
    local glow = b:CreateTexture(nil, "OVERLAY")
    glow:SetAllPoints(); glow:SetTexture(1, 1, 1); glow:SetBlendMode("ADD"); glow:SetAlpha(0)
    b.glow = glow; b._hover = false
    b:HookScript("OnEnter", function(s) s._hover = true end)
    b:HookScript("OnLeave", function(s) s._hover = false; if s.glow then s.glow:SetAlpha(0) end end)
    b:SetScript("OnClick", function() if b._enabled and onClick then onClick() end end)
    b._enabled = true
    if NC.SkinButton then NC.SkinButton(b) end   -- alterna Blizzard(classic) / oscuro(modern)
    allButtons[#allButtons + 1] = b
    return b
end

local function makeBar(parent, label, x, y, _w, cap, r, g, bl)
    local bar = CreateFrame("Frame", nil, parent)
    bar:SetHeight(20); bar:SetPoint("TOPLEFT", x, y)
    bar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1, insets = { left = 1, right = 1, top = 1, bottom = 1 } })
    bar:SetBackdropColor(0.08, 0.08, 0.10, 0.95); bar:SetBackdropBorderColor(0, 0, 0, 0.8)
    local fill = bar:CreateTexture(nil, "ARTWORK")
    fill:SetPoint("TOPLEFT", 2, -2); fill:SetPoint("BOTTOMLEFT", 2, 2); fill:SetTexture(r, g, bl)
    bar.fill = fill; bar._cap = cap; bar._value = 0
    local function apply(self)
        local cap2 = self._cap or 1
        local frac = (cap2 > 0) and (self._value / cap2) or 0
        if frac > 1 then frac = 1 elseif frac < 0 then frac = 0 end
        local usable = (self:GetWidth() or 0) - 4
        if usable < 1 then self.fill:Hide(); return end
        local fw = usable * frac
        if fw < 1 then self.fill:Hide() else self.fill:SetWidth(fw); self.fill:Show() end
    end
    bar:SetScript("OnSizeChanged", function(self) apply(self) end)
    bar:SetScript("OnShow", function(self) apply(self) end)
    bar.SetBarValue = function(self, v) self._value = v or 0; apply(self) end
    local lfs = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    lfs:SetPoint("LEFT", 6, 0); lfs:SetText(label)
    local vfs = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    vfs:SetPoint("RIGHT", -6, 0); bar.valueFS = vfs
    return bar
end

-- ---------- refrescos ----------
local function updateButtons()
    local wait = (NC.SendWaitTime and NC.SendWaitTime()) or 0
    local lvl = playerLevel()
    local lvlOK = (lvl >= 10 and lvl <= 79)
    for _, e in ipairs(joinButtons) do
        local waiting = wait > 0.1
        local blocked = waiting or (e.gated and not lvlOK)
        e.btn:SetText(waiting and ("Espera " .. math.ceil(wait) .. "s") or e.label)
        setBtnEnabled(e.btn, not blocked)
    end
end

local function refreshStatus()
    if not statusFS then return end
    if NC._bgTest then
        -- demo: inyecta una cola de ejemplo y la muestra por el camino normal
        NC._bgQueue = NC._bgQueue or { name = "Random Battleground", minL = "80",
            allyQ = "5", allyNeed = "5", hordeQ = "10", hordeNeed = "0",
            startAt = (GetTime and GetTime() or 0) }
    end
    if UnitInBattleground and UnitInBattleground("player") and not NC._bgTest then NC._bgQueue = nil end
    panel._alert = false
    local q = NC._bgQueue
    if q and q.name then
        local l1 = "|cffffd100En cola:|r " .. trBG(q.name)
        if q.minL then l1 = l1 .. "  |cff888888(Nivel " .. q.minL .. ")|r" end
        local parts = {}
        if q.allyQ then
            parts[#parts + 1] = "|cff4fc3f7Alianza:|r " .. q.allyQ ..
                (q.allyNeed and ("  |cff888888(faltan " .. q.allyNeed .. ")|r") or "")
        end
        if q.hordeQ then
            parts[#parts + 1] = "|cffff6060Horda:|r " .. q.hordeQ ..
                (q.hordeNeed and ("  |cff888888(faltan " .. q.hordeNeed .. ")|r") or "")
        end
        local out = l1
        if #parts > 0 then out = out .. "\n" .. table.concat(parts, "    ") end
        if q.startAt then
            out = out .. "\n|cff888888Tiempo en cola:|r " .. fmtTime((GetTime and GetTime() or 0) - q.startAt)
        end
        statusFS:SetText(out)
    else
        statusFS:SetText("|cff888888No estás en ninguna cola.|r")
    end
end
NC.RefreshBGStatus = function() refreshStatus() end

local function refreshPvP()
    if not honorBar then return end
    local honor = (GetHonorCurrency and GetHonorCurrency()) or 0
    local arena = (GetArenaCurrency and GetArenaCurrency()) or 0
    honorBar:SetBarValue(honor); honorBar.valueFS:SetText(honor .. " / " .. HONOR_CAP)
    arenaBar:SetBarValue(arena); arenaBar.valueFS:SetText(arena .. " / " .. ARENA_CAP)
    local hk, todayHonor = 0, 0
    if GetPVPSessionStats then local a, b = GetPVPSessionStats(); hk, todayHonor = a or 0, b or 0 end
    todayFS:SetText("|cff888888Hoy:|r " .. hk .. " kills · " .. todayHonor .. " honor")
    if weekFS then
        local whk, whonor = 0, 0
        if GetPVPThisWeekStats then local a, b = GetPVPThisWeekStats(); whk, whonor = a or 0, b or 0 end
        weekFS:SetText("|cff888888Semana:|r " .. whk .. " kills · " .. whonor .. " honor")
    end
    if last30FS then
        local sh, sk, sw, sl = 0, 0, 0, 0
        local tday = NC.PvP and NC.PvP.GetToday and NC.PvP.GetToday()
        if tday then sh=sh+(tday.honor or 0); sk=sk+(tday.kills or 0); sw=sw+(tday.wins or 0); sl=sl+(tday.losses or 0) end
        local days = (NC.PvP and NC.PvP.GetDays and NC.PvP.GetDays()) or {}
        for k = 1, #days do
            sh=sh+(days[k].honor or 0); sk=sk+(days[k].kills or 0)
            sw=sw+(days[k].wins or 0); sl=sl+(days[k].losses or 0)
        end
        local g = sw + sl
        local wrTxt = (g > 0) and ("  |cff9aa0a8(" .. math.floor(sw / g * 100 + 0.5) .. "% vic)|r") or ""
        last30FS:SetText("|cff888888Últimos 30 días:|r " .. sh .. " honor · " .. sk .. " kills · |cff4fdf4f" .. sw .. " ganadas|r · |cffff6060" .. sl .. " perdidas|r" .. wrTxt)
    end
end

-- ---------- historial (tabla con scroll) ----------
local function getHistRow(i)
    local r = histRows[i]
    if not r then
        r = CreateFrame("Frame", nil, histChild)
        r:SetHeight(16)
        r:SetPoint("TOPLEFT", 0, -(i - 1) * 17)
        r:SetPoint("RIGHT", histChild, "RIGHT", 0, 0)
        local stripe = r:CreateTexture(nil, "BACKGROUND")
        stripe:SetAllPoints(); stripe:SetTexture(1, 1, 1); stripe:SetVertexColor(1, 1, 1, 0)
        r.stripe = stripe
        r.cells = {}
        for key, x in pairs(HIST_COLS) do
            local fs = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            fs:SetPoint("LEFT", x, 0)
            r.cells[key] = fs
        end
        histRows[i] = r
    end
    r:Show()
    return r
end

local function fillCells(cells, dateText, d, color)
    cells.date:SetText(dateText)
    cells.honor:SetText((color or "|cffffd100") .. (d.honor or 0) .. "|r")
    cells.kills:SetText((color or "|cffffffff") .. (d.kills or 0) .. "|r")
    cells.wins:SetText((color or "|cff4fdf4f") .. (d.wins or 0) .. "|r")
    cells.losses:SetText((color or "|cffff6060") .. (d.losses or 0) .. "|r")
    cells.wr:SetText((color or "|cff9aa0a8") .. winrate(d) .. "|r")
end

local function refreshHistory()
    if not histChild then return end
    for _, r in ipairs(histRows) do r:Hide() end
    if not NC.PvP then return end
    local i = 0
    local t = NC.PvP.GetToday and NC.PvP.GetToday()
    if t then
        i = i + 1; local r = getHistRow(i)
        local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
        r.stripe:SetVertexColor(ac[1], ac[2], ac[3], 0.10)
        fillCells(r.cells, "|cffffd100Hoy|r", t)
    end
    local days = (NC.PvP.GetDays and NC.PvP.GetDays()) or {}
    for k = 1, #days do
        i = i + 1; local r = getHistRow(i)
        r.stripe:SetVertexColor(1, 1, 1, (i % 2 == 0) and 0.05 or 0)
        fillCells(r.cells, "|cff9aa0a8" .. (days[k].date or "?") .. "|r", days[k])
    end
    if #days == 0 then
        i = i + 1; local r = getHistRow(i)
        r.stripe:SetVertexColor(1, 1, 1, 0)
        r.cells.date:SetText("|cff707070(sin días anteriores todavía)|r")
        r.cells.honor:SetText(""); r.cells.kills:SetText("")
        r.cells.wins:SetText(""); r.cells.losses:SetText(""); r.cells.wr:SetText("")
    end
    histChild:SetHeight(i * 17 + 2)
    local tot = NC.PvP.GetTotals and NC.PvP.GetTotals()
    if tot and totalCells then
        local hex = (NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3"
        fillCells(totalCells, "|cff" .. hex .. "Totales|r", tot, "|cff" .. hex)
    end
end
NC.RefreshBGHistory = function() refreshHistory() end

-- popup de confirmación para limpiar
-- Blizzard owns this global. Register only our dialog; never reassign it.
StaticPopupDialogs["NAERCONTROL_PVP_CLEAR"] = {
    text = "¿Borrar TODO el historial de JcJ de este personaje?",
    button1 = "Sí, borrar", button2 = "Cancelar",
    OnAccept = function()
        if NC.PvP and NC.PvP.Clear then NC.PvP.Clear() end
        refreshHistory()
        if NC.SetStatus then NC.SetStatus("Historial de JcJ borrado.") end
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

-- ---------- construcción ----------
local function build()
    panel = CreateFrame("Frame", nil, NC.Content)
    panel:SetAllPoints(NC.Content)
    panel._ncSkip = true   -- esta pestaña ya tiene su propio estilo; SkinPanel la ignora

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    title:SetPoint("TOPLEFT", 4, -2); title:SetText("|cffffffffCampos de Batalla|r")

    -- Aleatorio
    local cA = makeCard(panel, "Campo de Batalla Aleatorio Twinks", -30, 68)
    local aNote = cA:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    aNote:SetPoint("TOPRIGHT", -10, -12); aNote:SetText("Nivel 10-79")
    local rSolo  = styledButton(cA, "Solo",  16, -34, 130, 26, function() run(".player joinrandombg") end)
    local rGroup = styledButton(cA, "Grupo", 156, -34, 130, 26, function() run(".player joinrandombg group") end)

    -- Puntuado
    local cP = makeCard(panel, "Campo de Batalla Puntuado", -102, 68)
    local pSolo  = styledButton(cP, "Solo",  16, -34, 130, 26, function() run(".player joinratedbg") end)
    local pGroup = styledButton(cP, "Grupo", 156, -34, 130, 26, function() run(".player joinratedbg group") end)

    joinButtons = {
        { btn = rSolo,  gated = true,  label = "Solo"  },
        { btn = rGroup, gated = true,  label = "Grupo" },
        { btn = pSolo,  gated = false, label = "Solo"  },
        { btn = pGroup, gated = false, label = "Grupo" },
    }

    -- Estado de cola
    local cQ = makeCard(panel, "Estado de cola", -174, 84)
    statusFS = cQ:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    statusFS:SetPoint("TOPLEFT", 16, -28); statusFS:SetPoint("BOTTOMRIGHT", cQ, "BOTTOMRIGHT", -12, 6)
    statusFS:SetJustifyH("LEFT"); statusFS:SetJustifyV("MIDDLE"); statusFS:SetSpacing(4)

    -- JcJ
    local cV = makeCard(panel, "JcJ", -266, 136)
    honorBar = makeBar(cV, "Honor", 16, -34, 300, HONOR_CAP, 0.95, 0.70, 0.20)
    honorBar:SetPoint("RIGHT", cV, "RIGHT", -16, 0)
    arenaBar = makeBar(cV, "Arena", 16, -58, 300, ARENA_CAP, 0.62, 0.42, 0.88)
    arenaBar:SetPoint("RIGHT", cV, "RIGHT", -16, 0)
    todayFS = cV:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    todayFS:SetPoint("TOPLEFT", 16, -84)
    weekFS = cV:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    weekFS:SetPoint("TOPLEFT", 16, -100)
    last30FS = cV:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    last30FS:SetPoint("TOPLEFT", 16, -116)

    -- Historial (tabla con scroll + totales fijos)
    local cH = makeCard(panel, "Historial JcJ", -410, 214)
    histCard = cH
    local clearBtn = styledButton(cH, "Limpiar", 0, 0, 80, 20, function() StaticPopup_Show("NAERCONTROL_PVP_CLEAR") end)
    clearBtn:ClearAllPoints(); clearBtn:SetPoint("TOPRIGHT", cH, "TOPRIGHT", -10, -8)
    local hdr = { date = "Fecha", honor = "Honor", kills = "Kills", wins = "Ganadas", losses = "Perdidas", wr = "%Vic" }
    for key, x in pairs(HIST_COLS) do
        local h = cH:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        h:SetPoint("TOPLEFT", 12 + x, -30); h:SetText(hdr[key])
    end
    local sep = cH:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOPLEFT", 10, -44); sep:SetPoint("RIGHT", cH, "RIGHT", -10, 0)
    sep:SetHeight(1); sep:SetTexture(0.3, 0.4, 0.5, 0.5)

    local scroll = CreateFrame("ScrollFrame", "NaerControlPvPScroll", cH, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 12, -48)
    scroll:SetPoint("BOTTOMRIGHT", cH, "BOTTOMRIGHT", -30, 28)
    if NC.SkinScrollOf then NC.SkinScrollOf(scroll) end
    histChild = CreateFrame("Frame", nil, scroll)
    histChild:SetSize(10, 10)
    scroll:SetScrollChild(histChild)
    scroll:SetScript("OnSizeChanged", function(_, w) histChild:SetWidth(w or 1) end)

    local tsep = cH:CreateTexture(nil, "ARTWORK")
    tsep:SetPoint("BOTTOMLEFT", 10, 24); tsep:SetPoint("BOTTOMRIGHT", -10, 24)
    tsep:SetHeight(1); tsep:SetTexture(0.3, 0.4, 0.5, 0.5)
    totalCells = {}
    for key, x in pairs(HIST_COLS) do
        local fs = cH:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("BOTTOMLEFT", 12 + x, 6)
        totalCells[key] = fs
    end

    local note = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    note:SetPoint("BOTTOMLEFT", 6, 6); note:SetPoint("RIGHT", panel, "RIGHT", -10, 0)
    note:SetJustifyH("LEFT")
    note:SetText("Unirse no funciona dentro de mazmorras, campos de batalla activos ni Conquista de Invierno.")

    panel:RegisterEvent("UPDATE_BATTLEFIELD_STATUS")
    panel:RegisterEvent("PLAYER_ENTERING_WORLD")
    panel:RegisterEvent("PLAYER_LEVEL_UP")
    panel:SetScript("OnEvent", function() updateButtons(); refreshStatus(); refreshPvP(); refreshHistory() end)
    panel._t, panel._t2 = 0, 0
    panel:SetScript("OnUpdate", function(self, e)
        local modern = (NC.Theme and NC.Theme.name == "modern")
        local a = 0.10 + 0.08 * math.sin(GetTime() * 4)
        for _, b in ipairs(allButtons) do
            if b.glow then b.glow:SetAlpha((modern and b._enabled and b._hover) and a or 0) end
        end
        self._t = self._t + (e or 0)
        if self._t >= 0.2 then self._t = 0; pcall(updateButtons) end
        self._t2 = self._t2 + (e or 0)
        if self._t2 >= 1 then self._t2 = 0; pcall(function() checkNativeQueue(); if self:IsShown() then refreshStatus(); refreshPvP(); refreshHistory() end end) end
    end)
end

function NC.ShowBGView()
    if not panel then build() end
    panel:Show(); NC.Content:Show()
    updateButtons(); refreshStatus(); refreshPvP(); refreshHistory()
end

function NC.HideBGView()
    if panel then panel:Hide() end
end
