local ADDON, NC = ...

local scroll, content
local rows = {}
local noteFS
local activeTab

local ROW_H     = 44   -- fila sin pista
local ROW_H_TIP = 62   -- fila con linea de pista debajo

------------------------------------------------------------
local function BuildView()
    if scroll then return end

    scroll, content = NC.CreateScroll(NC.Content)
    scroll:SetPoint("TOPLEFT", 0, 0)
    scroll:SetPoint("BOTTOMRIGHT", -26, 0)
    content:SetWidth(440)

    noteFS = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    noteFS:SetPoint("TOPLEFT", 6, -6)
    noteFS:SetWidth(430)
    noteFS:SetJustifyH("LEFT")
    noteFS:SetTextColor(1, 0.82, 0)
    noteFS:Hide()

    -- Refresca el bloqueo de los botones de rate segun la cola de envio.
    local lastLocked = nil
    scroll:SetScript("OnUpdate", function(self, elapsed)
        self.acc = (self.acc or 0) + (elapsed or 0)
        if self.acc < 0.2 then return end
        self.acc = 0
        if not NC.XpRates then return end
        local locked = NC.QueueSize() > 0 or (NC.AtRateLimit and NC.AtRateLimit())
        if locked ~= lastLocked then
            lastLocked = locked
            NC.XpRates:RefreshAll()
        end
        -- red de seguridad: re-habilita cuando ni hay cola ni tope
        if not locked then
            NC.XpRates:EnsureEnabled()
        end
    end)
end

------------------------------------------------------------
local function GetRow(i)
    if rows[i] then return rows[i] end

    local row = CreateFrame("Frame", nil, content)
    row:SetWidth(430)
    row:SetHeight(ROW_H)

    if (i % 2) == 1 then
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        bg:SetVertexColor(1, 1, 1, 0.05)
    end

    row.desc = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.desc:SetPoint("TOPLEFT", 10, -9)
    row.desc:SetWidth(170)
    row.desc:SetJustifyH("LEFT")

    row.tip = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.tip:SetPoint("TOPLEFT", 10, -30)
    row.tip:SetPoint("TOPRIGHT", -10, -30)
    row.tip:SetJustifyH("LEFT")
    row.tip:SetTextColor(0.55, 0.55, 0.55)
    row.tip:Hide()

    row.btn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.btn:SetWidth(80)
    row.btn:SetHeight(22)
    row.btn:SetPoint("TOPRIGHT", -10, -8)
    row.btn:SetText("Enviar")

    row.input = CreateFrame("EditBox", nil, row)
    row.input:SetWidth(150)
    row.input:SetHeight(20)
    row.input:SetPoint("RIGHT", row.btn, "LEFT", -10, 0)
    row.input:SetFontObject("ChatFontNormal")
    row.input:SetAutoFocus(false)
    row.input:SetTextInsets(4, 4, 0, 0)
    row.input:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 8,
        insets   = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    row.input:SetBackdropColor(0, 0, 0, 0.6)
    row.input:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)

    row.hint = row.input:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.hint:SetPoint("LEFT", 5, 0)
    row.hint:SetTextColor(0.5, 0.5, 0.5)

    row.input:SetScript("OnTextChanged", function(self)
        if self:GetText() == "" then row.hint:Show() else row.hint:Hide() end
    end)
    row.input:SetScript("OnEscapePressed", function(self)
        self:SetText("")
        self:ClearFocus()
    end)
    row.input:SetScript("OnEnterPressed", function(self)
        if row.Apply then row.Apply() end
        self:ClearFocus()
    end)

    -- permite soltar objetos con Mayus + clic cuando la caja tiene el foco
    NC.RegisterLinkTarget(row.input)

    row.btn:SetScript("OnClick", function()
        if row.Apply then row.Apply() end
    end)

    -- Fila de botones de rate (1-8), para input == "rate". Se crea una vez,
    -- oculta; se muestra solo en las filas de rate.
    row.rateButtons = {}
    local prev
    for v = 1, 8 do
        local b = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        b:SetWidth(30)
        b:SetHeight(22)
        if prev then
            b:SetPoint("LEFT", prev, "RIGHT", 4, 0)
        else
            b:SetPoint("TOPLEFT", 190, -8)
        end
        b:SetText(tostring(v))
        b.rateValue = v
        b:Hide()
        row.rateButtons[v] = b
        if NC.SkinButton then NC.SkinButton(b) end
        prev = b
    end

    rows[i] = row
    return row
end

------------------------------------------------------------
-- Requisitos de nivel
------------------------------------------------------------
local function LevelAllowed(cmd)
    if not cmd.minLevel and not cmd.maxLevel then return true end
    local lvl = UnitLevel("player") or 1
    if cmd.minLevel and lvl < cmd.minLevel then return false end
    if cmd.maxLevel and lvl > cmd.maxLevel then return false end
    return true
end

local function LevelText(cmd)
    if cmd.minLevel and cmd.maxLevel then
        return "Sólo niveles " .. cmd.minLevel .. "-" .. cmd.maxLevel
    elseif cmd.minLevel then
        return "Sólo nivel " .. cmd.minLevel .. " o superior"
    elseif cmd.maxLevel then
        return "Sólo hasta nivel " .. cmd.maxLevel
    end
end

local MAXLETTERS = { number = 10, name = 12, item = 250 }

------------------------------------------------------------
function NC.ShowCommandsView(tab)
    BuildView()
    activeTab = tab
    scroll:Show()

    for _, r in pairs(rows) do r:Hide() end

    local y = -8

    if tab.note then
        -- si esta pestaña tiene rates, mostramos el estado del bonus de finde
        local shown = false
        if NC.XpRates and NC.XpRates.WeekendBonus then
            local active, txt = NC.XpRates:WeekendBonus()
            if txt then
                noteFS:SetText(txt)
                if active then
                    noteFS:SetTextColor(0.4, 1, 0.4)    -- verde: activo
                else
                    noteFS:SetTextColor(1, 0.82, 0)     -- ámbar: informativo
                end
                noteFS:Show()
                y = y - noteFS:GetHeight() - 12
                shown = true
            end
        end
        if not shown then
            noteFS:SetText(tab.note)
            noteFS:SetTextColor(1, 0.82, 0)
            noteFS:Show()
            y = y - noteFS:GetHeight() - 12
        end
    else
        noteFS:Hide()
    end

    if NC.XpRates then NC.XpRates:ClearExtras() end
    for i, cmd in ipairs(tab.commands) do
        local row = GetRow(i)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 0, y)
        row:Show()

        local allowed   = LevelAllowed(cmd)
        local levelNote = LevelText(cmd)

        row.desc:SetText(cmd.desc)
        if allowed then
            row.desc:SetTextColor(1, 1, 1)
            NC.SetButtonEnabled(row.btn, true)
        else
            row.desc:SetTextColor(0.5, 0.5, 0.5)
            NC.SetButtonEnabled(row.btn, false)
        end

        -- linea de pista: motivo del bloqueo, o ayuda de la fila
        local tipText = (not allowed) and levelNote or cmd.tip
        if tipText then
            row:SetHeight(ROW_H_TIP)
            row.tip:SetText(tipText)
            if allowed then
                row.tip:SetTextColor(0.55, 0.55, 0.55)
            else
                row.tip:SetTextColor(1, 0.4, 0.4)
            end
            row.tip:Show()
        else
            row:SetHeight(ROW_H)
            row.tip:Hide()
        end

        if cmd.input == "rateFixed" then
            -- exploración: un único botón fijo, bloqueado (siempre x1)
            row.input:Hide()
            row.hint:Hide()
            row.btn:Hide()
            for _, b in pairs(row.rateButtons) do b:Hide() end
            local fb = row.rateButtons[cmd.fixedValue or 1]
            if fb then
                fb:SetText(tostring(cmd.fixedValue or 1))
                fb:Show()
                fb:Enable()               -- NO Disable (deja de verse opaco)
                fb:SetScript("OnClick", nil)   -- sin acción: es informativo
                fb:LockHighlight()        -- glow dorado, como el rate activo
                if NC.XpRates then NC.XpRates:RegisterExtra(fb) end
            end
        elseif cmd.input == "rate" then
            -- fila de 8 botones; oculta caja y boton Enviar
            row.input:Hide()
            row.hint:Hide()
            row.btn:Hide()
            for v, b in pairs(row.rateButtons) do
                if allowed then
                    b:Show()
                    b:SetScript("OnClick", function()
                        NC.XpRates:SendRate(cmd.rateKey, cmd.cmd, v)
                    end)
                else
                    b:Hide()
                end
            end
            NC.XpRates:Register(cmd.rateKey, row)
            NC.XpRates:Refresh(cmd.rateKey)
        elseif cmd.input == "none" or not allowed then
            row.input:Hide()
            row.hint:Hide()
            row.btn:Show()
            for _, b in pairs(row.rateButtons) do b:Hide() end
            -- Consultar / Rates al máximo: se bloquean con el límite
            if (cmd.ratesRefresh or cmd.ratesMax) and NC.XpRates then
                NC.XpRates:RegisterExtra(row.btn)
            end
        else
            row.input:Show()
            row.btn:Show()
            for _, b in pairs(row.rateButtons) do b:Hide() end
            row.input:SetMaxLetters(MAXLETTERS[cmd.input] or 32)
            row.input:SetText("")
            row.hint:SetText(cmd.hint or "")
            row.hint:Show()
        end

        row.Apply = function()
            if not LevelAllowed(cmd) then
                NC.SetStatus(LevelText(cmd) .. ".", true)
                return
            end
            -- comandos de rate: respetan el limitador (no enviar con cola)
            if (cmd.ratesMax or cmd.ratesRefresh) and NC.QueueSize() > 0 then
                NC.SetStatus("Espera: hay consultas en cola.", true)
                return
            end
            local value = (cmd.input ~= "none") and row.input:GetText() or ""
            local ok, result = NC.ValidateInput(cmd.input, value)
            if not ok then
                NC.SetStatus(result, true)
                return
            end
            local full = cmd.cmd
            if result and result ~= "" then
                full = full .. " " .. result
            end
            if (cmd.ratesMax or cmd.ratesRefresh) and NC.XpRates then
                NC.XpRates:Blink(row.btn, 4)
                NC.Send(full, function()
                    if NC.XpRates then NC.XpRates:StartCooldown(row.btn) end
                end)
            else
                NC.Send(full)
            end
            NC.SetStatus("Enviado: " .. full)

            -- "Rates al máximo" pone kill y quest a 8: refleja el gris al
            -- instante (el servidor lo confirmara con su respuesta).
            if cmd.ratesMax and NC.XpRates then
                NC.XpRates:Set("kill", 8)
                NC.XpRates:Set("quest", 8)
            end
        end

        y = y - (tipText and ROW_H_TIP or ROW_H)
    end

    content:SetHeight(-y + 20)
end

function NC.HideCommandsView()
    if scroll then scroll:Hide() end
end

-- Al subir de nivel se reevaluan los bloqueos si la pestana esta abierta.
function NC.RefreshCommandsView()
    if scroll and scroll:IsShown() and activeTab then
        NC.ShowCommandsView(activeTab)
    end
end
