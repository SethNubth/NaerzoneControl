local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña SoloQ (estilo Campos de batalla): tarjeta del NPC + tracking 5v5:
-- equipo/personal, compañeros y rivales más frecuentes, e historial por día
-- (clic en un día -> partidas de ese día).
------------------------------------------------------------

local WHITE = "Interface\\Buttons\\WHITE8X8"

local SLOT_NAMES = {
    [1]="Cabeza", [2]="Cuello", [3]="Hombros", [5]="Pecho", [6]="Cintura",
    [7]="Piernas", [8]="Pies", [9]="Muñecas", [10]="Manos", [11]="Anillo 1",
    [12]="Anillo 2", [13]="Abalorio 1", [14]="Abalorio 2", [15]="Espalda",
    [16]="Arma principal",
}

local NPC_TEXT = {
    resumen  = "SoloQ te permite entrar en cola de arena por tu cuenta: el sistema crea equipos equilibrados y te busca oponentes automáticamente.\n\nPuntúa usando el slot de arenas 5c5, y pueden participar twinks de nivel 79.\n\nHabla con el NPC en el centro de Ventormenta y Orgrimmar para crear tu equipo de SoloQ (cuesta 40 de oro). Luego únete a la cola con el botón «Unirse a SoloQ» de esta pestaña.",
    cola     = "Al anotarte, entras en una cola donde el sistema busca jugadores con MMR y roles compatibles (si el emparejamiento por roles está activado por el servidor).\n\nEl servidor puede exigir un número mínimo de jugadores en cola antes de empezar a formar grupos (para evitar abusos).\n\nEl rango de búsqueda de MMR se amplía progresivamente cuanto más tiempo en cola lleves. Esto garantiza partidas más rápidas con el tiempo, sin dejar de intentar encontrar enfrentamientos equilibrados.\n\nCuando se encuentran suficientes jugadores compatibles, se forman equipos temporales balanceados por rol siempre que sea posible.\n\nEn horas de poca afluencia, si la espera se alarga, el sistema puede relajar la composición de los equipos (por ejemplo, formar equipos sin sanador) para que puedas jugar igualmente.\n\nEl equipo formado entra en la cola de arena normal, igual que un grupo preformado. El sistema busca un equipo rival con MMR similar, ampliando también el rango de búsqueda hasta encontrar una partida.\n\n¡Una vez que ambos equipos aceptan la invitación, comienza la arena!",
    penal    = "- No aceptar la invitación a la arena cuando aparece: Pérdida de rating + Desertor de BG.\n\n- Abandonar la cola antes de que se forme tu equipo: sin penalización.\n\n- Abandonar la cola o desconectarte después de ser asignado a un equipo preformado: Desertor de BG.\n\n- Si no entran todos los participantes cuando la arena comienza y el servidor está configurado para ello, la partida finaliza de forma prematura. Los que no entraron o abandonaron la cola recibirán una penalización (pérdida de rating + Desertor).\n\nReutilización de la cola:\n\n- Después de anotarte, debes esperar unos minutos antes de poder anotarte de nuevo.\n\n- Este tiempo de espera se elimina automáticamente cuando la arena finaliza, así que si la partida fue rápida puedes volver a anotar inmediatamente.\n\nUna vez dentro de la arena, aplican las mismas reglas que en las arenas normales en cuanto a abandono, desertor y penalizaciones.",
    consejos = "- Crear un equipo: Selecciona la opción en el menú principal. Tiene un coste de oro y un tiempo de espera de 18 horas entre creaciones (anti-spam).\n\n- Unirte a la cola: Selecciona la opción en el menú principal, o usa .player joinarenasoloq desde cualquier zona no restringida.\n\n- Renombrar tu equipo: Si cambias el nombre de tu personaje, la opción \"Renombrar equipo\" aparecerá en el menú principal. Selecciónala para mantener el nombre de tu equipo actualizado.\n\n- Borrar tu equipo: Si quieres empezar de cero, selecciona la opción en el menú principal.\n\n- Hueco 5v5: SoloQ usa tu equipo 5v5 real. Si tienes un equipo 5v5 con más de un miembro, debes abandonarlo para poder usar el sistema.\n\n- Ver cola: Usa \"Comprobar jugadores en cola\" para ver quién más está esperando.\n\n- Ver Top: Selecciona la opción en el menú principal para ver la clasificación.",
}

StaticPopupDialogs["NAERCONTROL_SOLOQ_CLEAR"] = {
    text = "¿Limpiar el historial de SoloQ? (los últimos 30 días y sus partidas)",
    button1 = YES, button2 = NO,
    OnAccept = function() if NC.SoloQ then NC.SoloQ:ClearHistory() end end,
    timeout = 0, whileDead = 1, hideOnEscape = 1, preferredIndex = 3,
}

local panel, joinBtn, reqChip, npcText, topBtn, topOffMsg, clearBtn
local teamFS, teamRateFS, persoRateFS, weekFS, seasonFS, streakFS
local allyRows, enemyRows
local histChild, dayRows, histMsg
allyRows, enemyRows, dayRows = {}, {}, {}

local function accentHex()
    return (NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3"
end

local function makeCard(parent, titleText, y, h, x, w)
    local c = CreateFrame("Frame", nil, parent)
    c:SetPoint("TOPLEFT", x or 6, y)
    if w then c:SetWidth(w) else c:SetPoint("RIGHT", parent, "RIGHT", -6, 0) end
    c:SetHeight(h)
    c:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1,
                    insets = { left = 1, right = 1, top = 1, bottom = 1 } })
    local accent = c:CreateTexture(nil, "ARTWORK")
    accent:SetPoint("TOPLEFT", 8, -8); accent:SetSize(3, 16)
    local t = c:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOPLEFT", 16, -6)
    local function skin(th)
        th = th or NC.Theme or (NC.THEMES and NC.THEMES.classic)
        if not th then return end
        c:SetBackdropColor(th.cardBg[1], th.cardBg[2], th.cardBg[3], th.cardBg[4] or 1)
        c:SetBackdropBorderColor(th.cardBorder[1], th.cardBorder[2], th.cardBorder[3], th.cardBorder[4] or 1)
        accent:SetTexture(th.accent[1], th.accent[2], th.accent[3], 1)
        t:SetText("|cff" .. accentHex() .. titleText .. "|r")
    end
    if NC.RegisterThemeable then NC.RegisterThemeable(skin) else skin(NC.Theme) end
    return c
end

------------------------------------------------------------
-- Lector emergente (apartados del NPC)
------------------------------------------------------------
local reader
local function ShowReader(titleText, bodyText)
    if not reader then
        reader = CreateFrame("Frame", "NaerControlSoloQReader", UIParent)
        reader:SetSize(470, 400); reader:SetPoint("CENTER"); reader:SetFrameStrata("DIALOG")
        reader:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 },
        })
        reader:EnableMouse(true); reader:SetMovable(true); reader:RegisterForDrag("LeftButton")
        reader:SetScript("OnDragStart", reader.StartMoving)
        reader:SetScript("OnDragStop", reader.StopMovingOrSizing)
        tinsert(UISpecialFrames, "NaerControlSoloQReader")
        reader:SetScript("OnUpdate", function(self)
            local down = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
            if down and not self._wasDown and not MouseIsOver(self) then self:Hide() end
            self._wasDown = down
        end)
        local rbg = CreateFrame("Frame", nil, reader)
        rbg:SetPoint("TOPLEFT", 12, -40); rbg:SetPoint("BOTTOMRIGHT", -14, 12)
        rbg:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
        rbg:SetBackdropColor(0, 0, 0, 0.9); rbg:SetBackdropBorderColor(0.2, 0.22, 0.28, 0.9)
        reader.title = reader:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        reader.title:SetPoint("TOP", 0, -16)
        local close = CreateFrame("Button", nil, reader, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -6, -6)
        local sc = CreateFrame("ScrollFrame", "NaerControlSoloQReaderScroll", reader, "UIPanelScrollFrameTemplate")
        sc:SetPoint("TOPLEFT", 16, -44); sc:SetPoint("BOTTOMRIGHT", -34, 16)
        sc:EnableMouseWheel(true)
        sc:SetScript("OnMouseWheel", function(self, d)
            local c, m = self:GetVerticalScroll(), self:GetVerticalScrollRange()
            local n = c - d * 40; if n < 0 then n = 0 elseif n > m then n = m end
            self:SetVerticalScroll(n)
        end)
        local body = CreateFrame("Frame", nil, sc); body:SetSize(400, 10); sc:SetScrollChild(body)
        reader.bodyFS = body:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        reader.bodyFS:SetPoint("TOPLEFT", 0, 0); reader.bodyFS:SetWidth(400)
        reader.bodyFS:SetJustifyH("LEFT"); reader.bodyFS:SetJustifyV("TOP"); reader.bodyFS:SetSpacing(4)
        reader.bodyFS:SetTextColor(0.9, 0.92, 0.96)
        reader.body, reader.sc = body, sc
        sc:SetScript("OnSizeChanged", function() body:SetHeight((reader.bodyFS:GetStringHeight() or 10) + 16) end)
        if NC.SkinScrollOf then NC.SkinScrollOf(sc) end
    end
    reader.title:SetText("|cff" .. accentHex() .. (titleText or "") .. "|r")
    reader.bodyFS:SetText(bodyText or "")
    reader.body:SetHeight((reader.bodyFS:GetStringHeight() or 10) + 16)
    reader.sc:SetVerticalScroll(0)
    reader._wasDown = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
    reader:Show()
end

------------------------------------------------------------
-- Popup: partidas de un día
------------------------------------------------------------
local dayPopup, dayMatchRows
dayMatchRows = {}
local function ShowDayMatches(day)
    if not dayPopup then
        dayPopup = CreateFrame("Frame", "NaerControlSoloQDay", UIParent)
        dayPopup:SetSize(360, 360); dayPopup:SetPoint("CENTER"); dayPopup:SetFrameStrata("DIALOG")
        dayPopup:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 },
        })
        dayPopup:EnableMouse(true); dayPopup:SetMovable(true); dayPopup:RegisterForDrag("LeftButton")
        dayPopup:SetScript("OnDragStart", dayPopup.StartMoving)
        dayPopup:SetScript("OnDragStop", dayPopup.StopMovingOrSizing)
        tinsert(UISpecialFrames, "NaerControlSoloQDay")
        dayPopup:SetScript("OnUpdate", function(self)
            local down = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
            if down and not self._wasDown and not MouseIsOver(self) then self:Hide() end
            self._wasDown = down
        end)
        local dbg = CreateFrame("Frame", nil, dayPopup)
        dbg:SetPoint("TOPLEFT", 12, -40); dbg:SetPoint("BOTTOMRIGHT", -14, 12)
        dbg:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
        dbg:SetBackdropColor(0, 0, 0, 0.9); dbg:SetBackdropBorderColor(0.2, 0.22, 0.28, 0.9)
        dayPopup.title = dayPopup:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        dayPopup.title:SetPoint("TOP", 0, -16)
        local close = CreateFrame("Button", nil, dayPopup, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -6, -6)
        local sc = CreateFrame("ScrollFrame", "NaerControlSoloQDayScroll", dayPopup, "UIPanelScrollFrameTemplate")
        sc:SetPoint("TOPLEFT", 16, -44); sc:SetPoint("BOTTOMRIGHT", -34, 16)
        sc:EnableMouseWheel(true)
        sc:SetScript("OnMouseWheel", function(self, d)
            local c, m = self:GetVerticalScroll(), self:GetVerticalScrollRange()
            local n = c - d * 40; if n < 0 then n = 0 elseif n > m then n = m end
            self:SetVerticalScroll(n)
        end)
        local child = CreateFrame("Frame", nil, sc); child:SetSize(310, 10); sc:SetScrollChild(child)
        dayPopup.child, dayPopup.sc = child, sc
        dayPopup.empty = child:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        dayPopup.empty:SetPoint("TOPLEFT", 2, -2)
        dayPopup.empty:SetText("|cff888888Sin partidas registradas ese día.|r")
        if NC.SkinScrollOf then NC.SkinScrollOf(sc) end
    end
    dayPopup.title:SetText("|cff" .. accentHex() .. "Partidas · " .. (day.date or "") .. "|r")
    for _, r in ipairs(dayMatchRows) do r:Hide() end
    local matches = day.matches or {}
    local n = table.getn(matches)
    if n == 0 then dayPopup.empty:Show() else dayPopup.empty:Hide() end
    local idx = 0
    for i = n, 1, -1 do   -- más recientes arriba
        idx = idx + 1
        local m = matches[i]
        local r = dayMatchRows[idx]
        if not r then
            r = CreateFrame("Frame", nil, dayPopup.child)
            r:SetHeight(18)
            r:SetPoint("TOPLEFT", 0, -(idx - 1) * 18)
            r:SetPoint("RIGHT", dayPopup.child, "RIGHT", 0, 0)
            r.fs = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            r.fs:SetPoint("LEFT", 2, 0); r.fs:SetJustifyH("LEFT")
            r:EnableMouse(true)
            r:SetScript("OnEnter", function(self)
                if not self._m then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine("Compañeros", 0.4, 1, 0.4)
                if table.getn(self._m.allies or {}) == 0 then GameTooltip:AddLine("  —", 0.6,0.6,0.6) end
                for _, nm in ipairs(self._m.allies or {}) do GameTooltip:AddLine("  " .. nm, 0.8, 0.9, 0.8) end
                GameTooltip:AddLine("Rivales", 1, 0.4, 0.4)
                if table.getn(self._m.enemies or {}) == 0 then GameTooltip:AddLine("  —", 0.6,0.6,0.6) end
                for _, nm in ipairs(self._m.enemies or {}) do GameTooltip:AddLine("  " .. nm, 0.95, 0.8, 0.8) end
                GameTooltip:Show()
            end)
            r:SetScript("OnLeave", function() GameTooltip:Hide() end)
            dayMatchRows[idx] = r
        end
        r._m = m
        local hora = date("%H:%M", m.t or time())
        local res = m.win and "|cff40ff40Victoria|r" or "|cffff5040Derrota|r"
        local delta = m.delta or 0
        local dtxt = delta > 0 and ("|cff40ff40+" .. delta .. "|r") or (delta < 0 and ("|cffff5040" .. delta .. "|r") or "|cff888888" .. delta .. "|r")
        r.fs:SetText(hora .. "   " .. res .. "   " .. dtxt)
        r:Show()
    end
    dayPopup.child:SetHeight(math.max(1, idx * 18))
    dayPopup.sc:SetVerticalScroll(0)
    dayPopup._wasDown = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
    dayPopup:Show()
end

------------------------------------------------------------
-- Refresco
------------------------------------------------------------
local function getDayRow(i)
    if dayRows[i] then return dayRows[i] end
    local r = CreateFrame("Button", nil, histChild)
    r:SetHeight(17)
    r:SetPoint("TOPLEFT", 0, -(i - 1) * 17)
    r:SetPoint("RIGHT", histChild, "RIGHT", 0, 0)
    local hl = r:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints(); hl:SetTexture(1, 1, 1); hl:SetVertexColor(1, 1, 1, 0.08)
    r.date = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.date:SetPoint("LEFT", 4, 0)
    r.rec = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.rec:SetPoint("LEFT", 150, 0)
    r.rate = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.rate:SetPoint("LEFT", 260, 0)
    r.hint = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.hint:SetPoint("RIGHT", -6, 0); r.hint:SetText("ver »")
    dayRows[i] = r
    return r
end

local function RefreshAll()
    if not panel then return end

    -- Requisitos
    if reqChip and NC.SoloQ.CheckEligibility then
        local e = NC.SoloQ:CheckEligibility()
        reqChip._e = e
        if e.ok then
            reqChip.fs:SetText("|cff40ff40Puedes anotar|r")
        else
            local parts = {}
            if e.talentPoints > 0 then table.insert(parts, "talentos") end
            if table.getn(e.badItems) > 0 then table.insert(parts, "equipo") end
            reqChip.fs:SetText("|cffff5040No anota: " .. table.concat(parts, "+") .. "|r")
        end
    end

    -- Botón de cola
    local q = NC.SoloQ.queue.state
    if q == "queued" then
        local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
        joinBtn.glow:SetVertexColor(ac[1], ac[2], ac[3])
        NC.SetButtonEnabled(joinBtn, true)
    elseif q == "unavailable" then
        joinBtn:SetText("No disponible"); joinBtn.glow:SetAlpha(0); NC.SetButtonEnabled(joinBtn, false)
    elseif q == "arena" then
        joinBtn:SetText("En arena"); joinBtn.glow:SetAlpha(0); NC.SetButtonEnabled(joinBtn, false)
    else
        joinBtn:SetText("Unirse a SoloQ"); joinBtn.glow:SetAlpha(0)
        local elig = reqChip and reqChip._e
        NC.SetButtonEnabled(joinBtn, (not elig) or elig.ok)
    end

    -- Tarjeta 1: Equipo (como la UI de Blizzard)
    local t = NC.SoloQ:GetTeam()
    if not t then
        teamFS:SetText("|cff888888Sin equipo de SoloQ todavía.|r")
        teamRateFS:SetText(""); persoRateFS:SetText(""); weekFS:SetText(""); seasonFS:SetText(""); streakFS:SetText("")
    else
        local function wl(pl, wn) return string.format("%dG-%dP", wn, math.max(0, pl - wn)) end
        teamFS:SetText("Equipo: |cffffffff" .. (t.teamName or "?") .. "|r")
        teamRateFS:SetText("Rating de equipo: |cffffffff" .. (t.teamRating or 0) .. "|r")
        persoRateFS:SetText("Rating personal: |cffffffff" .. (t.playerRating or 0) .. "|r")
        weekFS:SetText("|cff888888Semana:|r " .. wl(t.weekPlayed or 0, t.weekWins or 0))
        seasonFS:SetText("|cff888888Temporada:|r " .. wl(t.seasonPlayed or 0, t.seasonWins or 0))
        local s = NC.SoloQ:GetStreak()
        if s > 0 then streakFS:SetText("|cff40ff40Racha: +" .. s .. "|r")
        elseif s < 0 then streakFS:SetText("|cffff5040Racha: " .. s .. "|r")
        else streakFS:SetText("|cff888888Racha: 0|r  ·  |cff888888Mejor:|r " .. NC.SoloQ:GetBest()) end
    end

    -- Tarjeta 2: compañeros y rivales (top 5)
    local function fillTop(rows, list, kind)
        for i = 1, 5 do
            local r = rows[i]
            local e = list[i]
            r._e = e; r._kind = kind
            if e then
                r.fs:SetText(i .. ".  " .. e.name .. "  |cff888888(" .. e.count .. ")|r")
                r:EnableMouse(true)
            else
                r.fs:SetText(""); r:EnableMouse(false)
            end
            r:Show()
        end
    end
    if NC.SoloQ:IsTopOff() then
        if topBtn then topBtn:SetText("Activar") end
        for i = 1, 5 do allyRows[i].fs:SetText(""); allyRows[i]._e = nil; enemyRows[i].fs:SetText(""); enemyRows[i]._e = nil end
        if topOffMsg then topOffMsg:Show() end
    else
        if topBtn then topBtn:SetText("Desactivar") end
        if topOffMsg then topOffMsg:Hide() end
        fillTop(allyRows, NC.SoloQ:GetTopAllies(5), "compañero")
        fillTop(enemyRows, NC.SoloQ:GetTopEnemies(5), "rival")
    end

    -- Tarjeta 3: historial por día (clic -> partidas)
    local days = NC.SoloQ:GetDays()
    for _, r in ipairs(dayRows) do r:Hide() end
    local n = table.getn(days)
    local idx = 0
    for i = n, 1, -1 do
        idx = idx + 1
        local d = days[i]
        local r = getDayRow(idx)
        local g = (d.wins or 0) + (d.losses or 0)
        r.date:SetText(d.date or "?")
        r.rec:SetText((d.wins or 0) .. "-" .. (d.losses or 0))
        r.rate:SetText("|cffffffffR " .. (d.rating or 0) .. "|r")
        r._day = d
        r:SetScript("OnClick", function(self) ShowDayMatches(self._day) end)
        r:Show()
    end
    histChild:SetHeight(math.max(1, idx * 17))
    if histMsg then if idx == 0 then histMsg:Show() else histMsg:Hide() end end
end

------------------------------------------------------------
-- Construcción
------------------------------------------------------------
-- Muestra el registro (V/D) de un jugador del Top al pulsar su fila.
local function showRecord(row)
    local e = row and row._e
    if not e or not e.name or e.name == "" then return end
    GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
    GameTooltip:AddLine(e.name)
    GameTooltip:AddLine(row._kind == "rival" and "Contra este rival:" or "Con este compañero:", 0.8, 0.8, 0.85)
    GameTooltip:AddLine("Victorias: " .. (e.wins or 0), 0.4, 1, 0.4)
    GameTooltip:AddLine("Derrotas: " .. ((e.games or 0) - (e.wins or 0)), 1, 0.4, 0.4)
    GameTooltip:AddLine("Partidas: " .. (e.games or 0), 0.7, 0.7, 0.75)
    GameTooltip:Show()
end

local function build()
    panel = CreateFrame("Frame", nil, NC.Content)
    panel:SetAllPoints(NC.Content)
    panel._ncSkip = true

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    title:SetPoint("TOPLEFT", 18, -8)
    title:SetText("|cffffffffSoloQ|r")

    joinBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    joinBtn:SetSize(160, 26); joinBtn:SetPoint("TOPRIGHT", -18, -8)
    joinBtn:SetText("Unirse a SoloQ")
    joinBtn:SetScript("OnClick", function() NC.SoloQ:Join() end)
    if NC.SkinButton then NC.SkinButton(joinBtn) end
    joinBtn.glow = joinBtn:CreateTexture(nil, "OVERLAY")
    joinBtn.glow:SetAllPoints(joinBtn)
    joinBtn.glow:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
    joinBtn.glow:SetBlendMode("ADD"); joinBtn.glow:SetAlpha(0)
    joinBtn:SetScript("OnUpdate", function(self, elapsed)
        if NC.SoloQ.queue.state == "unavailable" then
            if NC.SoloQ.queue.since and (GetTime() - NC.SoloQ.queue.since) > 5 then
                NC.SoloQ.queue.state = "idle"
                if NC.SoloQ.OnChanged then NC.SoloQ:OnChanged() end
            end
            return
        end
        if NC.SoloQ.queue.state ~= "queued" then return end
        if NC.SoloQ.queue.since and (GetTime() - NC.SoloQ.queue.since) > 90 then
            NC.SoloQ.queue.state = "idle"
            if NC.SoloQ.OnChanged then NC.SoloQ:OnChanged() end
            return
        end
        self._t = (self._t or 0) + (elapsed or 0)
        local dots = math.floor((self._t * 2) % 4)
        self:SetText("Buscando" .. string.rep(".", dots))
        if self.glow then self.glow:SetAlpha(0.2 + 0.5 * math.abs(math.sin(self._t * 3))) end
    end)

    reqChip = CreateFrame("Frame", nil, panel)
    reqChip:SetSize(180, 16); reqChip:SetPoint("TOP", joinBtn, "BOTTOM", 0, -4)
    reqChip:EnableMouse(true)
    reqChip.fs = reqChip:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    reqChip.fs:SetAllPoints(); reqChip.fs:SetJustifyH("CENTER")
    reqChip:SetScript("OnEnter", function(self)
        local e = self._e
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Requisitos para anotar en SoloQ")
        if not e then GameTooltip:AddLine("Sin datos.", 0.7, 0.7, 0.7)
        else
            if e.talentPoints > 0 then GameTooltip:AddLine("Talentos sin asignar: " .. e.talentPoints, 1, 0.4, 0.4)
            else GameTooltip:AddLine("Talentos: todos asignados", 0.4, 1, 0.4) end
            if table.getn(e.badItems) == 0 then GameTooltip:AddLine("Equipo: todo >= " .. (e.minILvl or 251), 0.4, 1, 0.4)
            else
                GameTooltip:AddLine("Piezas por debajo de " .. (e.minILvl or 251) .. ":", 1, 0.4, 0.4)
                for _, it in ipairs(e.badItems) do
                    local sn = SLOT_NAMES[it.slot] or ("Ranura " .. it.slot)
                    GameTooltip:AddLine("  " .. sn .. ": " .. (it.name or "?") .. " (" .. it.ilvl .. ")", 1, 0.7, 0.5)
                end
            end
            GameTooltip:AddLine("(No cuenta Tabardo, Camisa, Offhand ni Ranged)", 0.6, 0.6, 0.62)
        end
        GameTooltip:Show()
    end)
    reqChip:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Tarjeta: Sistema SoloQ (NPC)
    local cN = makeCard(panel, "Sistema SoloQ", -60, 176)
    local portrait = cN:CreateTexture(nil, "ARTWORK")
    portrait:SetSize(96, 96); portrait:SetPoint("TOPLEFT", 14, -30)
    portrait:SetTexCoord(0.04, 0.96, 0.04, 0.96)
    portrait:SetTexture(NC.MEDIA .. "soloq_npc")
    if not portrait:GetTexture() then portrait:SetTexture("Interface\\Icons\\Achievement_Arena_2v2_7") end
    local pbord = cN:CreateTexture(nil, "BACKGROUND")
    pbord:SetPoint("TOPLEFT", portrait, "TOPLEFT", -2, 2)
    pbord:SetPoint("BOTTOMRIGHT", portrait, "BOTTOMRIGHT", 2, -2)
    pbord:SetTexture(0, 0, 0, 0.6)

    npcText = cN:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    npcText:SetPoint("TOPLEFT", 122, -28); npcText:SetWidth(460)
    npcText:SetJustifyH("LEFT"); npcText:SetJustifyV("TOP"); npcText:SetSpacing(3)
    npcText:SetTextColor(0.85, 0.87, 0.92)
    npcText:SetText(NPC_TEXT.resumen)

    local defs = {
        { "Cola y emparejamiento", "cola", 165 },
        { "Penalizaciones", "penal", 120 },
        { "Consejos y trucos", "consejos", 130 },
    }
    local bx = 14
    for _, d in ipairs(defs) do
        local b = CreateFrame("Button", nil, cN, "UIPanelButtonTemplate")
        b:SetSize(d[3], 22); b:SetPoint("BOTTOMLEFT", bx, 10); b:SetText(d[1])
        local label, key = d[1], d[2]
        b:SetScript("OnClick", function() ShowReader(label, NPC_TEXT[key]) end)
        if NC.SkinButton then NC.SkinButton(b) end
        bx = bx + d[3] + 6
    end

    -- Tarjeta: Equipo
    local cE = makeCard(panel, "Equipo", -244, 96)
    teamFS = cE:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    teamFS:SetPoint("TOPLEFT", 16, -32)
    teamRateFS = cE:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    teamRateFS:SetPoint("TOPLEFT", 16, -52)
    persoRateFS = cE:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    persoRateFS:SetPoint("TOPLEFT", 16, -72)
    weekFS = cE:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    weekFS:SetPoint("TOPLEFT", 320, -32)
    seasonFS = cE:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    seasonFS:SetPoint("TOPLEFT", 320, -52)
    streakFS = cE:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    streakFS:SetPoint("TOPLEFT", 320, -72)

    -- Tarjeta: Compañeros y rivales
    local cM = makeCard(panel, "Compañeros y rivales", -348, 150)
    local ah = cM:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ah:SetPoint("TOPLEFT", 16, -30); ah:SetText("|cff9fd98fCompañeros más frecuentes|r")
    local eh = cM:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    eh:SetPoint("TOPLEFT", 330, -30); eh:SetText("|cffff9f9fRivales más frecuentes|r")
    local function mkRow(x, i, kind)
        local r = CreateFrame("Button", nil, cM)
        r:SetSize(290, 18)
        r:SetPoint("TOPLEFT", x, -30 - i * 20)
        r.fs = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        r.fs:SetPoint("LEFT", 0, 0); r.fs:SetJustifyH("LEFT")
        local hl = r:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints()
        hl:SetTexture(1, 1, 1); hl:SetVertexColor(1, 1, 1, 0.08)
        r._kind = kind
        r:SetScript("OnClick", function(self) showRecord(self) end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return r
    end
    for i = 1, 5 do
        allyRows[i]  = mkRow(20, i, "compañero")
        enemyRows[i] = mkRow(334, i, "rival")
    end
    topBtn = CreateFrame("Button", nil, cM, "UIPanelButtonTemplate")
    topBtn:SetSize(90, 20); topBtn:SetPoint("TOPRIGHT", -8, -6)
    topBtn:SetText("Desactivar")
    topBtn:SetScript("OnClick", function() NC.SoloQ:SetTopOff(not NC.SoloQ:IsTopOff()) end)
    if NC.SkinButton then NC.SkinButton(topBtn) end
    topOffMsg = cM:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    topOffMsg:SetPoint("CENTER", 0, -10)
    topOffMsg:SetText("|cff888888Top de compañeros y rivales desactivado.|r")
    topOffMsg:Hide()

    -- Tarjeta: Historial (30 días)
    local cH = makeCard(panel, "Historial (30 días)", -506, 108)
    local heads = { { "Fecha", 4 }, { "G-P", 150 }, { "Rating", 260 } }
    for _, hd in ipairs(heads) do
        local h = cH:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        h:SetPoint("TOPLEFT", hd[2] + 6, -32); h:SetText(hd[1])
    end
    local scroll = CreateFrame("ScrollFrame", "NaerControlSoloQHist", cH, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 12, -48); scroll:SetPoint("BOTTOMRIGHT", cH, "BOTTOMRIGHT", -30, 10)
    if NC.SkinScrollOf then NC.SkinScrollOf(scroll) end
    histChild = CreateFrame("Frame", nil, scroll); histChild:SetSize(10, 10)
    scroll:SetScrollChild(histChild)
    scroll:SetScript("OnSizeChanged", function(_, w) histChild:SetWidth(w or 1) end)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, d)
        local c, m = self:GetVerticalScroll(), self:GetVerticalScrollRange()
        local n = c - d * 30; if n < 0 then n = 0 elseif n > m then n = m end
        self:SetVerticalScroll(n)
    end)
    histMsg = cH:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    histMsg:SetPoint("TOPLEFT", 14, -52); histMsg:SetText("|cff888888Aún no hay días registrados.|r"); histMsg:Hide()

    clearBtn = CreateFrame("Button", nil, cH, "UIPanelButtonTemplate")
    clearBtn:SetSize(80, 20); clearBtn:SetPoint("TOPRIGHT", -8, -6)
    clearBtn:SetText("Limpiar")
    clearBtn:SetScript("OnClick", function() StaticPopup_Show("NAERCONTROL_SOLOQ_CLEAR") end)
    if NC.SkinButton then NC.SkinButton(clearBtn) end

    if NC.SkinPanel then NC.SkinPanel(panel) end
end

function NC.ShowSoloQView()
    if not panel then build() end
    NC.SoloQ.OnChanged = RefreshAll
    if NC.SoloQ.Update then NC.SoloQ:Update() end
    RefreshAll()
    panel:Show()
    NC.Content:Show()
    if not panel._ticking then
        panel._ticking = true
        panel:SetScript("OnUpdate", function(self, elapsed)
            if not self:IsShown() then return end
            self._acc = (self._acc or 0) + (elapsed or 0)
            if self._acc < 3 then return end
            self._acc = 0
            if NC.SoloQ.Update then pcall(function() NC.SoloQ:Update() end) end
        end)
    end
end

function NC.HideSoloQView()
    if panel then panel:Hide() end
end
