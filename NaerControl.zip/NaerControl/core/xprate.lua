local ADDON, NC = ...

------------------------------------------------------------
-- Rates de experiencia (pestaña Experiencia).
--
-- El rate actual se guarda POR PERSONAJE (NaerControlCharDB), no global:
-- cada personaje puede tener el suyo. El boton del valor guardado se ve
-- en gris/hundido. La verdad definitiva la da el servidor: al pulsar
-- "Consultar rates actuales", el parser corrige lo guardado con lo real.
--
-- Nota: el bonus de x10 de finde con rate 8 lo aplica el servidor solo;
-- el addon no puede detectarlo, asi que guarda el 8 que tu fijaste.
------------------------------------------------------------

NC.XpRates = {}

local MIN_RATE, MAX_RATE = 1, 8

-- rateKey: "quest" | "kill". Filas registradas para poder refrescar el gris.
local rows = {}

local function Store()
    NC.cdb.rates = NC.cdb.rates or {}
    return NC.cdb.rates
end

function NC.XpRates:Get(key)
    return Store()[key]   -- puede ser nil (sin dato -> ningun boton en gris)
end

function NC.XpRates:Set(key, value)
    if value then value = math.floor(value + 0.5) end
    Store()[key] = value
    self:Refresh(key)
end

-- Registra la fila de botones de un rateKey para refrescarla luego.
function NC.XpRates:Register(key, row)
    rows[key] = row
end

-- Marca en gris el boton que coincide con el rate guardado.
function NC.XpRates:Refresh(key)
    local row = rows[key]
    if not row or not row.rateButtons then return end
    local current = self:Get(key)
    -- bloqueamos si hay cola O si estamos en el tope del límite de envíos
    local locked = NC.QueueSize() > 0 or (NC.AtRateLimit and NC.AtRateLimit())
    for value, btn in pairs(row.rateButtons) do
        -- "es el actual" se marca SOLO con el resaltado, no deshabilitando:
        -- asi el bloqueo por cola (Enable/Disable) es lo unico que decide
        -- si el boton responde, y nunca queda muerto al vaciarse la cola.
        if current == value then
            btn:LockHighlight()
        else
            btn:UnlockHighlight()
        end
        NC.SetButtonEnabled(btn, not locked)
    end
end

-- Botones extra que deben bloquearse con el límite, además de los de rate:
-- "Consultar", "Rates al máximo" y el botón fijo de exploración.
local extraButtons = {}

function NC.XpRates:RefreshAll()
    for key in pairs(rows) do self:Refresh(key) end
    -- botones extra (Consultar, Máximo, exploración): mismo bloqueo
    local locked = NC.QueueSize() > 0 or (NC.AtRateLimit and NC.AtRateLimit())
    for btn in pairs(extraButtons) do
        NC.SetButtonEnabled(btn, not locked)
    end
end

-- Botones extra que deben bloquearse con el límite, además de los de rate:
-- "Consultar", "Rates al máximo" y el botón fijo de exploración.

function NC.XpRates:RegisterExtra(btn)
    if btn then extraButtons[btn] = true end
end

function NC.XpRates:ClearExtras()
    for k in pairs(extraButtons) do extraButtons[k] = nil end
end

-- Red de seguridad: si no hay cola ni tope de límite, garantiza que todos los
-- botones estén habilitados (evita que queden grises tras pulsar varios).
function NC.XpRates:EnsureEnabled()
    if NC.QueueSize() > 0 then return end
    if NC.AtRateLimit and NC.AtRateLimit() then return end
    for key, row in pairs(rows) do
        if row.rateButtons then
            for _, btn in pairs(row.rateButtons) do
                NC.SetButtonEnabled(btn, true)
            end
        end
    end
    for btn in pairs(extraButtons) do NC.SetButtonEnabled(btn, true) end
end

-- Parpadeo (destello con el acento) sobre un boton, N veces, via OnUpdate.
-- Feedback inmediato al pulsar Consultar / Rates al maximo, y al llegar la
-- respuesta del servidor.
local function blink(btn, times)
    if not btn then return end
    if not btn._ncPulse then
        local g = btn:CreateTexture(nil, "OVERLAY")
        g:SetPoint("TOPLEFT", -3, 3)
        g:SetPoint("BOTTOMRIGHT", 3, -3)
        g:SetTexture(1, 1, 1)
        g:SetBlendMode("ADD")
        g:SetAlpha(0)
        btn._ncPulse = g
        btn._ncPulseDrv = CreateFrame("Frame", nil, btn)
        btn._ncPulseDrv:Hide()
    end
    local g = btn._ncPulse
    local drv = btn._ncPulseDrv
    local ac = (NC.Theme and NC.Theme.accent) or { 1, 0.95, 0.4 }
    g:SetVertexColor(ac[1], ac[2], ac[3])
    drv._t = 0
    drv._cycles = times or 3
    local PERIOD = 0.28
    drv:SetScript("OnUpdate", function(self, elapsed)
        self._t = self._t + elapsed
        if self._t >= PERIOD * self._cycles then
            g:SetAlpha(0); self:Hide(); return
        end
        local phase = (self._t % PERIOD) / PERIOD
        g:SetAlpha(math.sin(phase * math.pi) * 0.8)
    end)
    drv:Show()
end

-- Parpadeo publico (lo usa la pestana Experiencia).
function NC.XpRates:Blink(btn, times)
    blink(btn, times)
end

-- Cooldown del limitador de comandos sobre un boton: al enviarse, muestra el
-- swirl con los segundos que faltan para poder volver a enviar.
function NC.XpRates:StartCooldown(btn)
    if not btn then return end
    if not btn._ncCD then
        local cd = CreateFrame("Cooldown", nil, btn, "CooldownFrameTemplate")
        cd:SetAllPoints(btn)
        btn._ncCD = cd
    end
    local w = (NC.SendWaitTime and NC.SendWaitTime()) or 0
    if w and w > 0 then
        btn._ncCD:SetCooldown(GetTime(), w)
    end
end

-- Respuesta del servidor: corrige lo guardado con la verdad.
function NC.XpRates:OnServerRates(rates)
    local changed = false
    if rates.quest then Store().quest = rates.quest; changed = true end
    if rates.kill  then Store().kill  = rates.kill;  changed = true end
    if changed then
        self:RefreshAll()
        for _, key in ipairs({ "quest", "kill" }) do
            if rates[key] and rows[key] and rows[key].rateButtons then
                blink(rows[key].rateButtons[rates[key]], 3)
            end
        end
    end
end

-- Envia el cambio de rate (por la cola, respetando el limite 2/5s).
-- Bonus de fin de semana: activo sábado 00:00 -> domingo 23:59 (hora
-- española). Devuelve: active(bool), texto(string) describiendo cuándo
-- empieza o termina. Usa la hora local del cliente, que en NAERZONE coincide
-- con la del servidor (española).
function NC.XpRates:WeekendBonus()
    -- date("*t") da la fecha/hora local. wday: 1=domingo ... 7=sábado.
    local t = date("*t")
    if not t then return false, nil end
    local wday = t.wday   -- 1=dom, 2=lun, ..., 7=sab
    local isWeekend = (wday == 7 or wday == 1)   -- sábado o domingo

    if isWeekend then
        -- termina el domingo a las 23:59
        local daysLeft = (wday == 7) and 1 or 0   -- sábado: falta 1 día
        if daysLeft == 1 then
            return true, "¡Bonus de fin de semana activo! Termina el |cffffffffdomingo|r a las |cffffffff23:59|r."
        else
            return true, "¡Bonus de fin de semana activo! Termina |cffffffffhoy|r a las |cffffffff23:59|r."
        end
    else
        -- cuenta cuántos días faltan hasta el sábado (wday 7)
        local daysToSat = (7 - wday)
        local when
        if daysToSat == 1 then when = "mañana"
        else when = "en " .. daysToSat .. " días" end
        return false, "El bonus de fin de semana empieza el |cffffffffsábado|r a las |cffffffff00:00|r (|cffffffff" .. when .. "|r)."
    end
end

function NC.XpRates:SendRate(key, cmdBase, value)
    if NC.QueueSize() > 0 then
        NC.SetStatus("Espera: hay consultas en cola.", true)
        return
    end
    local nombres = { quest = "misiones", kill = "criaturas", explore = "exploración" }
    local label = nombres[key] or key
    NC.Send(cmdBase .. " " .. value)
    self:Set(key, value)   -- optimista; el servidor lo confirmara
    NC.SetStatus("Enviando: rate " .. label .. " x" .. value .. "…")
    self:Refresh(key)
end
