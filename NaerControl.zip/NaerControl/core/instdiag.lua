local ADDON, NC = ...

------------------------------------------------------------
-- Diagnostico de instancias (/naer instdiag).
--
-- FASE 1 - RECOPILACION. No estima nada: graba cada evento de instancia
-- con su hora en un historial PERSISTENTE (sobrevive a /reload y relog),
-- hasta que el usuario lo apague. El objetivo es capturar una sesion real
-- de farmeo (p.ej. 5 fosos seguidos) y ver EXACTAMENTE que dispara el
-- bloqueo "has entrado en demasiadas estancias", para luego construir el
-- contador con datos y no con suposiciones.
--
-- Comandos:
--   /naer instdiag         -> activa la grabacion (persistente) y vuelca lockouts
--   /naer instdiag dump    -> muestra el historial recopilado
--   /naer instdiag stop    -> apaga la grabacion
--   /naer instdiag clear   -> borra el historial
------------------------------------------------------------

NC.InstDiag = {}

local function P(msg, r, g, b)
    if r then DEFAULT_CHAT_FRAME:AddMessage(msg, r, g, b)
    else DEFAULT_CHAT_FRAME:AddMessage(msg) end
end

-- Historial persistente (por cuenta: el limite de 5/h es de cuenta).
local function Log()
    NaerControlDB.instLog = NaerControlDB.instLog or {}
    return NaerControlDB.instLog
end

local function Stamp()
    return date("%Y-%m-%d %H:%M:%S")
end

-- Añade una entrada al historial y, si esta activo, la imprime.
local function Record(kind, detail)
    local e = {
        t     = time(),
        stamp = Stamp(),
        kind  = kind,
        who   = UnitName("player"),
        zone  = GetRealZoneText and GetRealZoneText() or "?",
        detail = detail,
    }
    table.insert(Log(), e)
    while table.getn(Log()) > 500 do table.remove(Log(), 1) end

    if NC.InstDiag.verbose then
        local col = { enter = "|cff7ec8e3", reset = "|cffffcc00",
                      block = "|cffff4040", sys = "|cff888888", leave = "|cff888888" }
        P("  " .. (col[kind] or "") .. "[" .. kind .. "]|r " .. e.stamp
            .. "  " .. tostring(e.zone) .. (detail and ("  " .. detail) or ""))
    end
end

------------------------------------------------------------
-- Volcado de lockouts (dato 100% fiable de la API).
------------------------------------------------------------
local function DumpSaved()
    P("|cff7ec8e3== Lockouts guardados ==|r")
    if type(RequestRaidInfo) == "function" then RequestRaidInfo() end
    if type(GetNumSavedInstances) ~= "function" then
        P("  GetNumSavedInstances no existe.", 1, 0.4, 0.4); return
    end
    local n = GetNumSavedInstances() or 0
    P("  total: " .. n)
    for i = 1, n do
        local name, id, reset, diff, locked, ext, mostSig, isRaid, maxP, diffName =
            GetSavedInstanceInfo(i)
        P(string.format("  [%d] %s  id=%s reset=%ss diff=%s(%s) locked=%s isRaid=%s maxP=%s",
            i, tostring(name), tostring(id), tostring(reset), tostring(diff),
            tostring(diffName), tostring(locked), tostring(isRaid), tostring(maxP)),
            0.9, 0.9, 0.6)
    end
end

------------------------------------------------------------
-- Control
------------------------------------------------------------
local listener

local function EnsureListener()
    if listener then return end
    listener = CreateFrame("Frame")
    listener:SetScript("OnEvent", function(self, event, ...)
        NC.InstDiag:OnEvent(event, ...)
    end)
end

local function RegisterAll()
    EnsureListener()
    listener:RegisterEvent("PLAYER_ENTERING_WORLD")
    listener:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    listener:RegisterEvent("UPDATE_INSTANCE_INFO")
    listener:RegisterEvent("CHAT_MSG_SYSTEM")
    listener:RegisterEvent("RAID_INSTANCE_WELCOME")
end

function NC.InstDiag:Start()
    NaerControlDB.instDiagOn = true
    self.verbose = true
    RegisterAll()
    P("|cff8b5a2bNaer|r|cff7ec8e3Control|r |cffffd100— grabación de instancias ACTIVA|r")
    P("Graba de forma permanente (sobrevive a /reload y relog).")
    P("Haz tu sesión de farmeo; cuando saltes el bloqueo, escribe "
        .. "|cffffd100/naer instdiag dump|r y pásame el resultado.")
    P("Apagar: |cffffd100/naer instdiag stop|r")
    P(" ")
    DumpSaved()
end

function NC.InstDiag:Stop()
    NaerControlDB.instDiagOn = false
    self.verbose = false
    if listener then listener:UnregisterAllEvents() end
    P("Grabación de instancias detenida. El historial se conserva "
        .. "(|cffffd100/naer instdiag dump|r para verlo).", 0.6, 0.6, 0.6)
end

function NC.InstDiag:Resume()
    if NaerControlDB and NaerControlDB.instDiagOn then
        RegisterAll()
    end
end

function NC.InstDiag:Dump()
    local l = Log()
    P("|cff7ec8e3== Historial de instancias (" .. table.getn(l) .. " eventos) ==|r")
    if table.getn(l) == 0 then
        P("  (vacío)", 0.6, 0.6, 0.6); return
    end
    for _, e in ipairs(l) do
        P(string.format("  %s  [%s]  %s  %s%s",
            e.stamp, e.kind, tostring(e.who), tostring(e.zone),
            e.detail and ("  " .. e.detail) or ""))
    end
    local now = time()
    local recent = 0
    for _, e in ipairs(l) do
        if e.kind == "enter" and (now - e.t) <= 3600 then recent = recent + 1 end
    end
    P("  |cffffd100Entradas en la última hora: " .. recent .. "|r")
end

function NC.InstDiag:Clear()
    NaerControlDB.instLog = {}
    P("Historial de instancias borrado.", 0.6, 0.6, 0.6)
end

------------------------------------------------------------
-- Eventos
------------------------------------------------------------
function NC.InstDiag:OnEvent(event, a1, a2, a3)
    if event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
        local inInst, instType = IsInInstance()
        if inInst and instType == "party" then
            Record("enter", "tipo=" .. tostring(instType))
        elseif not inInst and self._wasInside then
            Record("leave", nil)
        end
        self._wasInside = inInst

    elseif event == "RAID_INSTANCE_WELCOME" then
        Record("enter", string.format("WELCOME reset=%ss", tostring(a2)))

    elseif event == "UPDATE_INSTANCE_INFO" then
        -- refresco silencioso de lockouts; no se anuncia (era ruido)

    elseif event == "CHAT_MSG_SYSTEM" then
        local msg = a1 or ""
        local low = string.lower(msg)
        if string.find(low, "demasiadas estancias", 1, true) then
            Record("block", "BLOQUEO: " .. msg)
            if NC.InstDiag.verbose then
                P("  |cffff4040*** BLOQUEO DETECTADO ***|r", 1, 0.25, 0.25)
                P("  |cffff4040Escribe /naer instdiag dump y pásame el resultado.|r", 1, 0.25, 0.25)
            end
        elseif string.find(low, "se ha reiniciado", 1, true) then
            Record("reset", msg)
        end
    end
end
