local ADDON, NC = ...

------------------------------------------------------------
-- Diagnóstico de eventos (/naer eventdiag).
--
-- Registra, para CADA mensaje de chat que llega, si contiene algo que
-- parezca una respuesta de eventos y por qué evento de chat entró. Sirve
-- para descubrir el canal real por el que el servidor responde a
-- ".event activelist" y ".event info", y por qué el parser no captura.
--
-- Uso:
--   /naer eventdiag        -> arma el diagnóstico y lanza .event activelist
--   /naer eventdiag stop   -> desarma
------------------------------------------------------------

NC.EventDiag = {}

local function P(msg, r, g, b)
    if r then DEFAULT_CHAT_FRAME:AddMessage(msg, r, g, b)
    else DEFAULT_CHAT_FRAME:AddMessage(msg) end
end

local frame
local CHAT_EVENTS = {
    "CHAT_MSG_SYSTEM", "CHAT_MSG_CHANNEL", "CHAT_MSG_SAY", "CHAT_MSG_YELL",
    "CHAT_MSG_MONSTER_SAY", "CHAT_MSG_MONSTER_YELL", "CHAT_MSG_MONSTER_EMOTE",
    "CHAT_MSG_RAID_BOSS_EMOTE", "CHAT_MSG_WHISPER", "CHAT_MSG_GUILD",
    "CHAT_MSG_PARTY", "CHAT_MSG_RAID", "CHAT_MSG_EMOTE", "CHAT_MSG_TEXT_EMOTE",
}

function NC.EventDiag:Start()
    if not frame then
        frame = CreateFrame("Frame")
        frame:SetScript("OnEvent", function(self, event, ...)
            NC.EventDiag:OnEvent(event, ...)
        end)
    end
    for _, e in ipairs(CHAT_EVENTS) do frame:RegisterEvent(e) end

    P("|cff8b5a2bNaer|r|cff7ec8e3Control|r |cffffd100— diagnóstico de eventos ARMADO|r")
    P("Voy a lanzar |cffffd100.event activelist|r. Observa las líneas |cff33ff99[evdiag]|r:")
    P("te dirán por qué CANAL llega cada respuesta y si el parser la reconoce.")
    P("Cuando termines: |cffffd100/naer eventdiag stop|r")
    P(" ")

    -- lanzar el comando directamente (sin cola, para no interferir)
    if type(SendChatMessage) == "function" then
        SendChatMessage(".event activelist", "SAY")
    end
end

function NC.EventDiag:Stop()
    if frame then frame:UnregisterAllEvents() end
    P("Diagnóstico de eventos desarmado.", 0.6, 0.6, 0.6)
end

function NC.EventDiag:OnEvent(event, a1, a2, a3, a4)
    local msg = a1
    if type(msg) ~= "string" then return end

    -- ¿parece una línea de evento? (contiene [active] o "N - [")
    local plain = NC.StripColors and NC.StripColors(msg) or msg
    local looksEvent = string.find(plain, "%[active%]")
        or string.find(plain, "^%s*%d+%s*%-%s*%[")
        or string.find(plain, "^Event%s+%d+:")
        or string.find(plain, "Next state change:")
        or string.find(plain, "Occurence:")

    if not looksEvent then return end

    -- ¿lo reconoce nuestro parser?
    local id = NC.ParseEventListLine and NC.ParseEventListLine(msg)
    local info = NC.ParseEventInfo and NC.ParseEventInfo(msg)
    local parsed = id and ("lista id=" .. id) or (info and ("info " .. info.kind)) or "|cffff4040NO reconocido|r"

    -- estado del pending (¿el filtro ocultaría?)
    local pend = "pending.list=" .. tostring(NC.Events and NC.Events.pending and NC.Events.pending.list)

    P(string.format("  |cff33ff99[evdiag]|r %s -> %s  |cff888888(%s)|r", event, parsed, pend), 0.6, 0.85, 0.55)
    P("      |cff888888texto crudo: " .. msg .. "|r")
end
