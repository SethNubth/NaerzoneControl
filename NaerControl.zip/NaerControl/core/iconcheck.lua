local ADDON, NC = ...

------------------------------------------------------------
-- Verificador de iconos (/nc iconos)
--
-- Pinta, para cada jefe, la textura "Achievement_Boss_*" candidata junto
-- al objeto de respaldo. Las rutas que no existen en el cliente salen en
-- BLANCO (o como el cuadro morado por defecto): asi se ve de un vistazo
-- cuales sirven. Debajo de cada par va el nombre del jefe.
--
-- No decide nada solo: es una herramienta para que el usuario mire y diga
-- cuales funcionan. Las que sirvan se copian a NC.BOSS_ICON_TEX.
------------------------------------------------------------

local frame, scroll, content
local cells = {}

local ORDER = { "ICC", "TOC", "SR" }

local function GetCell(i)
    if cells[i] then return cells[i] end

    local cell = CreateFrame("Frame", nil, content)
    cell:SetWidth(210)
    cell:SetHeight(52)

    -- retrato candidato
    cell.portrait = cell:CreateTexture(nil, "ARTWORK")
    cell.portrait:SetWidth(40)
    cell.portrait:SetHeight(40)
    cell.portrait:SetPoint("LEFT", 4, 0)
    cell.portrait:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    local pborder = cell:CreateTexture(nil, "BACKGROUND")
    pborder:SetPoint("TOPLEFT", cell.portrait, "TOPLEFT", -2, 2)
    pborder:SetPoint("BOTTOMRIGHT", cell.portrait, "BOTTOMRIGHT", 2, -2)
    pborder:SetTexture("Interface\\Buttons\\WHITE8X8")
    pborder:SetVertexColor(0.3, 0.3, 0.3, 1)

    -- objeto de respaldo
    cell.fallback = cell:CreateTexture(nil, "ARTWORK")
    cell.fallback:SetWidth(28)
    cell.fallback:SetHeight(28)
    cell.fallback:SetPoint("LEFT", cell.portrait, "RIGHT", 12, 0)
    cell.fallback:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    cell.arrow = cell:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    cell.arrow:SetPoint("LEFT", cell.portrait, "RIGHT", 2, 0)
    cell.arrow:SetText("|cff666666>|r")

    cell.name = cell:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    cell.name:SetPoint("LEFT", cell.fallback, "RIGHT", 8, 0)
    cell.name:SetPoint("RIGHT", cell, "RIGHT", -4, 0)
    cell.name:SetJustifyH("LEFT")

    cell:EnableMouse(true)
    cell:SetScript("OnEnter", function(self)
        if not self.path then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.bossName)
        GameTooltip:AddLine(self.path, 0.7, 0.7, 0.7)
        GameTooltip:AddLine("Izquierda: el retrato candidato", 0.6, 0.85, 1)
        GameTooltip:AddLine("Derecha: el objeto de respaldo", 0.6, 0.85, 1)
        GameTooltip:Show()
    end)
    cell:SetScript("OnLeave", function() GameTooltip:Hide() end)

    cells[i] = cell
    return cell
end

local function Build()
    if frame then return end

    frame = CreateFrame("Frame", "NaerControlIconCheck", UIParent)
    frame:SetWidth(480)
    frame:SetHeight(560)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    tinsert(UISpecialFrames, "NaerControlIconCheck")

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 18, -16)
    title:SetText("Verificar iconos de jefe")
    title:SetTextColor(0.35, 0.8, 1)

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    local help = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    help:SetPoint("TOPLEFT", 18, -40)
    help:SetPoint("TOPRIGHT", -18, -40)
    help:SetJustifyH("LEFT")
    help:SetTextColor(1, 0.82, 0)
    help:SetText("Izquierda: retrato del jefe (puede no existir y salir en blanco).\n"
        .. "Derecha: objeto de respaldo (siempre sale). Dime cuáles retratos se ven bien.")

    scroll, content = NC.CreateScroll(frame)
    scroll:SetPoint("TOPLEFT", 16, -74)
    scroll:SetPoint("BOTTOMRIGHT", -34, 16)
    content:SetWidth(420)
end

function NC.ShowIconCheck()
    Build()

    for _, c in ipairs(cells) do c:Hide() end

    local i, y = 0, -4
    for _, raid in ipairs(ORDER) do
        for _, boss in ipairs(NC.BOSSES[raid]) do
            i = i + 1
            local cell = GetCell(i)
            local col = (i - 1) % 2
            local row = math.floor((i - 1) / 2)
            cell:ClearAllPoints()
            cell:SetPoint("TOPLEFT", content, "TOPLEFT", col * 210, -row * 54)

            -- ya confirmado: mostramos el retrato bueno, sin candidato
            local confirmado = NC.BOSS_ICON_TEX[boss.name]
            local path = confirmado or NC.BOSS_ICON_CANDIDATES[boss.name]
            cell.bossName = boss.name
            cell.path = path
            cell.portrait:SetTexture(path or NC.UNKNOWN_ICON)
            if confirmado then
                cell.arrow:SetText("|cff55ff55OK|r")
            elseif path then
                cell.arrow:SetText("|cffffcc00?|r")
            else
                cell.arrow:SetText("|cff666666-|r")
            end

            -- respaldo: el objeto que se usa hoy
            local itemID = NC.BOSS_ICON[boss.name]
            cell.fallback:SetTexture(itemID and NC.ItemIcon(itemID) or NC.UNKNOWN_ICON)

            cell.name:SetText(boss.name)
            cell:Show()
        end
    end

    content:SetHeight(math.ceil(i / 2) * 54 + 10)
    scroll:SetVerticalScroll(0)
    frame:Show()
end
