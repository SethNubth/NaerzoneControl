local ADDON, NC = ...

------------------------------------------------------------
-- Sonda de diagnóstico temporal: cuando está activa (/naer probe), engancha
-- MUCHOS eventos de chat y registra en la consola por CUÁL evento llega cada
-- línea. Sirve para averiguar por dónde manda el servidor los datos de
-- .player info de OTROS jugadores (que no aparecen por CHAT_MSG_SYSTEM).
-- No filtra nada; solo observa.
------------------------------------------------------------

local EVENTS = {
    "CHAT_MSG_SYSTEM", "CHAT_MSG_CHANNEL", "CHAT_MSG_SAY", "CHAT_MSG_YELL",
    "CHAT_MSG_MONSTER_SAY", "CHAT_MSG_MONSTER_YELL", "CHAT_MSG_MONSTER_WHISPER",
    "CHAT_MSG_MONSTER_EMOTE", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_RAID_BOSS_EMOTE", "CHAT_MSG_RAID_BOSS_WHISPER",
    "CHAT_MSG_TEXT_EMOTE", "CHAT_MSG_EMOTE", "CHAT_MSG_PARTY",
    "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_RAID",
}

local probe = CreateFrame("Frame")
NC._probeOn = false

local function short(s)
    s = NC.StripColors(s or "")
    if #s > 120 then s = string.sub(s, 1, 120) .. "…" end
    return s
end

probe:SetScript("OnEvent", function(self, event, msg, sender)
    if not NC._probeOn then return end
    if type(msg) ~= "string" or msg == "" then return end
    if NC.Console and NC.Console.LogInfo then
        -- recorta el prefijo "CHAT_MSG_" para que quepa
        local ev = string.gsub(event, "CHAT_MSG_", "")
        -- ¿reconocería NC.Info esta línea como parte de un bloque de info?
        local recog = ""
        if NC.IsInfoHeader and (NC.IsInfoHeader(msg) or NC.IsPlayerInfoLine(msg)
           or NC.IsRaidListLine(msg) or NC.IsRaidInfoLine(msg)) then
            recog = " |cff4fdf4f<INFO>|r"
        end
        local from = (sender and sender ~= "") and (" de=" .. sender) or ""
        NC.Console:LogInfo("[probe:" .. ev .. from .. "]" .. recog .. " " .. short(msg))
    end
end)

function NC.ToggleProbe()
    NC._probeOn = not NC._probeOn
    if NC._probeOn then
        for _, e in ipairs(EVENTS) do probe:RegisterEvent(e) end
        NC.Print("Sonda de chat: ON. Consulta un jugador y mira la consola. (Repite el comando para apagar.)")
    else
        probe:UnregisterAllEvents()
        NC.Print("Sonda de chat: OFF.")
    end
end
