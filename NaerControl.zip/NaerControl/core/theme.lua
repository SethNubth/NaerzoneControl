local ADDON, NC = ...

------------------------------------------------------------
-- Motor de temas. Tokens de estilo por tema:
--   "classic" = estilo general (acento dorado)
--   "modern"  = estilo de tarjetas (acento cian, el de Campos de Batalla)
--
-- Los elementos que quieran seguir el tema se registran con
-- NC.RegisterThemeable(fn); fn(tema) se llama ya y en cada cambio de tema.
-- NC.ApplyTheme("classic"|"modern") cambia el tema y reestiliza todo lo
-- registrado. El motor está listo para ir "temizando" más partes del addon.
------------------------------------------------------------

NC.THEMES = {
    classic = {
        name         = "classic",
        accent       = { 1.00, 0.82, 0.00 },
        cardBg       = { 0.07, 0.06, 0.05, 0.90 },
        cardBorder   = { 0.40, 0.32, 0.12, 0.90 },
        windowBg     = { 0.06, 0.05, 0.04, 0.95 },
        windowBorder = { 0.40, 0.32, 0.12, 1.00 },
    },
    modern = {
        name         = "modern",
        accent       = { 0.49, 0.78, 0.89 },
        cardBg       = { 0.06, 0.07, 0.10, 0.85 },
        cardBorder   = { 0.20, 0.30, 0.42, 0.90 },
        windowBg     = { 0.04, 0.05, 0.07, 0.92 },
        windowBorder = { 0.20, 0.30, 0.42, 0.90 },
    },
}

NC.Theme = NC.THEMES.classic

local skins = {}

-- Registra un reestilizador fn(tema). Se ejecuta ya con el tema actual.
function NC.RegisterThemeable(fn)
    if type(fn) ~= "function" then return end
    skins[#skins + 1] = fn
    if NC.Theme then pcall(fn, NC.Theme) end
end

-- Cambia el tema activo y reestiliza todo lo registrado.
function NC.ApplyTheme(name)
    local t = NC.THEMES[name] or NC.THEMES.classic
    NC.Theme = t
    if NC.db then NC.db.theme = t.name end
    -- El código de color de acento compartido (NC.COL.accent) sigue el tema, así
    -- muchos textos con acento (comandos, cabeceras, ayuda...) se temizan solos.
    if NC.COL then NC.COL.accent = "|cff" .. NC.ThemeHex("accent") end
    -- iterar sobre una COPIA: si algún callback registra nuevos themeables al
    -- reestilizar, evitamos crecer la lista en medio del bucle (bucle infinito).
    local snapshot = {}
    for i = 1, #skins do snapshot[i] = skins[i] end
    for _, fn in ipairs(snapshot) do pcall(fn, t) end
end

-- Color 'key' del tema activo como cadena hex "rrggbb" (para códigos |cff...).
function NC.ThemeHex(key)
    local c = (NC.Theme and NC.Theme[key]) or { 1, 1, 1 }
    return string.format("%02x%02x%02x",
        math.floor((c[1] or 1) * 255 + 0.5),
        math.floor((c[2] or 1) * 255 + 0.5),
        math.floor((c[3] or 1) * 255 + 0.5))
end

-- Skinea un botón según el TEMA:
--   modern  -> oculta la cara Blizzard + fondo oscuro/acento (estilo tarjeta)
--   classic -> restaura la cara Blizzard original (rojo del cliente) + sin backdrop
-- Se registra y alterna solo al cambiar de tema.
function NC.SkinButton(btn)
    if not btn then return btn end
    local fs = btn.GetFontString and btn:GetFontString()
    if not fs then return btn end   -- botones de icono/flecha (desplegable, scroll, cerrar): no tocar
    if not btn._ncApply then
        local function faces(hide)
            for _, k in ipairs({ "Normal", "Pushed", "Highlight", "Disabled" }) do
                local get = btn["Get" .. k .. "Texture"]
                local t = get and get(btn)
                if t then t:SetAlpha(hide and 0 or 1) end
            end
        end
        btn._ncApply = function()
            local modern = (NC.Theme and NC.Theme.name == "modern")
            if modern then
                faces(true)
                local ac = NC.Theme.accent
                local on
                if btn._enabled ~= nil then on = btn._enabled
                else on = (not btn.IsEnabled) or (btn:IsEnabled() and true or false) end
                if btn.SetBackdrop then
                    btn:SetBackdrop({
                        bgFile = "Interface\\Buttons\\WHITE8X8",
                        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
                        insets = { left = 1, right = 1, top = 1, bottom = 1 },
                    })
                    if not on then
                        btn:SetBackdropColor(0.07, 0.07, 0.09, 0.9)
                        btn:SetBackdropBorderColor(0.30, 0.30, 0.33, 0.5)
                    elseif btn._locked then
                        btn:SetBackdropColor(ac[1] * 0.5, ac[2] * 0.6, ac[3] * 0.8, 1)   -- seleccionado
                        btn:SetBackdropBorderColor(ac[1], ac[2], ac[3], 1)
                    else
                        btn:SetBackdropColor(0.13, 0.16, 0.22, 0.95)
                        btn:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.8)
                    end
                end
                if fs then
                    if on then fs:SetTextColor(0.95, 0.95, 1) else fs:SetTextColor(0.45, 0.45, 0.5) end
                end
            else
                if btn.GetBackdrop and btn:GetBackdrop() then
                    btn:SetBackdropColor(0, 0, 0, 0); btn:SetBackdropBorderColor(0, 0, 0, 0)
                end
                faces(false)
                if fs then fs:SetTextColor(1.0, 0.82, 0.0) end
            end
        end
        if btn.HookScript then
            btn:HookScript("OnEnter", function(s)
                if not (NC.Theme and NC.Theme.name == "modern") then return end
                if s.IsEnabled and not s:IsEnabled() then return end
                local ac = NC.Theme.accent
                if s.SetBackdropColor then s:SetBackdropColor(ac[1] * 0.5, ac[2] * 0.6, ac[3] * 0.8, 1) end
                if s.SetBackdropBorderColor then s:SetBackdropBorderColor(ac[1], ac[2], ac[3], 1) end
            end)
            btn:HookScript("OnLeave", function(s)
                if not (NC.Theme and NC.Theme.name == "modern") then return end
                if s._ncApply then s._ncApply() end   -- restaura el estado real (base o atenuado)
            end)
        end
        -- reflejar el estado "seleccionado" (LockHighlight) también en modern
        if hooksecurefunc and btn.LockHighlight then
            hooksecurefunc(btn, "LockHighlight", function(s) s._locked = true; if s._ncApply then s._ncApply() end end)
            hooksecurefunc(btn, "UnlockHighlight", function(s) s._locked = false; if s._ncApply then s._ncApply() end end)
        end
        if NC.RegisterThemeable then NC.RegisterThemeable(btn._ncApply) end
    end
    btn._ncApply()
    return btn
end

-- Activa/desactiva un botón reflejando el estado en el tema (como en Campos de
-- batalla). Úsalo en vez de Enable()/Disable() directos para que el botón
-- muestre el look desactivado del tema en Moderno.
function NC.SetButtonEnabled(b, on)
    if not b then return end
    on = on and true or false
    if b._enabled == on then return end
    b._enabled = on
    if on then if b.Enable then b:Enable() end else if b.Disable then b:Disable() end end
    if b._ncApply then b._ncApply() end
end

-- Casilla según el TEMA:
--   modern  -> cuadrado oscuro con borde de acento; al MARCAR se rellena de
--              acento (cuadrado lleno); vacío = desmarcado.
--   classic -> casilla Blizzard por defecto.
function NC.SkinCheckbox(cb)
    if not cb then return cb end
    if not cb._ncApply then
        -- relleno de acento para el estado marcado (solo en modern)
        local fill = cb:CreateTexture(nil, "ARTWORK")
        fill:SetTexture(1, 1, 1)
        fill:SetPoint("TOPLEFT", 5, -5)
        fill:SetPoint("BOTTOMRIGHT", -5, 5)
        fill:Hide()
        cb._ncFill = fill
        local function updateFill()
            if NC.Theme and NC.Theme.name == "modern" and cb.GetChecked and cb:GetChecked() then
                local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
                fill:SetVertexColor(ac[1], ac[2], ac[3], 1)
                fill:Show()
            else
                fill:Hide()
            end
        end
        if cb.HookScript then cb:HookScript("OnClick", updateFill) end
        if hooksecurefunc then hooksecurefunc(cb, "SetChecked", function() updateFill() end) end
        cb._ncApply = function()
            local modern = (NC.Theme and NC.Theme.name == "modern")
            local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
            local nt = cb.GetNormalTexture and cb:GetNormalTexture()
            local pt = cb.GetPushedTexture and cb:GetPushedTexture()
            local dt = cb.GetDisabledTexture and cb:GetDisabledTexture()
            local ck = cb.GetCheckedTexture and cb:GetCheckedTexture()
            if modern then
                if nt then nt:SetAlpha(0) end
                if pt then pt:SetAlpha(0) end
                if dt then dt:SetAlpha(0) end
                if ck then ck:SetAlpha(0) end   -- ocultamos la marca; usamos el relleno
                if cb.SetBackdrop then
                    cb:SetBackdrop({
                        bgFile = "Interface\\Buttons\\WHITE8X8",
                        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
                        insets = { left = 1, right = 1, top = 1, bottom = 1 },
                    })
                    cb:SetBackdropColor(0.10, 0.10, 0.13, 0.9)
                    cb:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.85)
                end
            else
                if cb.GetBackdrop and cb:GetBackdrop() then
                    cb:SetBackdropColor(0, 0, 0, 0); cb:SetBackdropBorderColor(0, 0, 0, 0)
                end
                if nt then nt:SetAlpha(1) end
                if pt then pt:SetAlpha(1) end
                if dt then dt:SetAlpha(1) end
                if ck then ck:SetAlpha(1); ck:SetVertexColor(1, 1, 1) end
            end
            updateFill()
        end
        if NC.RegisterThemeable then NC.RegisterThemeable(cb._ncApply) end
    end
    cb._ncApply()
    return cb
end

-- Campo de texto (EditBox): modern -> fondo oscuro + borde de acento;
-- classic -> vuelve a las texturas Blizzard del template.
function NC.SkinEditBox(eb)
    if not eb then return eb end
    if not eb._ncApply then
        eb._ncTex = {}
        if eb.GetRegions then
            for _, r in ipairs({ eb:GetRegions() }) do
                if r.GetObjectType and r:GetObjectType() == "Texture" then
                    eb._ncTex[#eb._ncTex + 1] = r
                end
            end
        end
        eb._ncApply = function()
            local modern = (NC.Theme and NC.Theme.name == "modern")
            local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
            if modern then
                for _, r in ipairs(eb._ncTex) do r:SetAlpha(0) end
                if eb.SetBackdrop then
                    eb:SetBackdrop({
                        bgFile = "Interface\\Buttons\\WHITE8X8",
                        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
                        insets = { left = 1, right = 1, top = 1, bottom = 1 },
                    })
                    eb:SetBackdropColor(0.08, 0.09, 0.12, 0.95)
                    eb:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.8)
                end
                if eb.SetTextColor then eb:SetTextColor(0.95, 0.95, 1) end
            else
                if eb.GetBackdrop and eb:GetBackdrop() then
                    eb:SetBackdropColor(0, 0, 0, 0); eb:SetBackdropBorderColor(0, 0, 0, 0)
                end
                for _, r in ipairs(eb._ncTex) do r:SetAlpha(1) end
                if eb.SetTextColor then eb:SetTextColor(1, 1, 1) end
            end
        end
        if NC.RegisterThemeable then NC.RegisterThemeable(eb._ncApply) end
    end
    eb._ncApply()
    return eb
end

-- Desplegable (UIDropDownMenu con nombre): recuadro oscuro en modern / Blizzard
-- en classic. El cambio se aplica DIFERIDO (frame siguiente) porque hacerlo
-- durante el clic del propio desplegable crasheaba el cliente.
function NC.SkinDropdown(dd)
    if not dd or not dd.GetName or not dd:GetName() then return dd end
    if not dd._ncApply then
        local name = dd:GetName()
        local left, mid, right = _G[name .. "Left"], _G[name .. "Middle"], _G[name .. "Right"]
        local arrow = _G[name .. "Button"]
        local bgf = CreateFrame("Frame", nil, dd)
        bgf:SetFrameLevel(math.max(0, dd:GetFrameLevel()))
        bgf:SetHeight(26)
        bgf:SetPoint("LEFT", dd, "LEFT", 16, 0)
        bgf:SetPoint("RIGHT", dd, "RIGHT", -14, 0)
        bgf:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
            insets = { left = 1, right = 1, top = 1, bottom = 1 },
        })
        bgf:Hide()
        -- barra de acento a la izquierda (firma visual del addon)
        local accentBar = bgf:CreateTexture(nil, "ARTWORK")
        accentBar:SetPoint("TOPLEFT", 3, -3)
        accentBar:SetPoint("BOTTOMLEFT", 3, 3)
        accentBar:SetWidth(3)
        accentBar:SetTexture(1, 1, 1)
        local function doBox()
            local modern = (NC.Theme and NC.Theme.name == "modern")
            local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
            local at = arrow and arrow.GetNormalTexture and arrow:GetNormalTexture()
            local ap = arrow and arrow.GetPushedTexture and arrow:GetPushedTexture()
            if modern then
                if left then left:Hide() end
                if mid then mid:Hide() end
                if right then right:Hide() end
                bgf:SetBackdropColor(0.10, 0.10, 0.13, 0.95)
                bgf:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.8)
                bgf:Show()
                accentBar:SetVertexColor(ac[1], ac[2], ac[3], 1)
                if at then at:SetVertexColor(ac[1], ac[2], ac[3]) end
                if ap then ap:SetVertexColor(ac[1], ac[2], ac[3]) end
            else
                bgf:Hide()
                if left then left:Show() end
                if mid then mid:Show() end
                if right then right:Show() end
                if at then at:SetVertexColor(1, 1, 1) end
                if ap then ap:SetVertexColor(1, 1, 1) end
            end
        end
        -- diferidor de un disparo: ejecuta doBox en el frame siguiente
        local defer = CreateFrame("Frame")
        defer:Hide()
        defer:SetScript("OnUpdate", function(self) self:Hide(); doBox() end)
        dd._ncApply = function() defer:Show() end
        if NC.RegisterThemeable then NC.RegisterThemeable(dd._ncApply) end
    end
    dd._ncApply()
    return dd
end

-- Barra de scroll (Slider): tinta el pulgar con el acento en modern.
function NC.SkinScrollBar(sb)
    if not sb then return sb end
    if not sb._ncApply then
        sb._ncApply = function()
            local th = sb.GetThumbTexture and sb:GetThumbTexture()
            if th and th.SetVertexColor then
                if NC.Theme and NC.Theme.name == "modern" then
                    local ac = NC.Theme.accent
                    th:SetVertexColor(ac[1], ac[2], ac[3])
                else
                    th:SetVertexColor(1, 1, 1)
                end
            end
        end
        if NC.RegisterThemeable then NC.RegisterThemeable(sb._ncApply) end
    end
    sb._ncApply()
    return sb
end

-- Skiniza la barra de un ScrollFrame buscando su hijo Slider. Sirve para
-- teñir de forma consistente scrolls que no pasan por SkinPanel (p.ej. los de
-- Campos de batalla, marcado con _ncSkip, o ventanas secundarias).
function NC.SkinScrollOf(sf)
    if not sf or not sf.GetChildren then return end
    for _, c in ipairs({ sf:GetChildren() }) do
        if c.GetObjectType and c:GetObjectType() == "Slider" then
            NC.SkinScrollBar(c)
        end
    end
end

-- Skinea (recursivo) botones, casillas, campos de texto y barras de scroll de
-- un panel y sus descendientes. Un marco con _ncSkip = true (y su contenido)
-- se ignora (p.ej. la pestaña de Campos de Batalla, que ya tiene su estilo).
function NC.SkinPanel(panel)
    if not panel or panel._ncSkip or not panel.GetChildren then return end
    for _, child in ipairs({ panel:GetChildren() }) do
        if not child._ncSkip then
            local ot = child.GetObjectType and child:GetObjectType()
            if ot == "Button" then NC.SkinButton(child)
            elseif ot == "CheckButton" then NC.SkinCheckbox(child)
            elseif ot == "EditBox" then NC.SkinEditBox(child)
            elseif ot == "Slider" then NC.SkinScrollBar(child) end
            NC.SkinPanel(child)
        end
    end
end

-- Desplegable PROPIO (sin UIDropDownMenu): estilo del addon completo, con
-- recuadro oscuro, barra de acento, flecha propia y lista desplegable propia.
-- Sigue el tema (acento). opts = {
--   width, choices = {{value=, text=}, ...},
--   get = function() return valorActual end,
--   onChange = function(valorNuevo) end }
function NC.CreateDropdown(parent, opts)
    opts = opts or {}
    local choices = opts.choices or {}
    local dd = CreateFrame("Button", nil, parent)
    dd:SetSize(opts.width or 150, 24)
    dd:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    local bar = dd:CreateTexture(nil, "ARTWORK")
    bar:SetPoint("TOPLEFT", 2, -2); bar:SetPoint("BOTTOMLEFT", 2, 2); bar:SetWidth(3)
    bar:SetTexture(1, 1, 1)
    local valueFS = dd:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    valueFS:SetPoint("LEFT", 10, 0); valueFS:SetPoint("RIGHT", -22, 0); valueFS:SetJustifyH("CENTER")
    local arrow = dd:CreateTexture(nil, "OVERLAY")
    arrow:SetSize(12, 12); arrow:SetPoint("RIGHT", -6, 0)
    arrow:SetTexture("Interface\\Buttons\\Arrow-Down-Up")

    local list = CreateFrame("Frame", nil, dd)
    list:SetPoint("TOPLEFT", dd, "BOTTOMLEFT", 0, -2)
    list:SetPoint("TOPRIGHT", dd, "BOTTOMRIGHT", 0, -2)
    list:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    list:SetFrameStrata("DIALOG")
    list:Hide()

    local rows = {}
    local ROW = 22
    for i, c in ipairs(choices) do
        local b = CreateFrame("Button", nil, list)
        b:SetHeight(ROW)
        b:SetPoint("TOPLEFT", 3, -3 - (i - 1) * ROW)
        b:SetPoint("RIGHT", list, "RIGHT", -3, 0)
        local hl = b:CreateTexture(nil, "BACKGROUND"); hl:SetAllPoints(); hl:SetTexture(1, 1, 1); hl:SetAlpha(0)
        local fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        fs:SetPoint("LEFT", 10, 0); fs:SetText(c.text)
        b.fs, b.hl, b.value = fs, hl, c.value
        b:SetScript("OnEnter", function(s)
            local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
            s.hl:SetVertexColor(ac[1], ac[2], ac[3]); s.hl:SetAlpha(0.35)
        end)
        b:SetScript("OnLeave", function(s) s.hl:SetAlpha(0) end)
        b:SetScript("OnClick", function(s)
            valueFS:SetText(c.text)
            list:Hide()
            if opts.onChange then opts.onChange(s.value) end
        end)
        rows[i] = b
    end
    list:SetHeight(6 + #choices * ROW)

    dd:SetScript("OnClick", function() if list:IsShown() then list:Hide() else list:Show() end end)

    local function refreshValue()
        local v = opts.get and opts.get()
        for _, c in ipairs(choices) do if c.value == v then valueFS:SetText(c.text); return end end
        if choices[1] then valueFS:SetText(choices[1].text) end
    end
    refreshValue()

    local function skin()
        local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
        dd:SetBackdropColor(0.10, 0.10, 0.13, 0.95); dd:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.85)
        bar:SetVertexColor(ac[1], ac[2], ac[3], 1)
        arrow:SetVertexColor(ac[1], ac[2], ac[3])
        list:SetBackdropColor(0.07, 0.07, 0.10, 0.98); list:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.85)
    end
    if NC.RegisterThemeable then NC.RegisterThemeable(skin) else skin() end

    dd.Refresh = refreshValue
    return dd
end
