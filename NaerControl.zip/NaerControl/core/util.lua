local ADDON, NC = ...

local CFG, COL = NC.CFG, NC.COL

------------------------------------------------------------
-- Salida por chat
------------------------------------------------------------
function NC.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage(NC.TAG .. (msg or ""))
    if NC.Console and NC.Console.LogInfo and not NC._suppressConsole then
        NC.Console:LogInfo(msg or "")
    end
end

function NC.Warn(msg)
    NC._suppressConsole = true
    NC.Print(COL.warn .. (msg or "") .. COL.r)
    NC._suppressConsole = false
    if NC.Console and NC.Console.LogWarn then NC.Console:LogWarn(msg or "") end
end

------------------------------------------------------------
-- Texto: quita acentos y baja a minusculas.
-- Sirve para comparar respuestas del servidor sin depender de la
-- codificacion ni de %a (que en 3.3.5a no cubre acentos).
------------------------------------------------------------
local ACCENTS = {
    ["á"]="a", ["é"]="e", ["í"]="i", ["ó"]="o", ["ú"]="u", ["ü"]="u", ["ñ"]="n",
    ["Á"]="a", ["É"]="e", ["Í"]="i", ["Ó"]="o", ["Ú"]="u", ["Ü"]="u", ["Ñ"]="n",
}

function NC.Normalize(s)
    if not s then return "" end
    s = string.lower(s)
    for k, v in pairs(ACCENTS) do
        s = string.gsub(s, k, v)
    end
    return s
end

------------------------------------------------------------
-- Validacion de entradas
------------------------------------------------------------
function NC.ValidateInput(kind, text)
    text = string.gsub(text or "", "^%s*(.-)%s*$", "%1")

    if kind == "none" then
        return true, nil
    end

    if text == "" then
        return false, "Escribe un valor antes de aplicar."
    end

    if kind == "number" then
        local n = tonumber(text)
        if not n or n < 0 or n ~= math.floor(n) then
            return false, "Ese campo solo admite un número entero."
        end
        return true, tostring(n)
    end

    if kind == "item" then
        local id = tonumber(text)
        if not id then
            id = tonumber(string.match(text, "Hitem:(%d+)"))
        end
        if not id then
            return false, "Escribe un ID numérico o enlaza un objeto con Mayús+clic."
        end
        return true, tostring(id)
    end

    if kind == "name" then
        if string.find(text, "%s") then
            return false, "El nombre no puede llevar espacios."
        end
        if string.len(text) < 2 or string.len(text) > 12 then
            return false, "El nombre debe tener entre 2 y 12 caracteres."
        end
        return true, text
    end

    return true, text
end

------------------------------------------------------------
-- Cola de envio con ventana deslizante.
--
-- NAERZONE corta a 2 consultas cada 10 segundos y el castigo por pasarse
-- es un silencio en el chat, no un mensaje de error. Asi que el limitador
-- es una red de seguridad, no una optimizacion: nunca envia si en los
-- ultimos RateWindow segundos ya se han hecho RateMax envios.
------------------------------------------------------------
local queue = {}
local sentAt = {}        -- marcas de tiempo de los ultimos envios
local sender = CreateFrame("Frame")
sender:Hide()

local function Purge(now)
    local limit = now - (CFG.RateWindow + CFG.RateSafety)
    local i = 1
    while i <= table.getn(sentAt) do
        if sentAt[i] < limit then
            table.remove(sentAt, i)
        else
            i = i + 1
        end
    end
end

-- Segundos que faltan para poder enviar. 0 = via libre.
-- Devuelve el MAXIMO de las dos restricciones (intervalo entre envios y ventana
-- deslizante). Antes devolvia primero el intervalo y luego "saltaba" al de la
-- ventana, lo que hacia que la cuenta atras de los botones fuera a trompicones
-- (p.ej. 3s y luego 6s).
local function WaitTime(now)
    Purge(now)
    local n = table.getn(sentAt)
    local wait = 0

    if n > 0 then
        local gap = CFG.SendInterval - (now - sentAt[n])
        if gap > wait then wait = gap end
    end

    if n >= CFG.RateMax then
        -- hay que esperar a que el mas antiguo salga de la ventana
        local libre = sentAt[n - CFG.RateMax + 1] + CFG.RateWindow + CFG.RateSafety
        local w = libre - now
        if w > wait then wait = w end
    end

    return wait
end

-- Segundos que faltan para poder enviar un comando (0 = via libre). Lo usa la
-- UI para poner en gris los botones de consulta cuando se alcanza el limite.
function NC.SendWaitTime()
    return WaitTime(GetTime())
end

local function DoSend(entry)
    local db = NC.db
    if db and db.sendMode == "SAY" then
        SendChatMessage(entry.text, "SAY")
    else
        SendChatMessage(entry.text, "WHISPER", nil, UnitName("player"))
    end
    table.insert(sentAt, GetTime())
    if NC.Console then NC.Console:LogSent(entry.text) end
    if entry.onSent then entry.onSent() end
end

sender:SetScript("OnUpdate", function(self)
    if table.getn(queue) == 0 then
        self:Hide()
        return
    end
    if WaitTime(GetTime()) > 0 then return end
    DoSend(table.remove(queue, 1))
end)

function NC.Send(cmd, onSent)
    if not cmd or cmd == "" then return end

    local db = NC.db
    if db and not db.warnedSend then
        db.warnedSend = true
        if db.sendMode == "WHISPER" then
            NC.Print(COL.soft .. "Los comandos se envían como susurro a ti mismo. "
                .. "Si el servidor no responde, prueba " .. COL.r .. COL.accent .. "/nc modo say" .. COL.r .. ".")
        end
    end

    table.insert(queue, { text = cmd, onSent = onSent })
    sender:Show()
end

function NC.QueueSize()
    return table.getn(queue)
end

-- ¿Estamos en el tope del límite de envíos? true si ahora mismo no se puede
-- enviar (por intervalo o por ventana llena), aunque la cola esté vacía.
-- Sirve para poner los botones en gris cuando el servidor no aceptaría más.
function NC.AtRateLimit()
    return WaitTime(GetTime()) > 0
end

-- Devuelve: pendientes, segundos para el siguiente envio
function NC.QueueInfo()
    local n = table.getn(queue)
    if n == 0 then return 0, 0 end
    return n, WaitTime(GetTime())
end

-- Segundos estimados para vaciar una cola de n elementos
function NC.EstimateTime(n)
    if n <= 0 then return 0 end
    local ventanas = math.floor((n - 1) / CFG.RateMax)
    return ventanas * (CFG.RateWindow + CFG.RateSafety)
        + ((n - 1) - ventanas * CFG.RateMax) * CFG.SendInterval
end

function NC.ClearQueue()
    local n = table.getn(queue)
    while table.getn(queue) > 0 do table.remove(queue) end
    sender:Hide()
    return n
end

------------------------------------------------------------
-- Objetos
------------------------------------------------------------
local QUALITY_HEX = {
    [0] = "|cff9d9d9d", [1] = "|cffffffff", [2] = "|cff1eff00",
    [3] = "|cff0070dd", [4] = "|cffa335ee", [5] = "|cffff8000",
}

-- Devuelve nombre (coloreado por calidad si el cliente lo conoce).
-- fallback = el "name" guardado en data.lua.
function NC.ItemName(id, fallback)
    local name, _, quality = GetItemInfo(id)
    if name then
        local hex = QUALITY_HEX[quality or 1] or "|cffffffff"
        return hex .. name .. "|r", true
    end
    return (fallback or ("Objeto " .. tostring(id))), false
end

function NC.ItemIcon(id)
    return GetItemIcon(id) or NC.UNKNOWN_ICON
end

-- Iconos de jefe y de banda.
--
-- Se derivan de la tabla de botin: cogemos un objeto EXCLUSIVO de ese jefe
-- (saltandonos trofeos y emblemas, que se repiten en varios y harian que
-- media banda compartiera icono) y le pedimos su textura al cliente.
-- GetItemIcon resuelve desde el DBC aunque el objeto no este en cache, asi
-- que nunca puede quedar un hueco en blanco.
local bossIconCache = {}
local raidIconCache = {}
local sharedCache   = {}

-- IDs que aparecen en mas de un jefe del mismo modo
local function SharedIDs(mode)
    if sharedCache[mode] then return sharedCache[mode] end

    local veces, compartidos = {}, {}
    local data = NC.GetModeLoot(mode)
    if data then
        for _, list in pairs(data) do
            local vistosAqui = {}
            for _, it in ipairs(list) do
                if not vistosAqui[it.id] then
                    vistosAqui[it.id] = true
                    veces[it.id] = (veces[it.id] or 0) + 1
                end
            end
        end
        for id, n in pairs(veces) do
            if n > 1 then compartidos[id] = true end
        end
    end

    sharedCache[mode] = compartidos
    return compartidos
end

-- Primer objeto exclusivo de un jefe; si no hay ninguno, el primero que sea
local function IconItem(mode, bossName)
    local list = NC.GetBossLoot(mode, bossName)
    if not list or table.getn(list) == 0 then return nil end

    local compartidos = SharedIDs(mode)
    for _, it in ipairs(list) do
        if not compartidos[it.id] then return it.id end
    end
    return list[1].id
end

function NC.BossIcon(bossName, mode)
    local cached = bossIconCache[bossName]
    if cached then return cached end

    -- 1) retrato del jefe confirmado (Achievement_Boss_*)
    local tex = NC.BOSS_ICON_TEX and NC.BOSS_ICON_TEX[bossName]
    if tex then
        bossIconCache[bossName] = tex
        return tex
    end

    -- 2) icono elegido a mano: un objeto reconocible del jefe
    local pref = NC.BOSS_ICON and NC.BOSS_ICON[bossName]
    if pref then
        local t = GetItemIcon(pref)
        if t then
            bossIconCache[bossName] = t
            return t
        end
    end

    -- 3) si no, un objeto exclusivo del jefe
    local id = IconItem(mode, bossName)
    if id then
        local t = GetItemIcon(id)
        if t then
            bossIconCache[bossName] = t
            return t
        end
    end
    return NC.UNKNOWN_ICON
end

-- Icono de la banda: el del jefe final, para que las cuatro dificultades
-- compartan imagen.
function NC.RaidIcon(raid, mode)
    if NC.RAID_ICON[raid] then return NC.RAID_ICON[raid] end
    if raidIconCache[raid] then return raidIconCache[raid] end

    local bosses = NC.BOSSES[raid] or {}
    for i = table.getn(bosses), 1, -1 do
        local b = bosses[i]
        if NC.BossAvailable(b, mode) then
            local id = IconItem(mode, b.name)
            if id then
                local tex = GetItemIcon(id)
                if tex then
                    raidIconCache[raid] = tex
                    return tex
                end
            end
        end
    end
    return NC.UNKNOWN_ICON
end

-- Al cambiar de faccion las tablas cambian: hay que recalcular
function NC.ResetIconCache()
    bossIconCache = {}
    raidIconCache = {}
    sharedCache   = {}
end

------------------------------------------------------------
-- Objetivo valido para .player iteminfo
------------------------------------------------------------
function NC.GetValidTarget()
    if not UnitExists("target") then
        return nil, "Selecciona a un jugador primero."
    end
    if not UnitIsPlayer("target") then
        return nil, "El objetivo tiene que ser un jugador."
    end
    if UnitIsUnit("target", "player") then
        return nil, "El objetivo no puede ser tú mismo."
    end
    return UnitName("target")
end

------------------------------------------------------------
-- Comprobacion de integridad de data.lua (para /nc diag)
------------------------------------------------------------
function NC.CheckData()
    local problems = {}

    for _, mode in ipairs(NC.MODES) do
        local data = NC.GetModeLoot(mode.key)
        if not data then
            table.insert(problems, "Falta el modo " .. mode.key .. " en data.lua")
        else
            for _, boss in ipairs(NC.BOSSES[mode.raid]) do
                local list = data[boss.name]
                local esperado = NC.BossAvailable(boss, mode.key)
                if not list and esperado then
                    table.insert(problems, mode.key .. ": sin datos para " .. boss.name)
                elseif list then
                    local seen = {}
                    for _, it in ipairs(list) do
                        if not it.id then
                            table.insert(problems, mode.key .. "/" .. boss.name .. ": objeto sin id")
                        elseif seen[it.id] then
                            table.insert(problems, mode.key .. "/" .. boss.name
                                .. ": id " .. it.id .. " repetido (" .. tostring(it.name) .. ")")
                        else
                            seen[it.id] = true
                        end
                    end
                end
            end
        end
    end

    return problems
end


------------------------------------------------------------
-- Shared link routing for addon edit boxes. Keep one wrapper, preserve
-- the previous function and leave Blizzard's own inputs in control.
------------------------------------------------------------
local linkTargets = {}
local linkNameTargets = {}
local originalInsertLink

function NC.IsBlizzardLinkInputActive()
    local active = type(ChatEdit_GetActiveWindow) == "function"
        and ChatEdit_GetActiveWindow()
    if active and active:IsVisible() then return true end

    -- Friend/ignore/invite dialogs must continue to receive player names.
    for i = 1, (STATICPOPUP_NUMDIALOGS or 4) do
        local box = _G["StaticPopup" .. i .. "EditBox"]
        local wide = _G["StaticPopup" .. i .. "WideEditBox"]
        if (box and box:IsVisible()) or (wide and wide:IsVisible()) then
            return true
        end
    end
    return HelpFrameOpenTicketEditBox and HelpFrameOpenTicketEditBox:IsVisible()
        or false
end

function NC.RegisterLinkTarget(editbox, nameOnly)
    if not editbox then return end
    local found = false
    for _, box in ipairs(linkTargets) do
        if box == editbox then found = true; break end
    end
    if not found then table.insert(linkTargets, editbox) end
    linkNameTargets[editbox] = nameOnly == true

    if originalInsertLink or type(ChatEdit_InsertLink) ~= "function" then return end
    originalInsertLink = ChatEdit_InsertLink

    ChatEdit_InsertLink = function(text, ...)
        if type(text) == "string" and not NC.IsBlizzardLinkInputActive() then
            for _, box in ipairs(linkTargets) do
                if box:IsVisible() and box:HasFocus() then
                    if linkNameTargets[box] then
                        local name = string.match(text, "|h%[(.-)%]|h")
                            or string.match(text, "%[(.-)%]") or text
                        box:Insert(name)
                    else
                        box:SetText(text)
                    end
                    return true
                end
            end
        end
        return originalInsertLink(text, ...)
    end
end

------------------------------------------------------------
-- Parser de xprate. Formatos reales de NAERZONE:
--   "Quest rate establecido a: 1.000000"   -> quest = 1
--   "Kill rate establecido a: 8.000000"    -> kill  = 8
--   bloque "Kill: x8.000000 / Quest: x8.000000 / Explore: x1.000000"
-- Devuelve { quest = N, kill = N, explore = N } con lo que encuentre, o nil.
------------------------------------------------------------
------------------------------------------------------------
-- Parsers de eventos (.event activelist y .event info).
------------------------------------------------------------

-- Quita los códigos de color de WoW (|cffRRGGBB ... |r) y enlaces, dejando
-- el texto plano. Los mensajes de .event vienen coloreados, y sin limpiar
-- esto el número inicial no está al principio de la cadena.
-- ¿Es una línea de respuesta de eventos? (para registro en consola)
function NC.IsEventLine(msg)
    if type(msg) ~= "string" then return false end
    if NC.ParseEventListLine(msg) then return true end
    if NC.ParseEventInfo(msg) then return true end
    return false
end

function NC.StripColors(s)
    if type(s) ~= "string" then return "" end
    -- Case-insensitive: este servidor manda algunos códigos con |C en MAYÚSCULA
    -- (p.ej. en las líneas de .raid list). WoW los renderiza igual, pero si no
    -- los quitamos, string.match coge los dígitos del color (ff00ff00 -> "00").
    s = string.gsub(s, "|[cC]%x%x%x%x%x%x%x%x", "")   -- |cRRGGBB / |CRRGGBB
    s = string.gsub(s, "|[rR]", "")                    -- fin de color
    s = string.gsub(s, "|[Hh].-|[hH]", "")             -- hipervínculo
    s = string.gsub(s, "|[hH]", "")
    s = string.gsub(s, "\194\160", " ")             -- NBSP UTF-8 (0xC2 0xA0)
    s = string.gsub(s, "\160", " ")                 -- NBSP Latin-1 (0xA0)
    s = string.gsub(s, "\226\128\175", " ")         -- espacio fino (0xE2 0x80 0xAF)
    s = string.gsub(s, "\226\128\139", "")          -- zero-width (0xE2 0x80 0x8B)
    return s
end

-- Una línea de activelist: "3 - [Nombre del evento] [active]"
-- Devuelve id, nombre, activo(bool) o nil si no encaja.
function NC.ParseEventListLine(msg)
    if type(msg) ~= "string" then return nil end
    msg = NC.StripColors(msg)
    local id, name = string.match(msg, "^%s*(%d+)%s*%-%s*%[(.-)%]")
    if not id then return nil end
    local active = string.find(msg, "%[active%]") ~= nil
    return tonumber(id), strtrim(name or ""), active
end

-- Cabecera de .event info: "Event 3: Nombre ( zona ) [active]"
-- Bloque siguiente: "Start: FECHA End: FECHA Occurence: N Days Length: N Days"
--                   "Next state change: FECHA"
-- Fechas con formato "2026-08-02_00-00-00".
-- Devuelve una tabla con lo que encuentre, o nil.
function NC.ParseEventInfo(msg)
    if type(msg) ~= "string" then return nil end
    msg = NC.StripColors(msg)

    -- cabecera: "Event N: Nombre" con o sin "[active]" al final.
    -- Algunos eventos vienen sin corchete (p.ej. "Event 67: AT Event Trigger
    -- (Tirion Speech)"), así que no exigimos el "[".
    local id, name = string.match(msg, "^Event%s+(%d+):%s*(.+)$")
    if id then
        local active = string.find(msg, "%[active%]") ~= nil
        -- quitar el sufijo "[active]" del nombre si lo lleva
        name = strtrim((string.gsub(name or "", "%s*%[active%]%s*$", "")))
        return { kind = "header", id = tonumber(id), name = name, active = active }
    end

    -- linea de fechas
    local startD = string.match(msg, "Start:%s*([%d%-_]+)")
    local endD   = string.match(msg, "End:%s*([%d%-_]+)")
    local occ    = string.match(msg, "Occurence:%s*(%d+)")
    local len    = string.match(msg, "Length:%s*(%d+)")
    if startD or endD or occ or len then
        return { kind = "dates", startD = startD, endD = endD,
                 occurrence = tonumber(occ), length = tonumber(len) }
    end

    -- proximo cambio de estado
    local nextD = string.match(msg, "Next state change:%s*([%d%-_]+)")
    if nextD then
        return { kind = "next", nextChange = nextD }
    end

    return nil
end

-- Convierte "2026-08-02_00-00-00" a epoch (asumiendo hora del servidor).
function NC.EventDateToEpoch(s)
    if type(s) ~= "string" then return nil end
    local y, mo, d, h, mi, se = string.match(s, "(%d+)%-(%d+)%-(%d+)_(%d+)%-(%d+)%-(%d+)")
    if not y then return nil end
    return time({ year = tonumber(y), month = tonumber(mo), day = tonumber(d),
                  hour = tonumber(h), min = tonumber(mi), sec = tonumber(se) })
end

-- ¿Es una línea CUALQUIERA del bloque de respuesta de .xprate? El servidor
-- manda cabeceras, texto de ayuda y valores; hay que reconocer todo el bloque
-- para ocultarlo, no solo las líneas de valores.
function NC.IsXpRateLine(msg)
    if type(msg) ~= "string" then return false end
    -- limpiar colores y normalizar (minúsculas, sin acentos)
    local clean = NC.StripColors and NC.StripColors(msg) or msg
    local n = NC.Normalize(clean)
    n = strtrim(n or "")
    if NC.ParseXpRate(msg) then return true end
    if string.find(n, "xp rates naerzone", 1, true) then return true end
    if string.find(n, "tus rates", 1, true) then return true end
    if string.find(n, ".xprate", 1, true) then return true end
    if string.find(n, "rates globales del reino", 1, true) then return true end
    -- líneas de valores: "kill: x8", "quest: x8", "explore: x1" (en cualquier posición)
    if string.find(n, "kill:%s*x%d") then return true end
    if string.find(n, "quest:%s*x%d") then return true end
    if string.find(n, "explore:%s*x%d") then return true end
    -- línea separadora de solo signos "="
    if string.find(n, "^=+$") then return true end
    return false
end

function NC.ParseXpRate(msg)
    if type(msg) ~= "string" then return nil end
    local clean = NC.StripColors and NC.StripColors(msg) or msg
    local norm = NC.Normalize(clean)
    local found, res = false, {}

    local q = string.match(norm, "quest rate establecido a:%s*x?(%d+)")
    if q then res.quest = tonumber(q); found = true end
    local k = string.match(norm, "kill rate establecido a:%s*x?(%d+)")
    if k then res.kill = tonumber(k); found = true end

    local bk = string.match(norm, "kill:%s*x(%d+)")
    if bk then res.kill = tonumber(bk); found = true end
    local bq = string.match(norm, "quest:%s*x(%d+)")
    if bq then res.quest = tonumber(bq); found = true end
    local be = string.match(norm, "explore:%s*x(%d+)")
    if be then res.explore = tonumber(be); found = true end

    if not found then return nil end
    return res
end

------------------------------------------------------------
-- Parser de .player iteminfo. Formatos reales:
--   "Objeto encontrado en inventario/banco: ID 50457, Cantidad 1, Jugador: Odnel"
--   "Objeto no encontrado: ID 49623, Jugador: Odnel"
-- Devuelve: id, jugador, "yes"|"no", lugar, cantidad
------------------------------------------------------------
function NC.ParseItemInfo(msg)
    if type(msg) ~= "string" then return nil end

    local norm = NC.Normalize(msg)
    if not string.find(norm, "objeto", 1, true) then return nil end

    local state
    if string.find(norm, "no encontrado", 1, true) then
        state = "no"
    elseif string.find(norm, "lista de vendedor", 1, true)
        or string.find(norm, "que se puede recuperar", 1, true) then
        -- el caso clave del ninjeo: vendio el objeto para recuperarlo luego
        state = "sold"
    elseif string.find(norm, "encontrado", 1, true) then
        state = "yes"
    else
        return nil
    end

    local id = tonumber(string.match(norm, "id[:%s]+(%d+)"))
    if not id then return nil end

    -- el nombre se saca del mensaje original para conservar mayusculas
    local player = string.match(msg, "[Jj]ugador:%s*([^%s,%.]+)")
    local count  = tonumber(string.match(norm, "cantidad[:%s]+(%d+)"))
    local place  = string.match(norm, "encontrado en ([^:]+)")

    if state == "sold" then place = "lista de vendedor" end

    return id, player, state, place, count
end


------------------------------------------------------------
-- ¿existe este jefe en esta dificultad?
------------------------------------------------------------
function NC.BossAvailable(boss, modeKey)
    if boss.heroicOnly and not string.find(modeKey, "H$") then
        return false
    end
    return true
end

------------------------------------------------------------
-- Faccion
--
-- El Coliseo es la unica banda de WotLK cuyo botin cambia por faccion,
-- y cambia casi por completo: de los 331 objetos solo coincide el trofeo.
-- Un jugador de Alianza mirando la tabla de Horda veria IDs que ni
-- existen para el, y el addon le diria "no lo tiene" sin fallar.
------------------------------------------------------------
function NC.GetFaction()
    local f = NC.db and NC.db.faction
    if f == "Alliance" or f == "Horde" then return f, true end
    return (UnitFactionGroup("player") or "Horde"), false
end

function NC.FactionLabel(f)
    return (f == "Alliance") and "Alianza" or "Horda"
end

-- ¿este modo tiene tablas separadas por faccion?
function NC.ModeHasFactions(mode)
    return (NC.LootFaction
        and NC.LootFaction.Horde
        and NC.LootFaction.Horde[mode]) and true or false
end

-- Tabla de un modo completo, ya resuelta
function NC.GetModeLoot(mode)
    if NC.ModeHasFactions(mode) then
        local fac = NC.GetFaction()
        return NC.LootFaction[fac] and NC.LootFaction[fac][mode]
    end
    return NC.Loot[mode]
end

-- Lista de objetos de un jefe concreto
function NC.GetBossLoot(mode, boss)
    local d = NC.GetModeLoot(mode)
    return d and d[boss]
end

------------------------------------------------------------
-- Parsers de .player info / .raid list / .raid info (NAERZONE)
-- Las respuestas llegan línea a línea por CHAT_MSG_SYSTEM, coloreadas.
------------------------------------------------------------

-- ¿Es una línea de la cabecera de bloque? (===== XXX NAERZONE =====)
function NC.IsInfoHeader(msg, kind)
    if type(msg) ~= "string" then return false end
    local m = NC.StripColors(msg)
    if kind == "player" then return string.find(m, "PLAYER INFO NAERZONE", 1, true) ~= nil end
    if kind == "raidlist" then return string.find(m, "RAID LIST NAERZONE", 1, true) ~= nil end
    if kind == "raidinfo" then return string.find(m, "RAID INFO NAERZONE", 1, true) ~= nil end
    -- cualquiera
    return string.find(m, "PLAYER INFO NAERZONE", 1, true) ~= nil
        or string.find(m, "RAID LIST NAERZONE", 1, true) ~= nil
        or string.find(m, "RAID INFO NAERZONE", 1, true) ~= nil
end

-- Parsea una línea "Clave: Valor" de player info. Devuelve clave, valor o nil.
function NC.ParsePlayerInfoLine(msg)
    if type(msg) ~= "string" then return nil end
    local m = strtrim(NC.StripColors(msg))
    -- líneas de la forma "Etiqueta: resto"
    local key, val = string.match(m, "^([^:]+):%s*(.+)$")
    if not key then return nil end
    return strtrim(key), strtrim(val)
end

-- ¿Es una línea que pertenece a un bloque de player info? (para ocultar/registrar)
function NC.IsPlayerInfoLine(msg)
    if type(msg) ~= "string" then return false end
    local m = NC.StripColors(msg)
    if NC.IsInfoHeader(msg, "player") then return true end
    -- claves conocidas del bloque
    local keys = { "Nombre:", "Hermandad:", "Clase&Raza:", "Talentos:", "Posible Rol:",
                   "GS total:", "ilvl equipado:", "Equipo de Arenas", "Rated Battleground",
                   "PvERating:" }
    for _, k in ipairs(keys) do
        if string.find(m, k, 1, true) then return true end
    end
    -- línea de ayuda final "Puedes usar .raid list"
    if string.find(m, ".raid list", 1, true) then return true end
    return false
end

-- Parsea una línea de raid list: "Mapa: X, Dificultad: Y  [ACTIVO]" o "RaidID: N"
function NC.ParseRaidListLine(msg)
    if type(msg) ~= "string" then return nil end
    local m = strtrim(NC.StripColors(msg))
    -- normalizar espacios invisibles (por si StripColors no los cubriera)
    m = string.gsub(m, "\194\160", " ")
    m = string.gsub(m, "\160", " ")
    m = string.gsub(m, "\226\128\175", " ")
    m = string.gsub(m, "\226\128\139", "")
    m = strtrim(m)
    local low = string.lower(m)
    -- Detección por palabra clave (sin ^ ni etiquetas exactas): tolera cualquier
    -- residuo/carácter invisible por delante.
    if string.find(low, "raidid", 1, true) then
        local raidId = string.match(m, "(%d+)")
        if raidId then return { kind = "id", raidId = tonumber(raidId) } end
        -- "RaidID" SIN número (p.ej. el texto de error "...este RaidID este
        -- conectado, o sea erroneo"): NO es una línea de lista; que caiga al
        -- manejador de raid info para tratarla como "sin miembros".
    end
    if string.find(low, "mapa", 1, true) and string.find(low, "dificultad", 1, true) then
        local mapa = string.match(m, ":%s*(.-)%s*,")            -- tras 1er ':' hasta la ','
        local dif  = string.match(m, "[Dd]ificultad:%s*([^%s%[]+)")
        local activo = string.find(string.upper(m), "ACTIVO", 1, true) ~= nil
        return { kind = "map", map = strtrim(mapa or ""), diff = strtrim(dif or ""), active = activo }
    end
    if string.find(low, "jugador", 1, true) then
        local jugador = string.match(m, "[Jj]ugador%s*:%s*(.+)$")
        if jugador and jugador ~= "" then
            return { kind = "player", player = strtrim(jugador) }
        end
        -- "jugador" sin "Jugador:" (p.ej. el footer "...detalles de un jugador
        -- online"): NO es una línea de lista.
    end
    return nil
end

-- ¿Es una línea de raid list? (para ocultar)
function NC.IsRaidListLine(msg)
    if type(msg) ~= "string" then return false end
    if NC.IsInfoHeader(msg, "raidlist") then return true end
    local m = NC.StripColors(msg)
    m = string.gsub(m, "\194\160", " ")
    m = string.gsub(m, "\160", " ")
    local low = string.lower(m)
    if string.find(low, "raidid", 1, true) then return true end
    if string.find(low, "jugador", 1, true) and NC._raidListActive then return true end
    if string.find(low, "mapa", 1, true) and string.find(low, "dificultad", 1, true) then return true end
    return false
end

-- Parsea el bloque de raid info (por número). Línea a línea.
function NC.ParseRaidInfoLine(msg)
    if type(msg) ~= "string" then return nil end
    local m = strtrim(NC.StripColors(msg))
    local raidId = string.match(m, "^RaidID:%s*(%d+)")
    if raidId then return { k = "id", v = tonumber(raidId) } end
    local mapa, dif = string.match(m, "^Mapa:%s*(.-),%s*Dificultad:%s*(.+)$")
    if mapa then return { k = "map", map = strtrim(mapa), diff = strtrim(dif) } end
    local enc = string.match(m, "^Encuentros:%s*(.+)$")
    if enc then return { k = "encounters", v = strtrim(enc) } end
    local lider = string.match(m, "^Líder:%s*(.+)$") or string.match(m, "^Lider:%s*(.+)$")
    if lider then return { k = "leader", v = strtrim(lider) } end
    local jug = string.match(m, "^Jugadores:%s*(.+)$")
    if jug then return { k = "players", v = strtrim(jug) } end
    local roles = string.match(m, "^Posibles Roles:%s*(.+)$")
    if roles then return { k = "roles", v = strtrim(roles) } end
    local gs = string.match(m, "GS Promedio:%s*(%d+)")
    if gs then
        local ilvl = string.match(m, "ilvl Promedio:%s*(%d+)")
        return { k = "gs", gs = tonumber(gs), ilvl = tonumber(ilvl) }
    end
    return nil
end

-- ¿Es una línea de raid info? (para ocultar)
function NC.IsRaidInfoLine(msg)
    if type(msg) ~= "string" then return false end
    if NC.IsInfoHeader(msg, "raidinfo") then return true end
    if NC._raidInfoActive and NC.ParseRaidInfoLine(msg) then return true end
    local m = NC.StripColors(msg)
    if string.find(m, ".player info", 1, true) and NC._raidInfoActive then return true end
    return false
end
