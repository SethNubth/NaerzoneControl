local ADDON, NC = ...

NC.ADDON   = ADDON
NC.VERSION = "1.0.2"
NC.DB_VERSION = 1   -- versión de la estructura de SavedVariables (para migraciones)
NC.MEDIA   = "Interface\\AddOns\\" .. ADDON .. "\\media\\"

------------------------------------------------------------
-- Ajustes por defecto (se copian a la DB en el primer arranque)
------------------------------------------------------------
NC.DEFAULTS = {
    eyeShown     = true,    -- ojo flotante visible
    eyeScale     = 1.0,     -- escala del ojo flotante (0.6 - 2.0)
    eyeAlpha     = 1.0,     -- opacidad del ojo en reposo (0.2 - 1.0)
    eyeFade      = false,   -- atenuar el ojo cuando el ratón no está encima
    eyeLock      = false,   -- bloquear la posición del ojo (no arrastrable)
    eyeHideCombat = false,  -- ocultar el ojo durante el combate
    sendMode     = "SAY",       -- "SAY" (por defecto en NAERZONE) o "WHISPER"
    skin         = "blizzard",  -- "blizzard" (marco clasico de WoW) o "naer" (texturas propias)
    lastTab      = 1,
    minimapAngle = 220,
    minimapHide  = false,
    silence      = false,   -- ocultar del chat las respuestas de .player iteminfo
    translateInstances = true,  -- traducir nombres de bandas/mazmorras al español
    showDungeonLocks   = false, -- mostrar también los CDs de mazmorra (5); por defecto solo bandas
    theme        = "classic", -- tema visual global: "classic" | "modern" (aplicación futura)
    opacity      = 1,         -- opacidad del fondo de la ventana (0.3 - 1.0)
    warnedSend   = false,
}

-- LIMITE DEL SERVIDOR (medido en NAERZONE):
--   .player iteminfo admite 2 consultas cada 5 segundos.
--   Pasarse NO devuelve error: te SILENCIA durante 10 segundos, y no solo
--   los comandos: TODO lo que escribas.
-- La cola usa una ventana deslizante: nunca puede haber mas de RateMax
-- envios en los ultimos RateWindow segundos. Como el castigo (10 s) dobla
-- a la ventana (5 s), el margen de seguridad es generoso a proposito:
-- perder un segundo por consulta es mejor que quedarse mudo 10.
NC.CFG = {
    RateMax       = 2,     -- envios permitidos por ventana
    RateWindow    = 10,    -- tamaño de la ventana en segundos (2 consultas / 10 s)
    RateSafety    = 1.0,   -- margen extra por si el reloj del servidor no cuadra
    ConfirmAbove  = 4,     -- pedir confirmacion al encolar mas de esto
    SendInterval  = 2.5,   -- separacion minima entre dos envios de la misma ventana
    ResultTimeout = 6,     -- segundos que esperamos respuesta del servidor
    IconSize      = 64,
    IconPad       = 14,
    IconCols      = 6,
    RowHeight     = 30,
}

NC.COL = {
    title   = "|cff00ccff",
    warn    = "|cffff5555",
    ok      = "|cff55ff55",
    soft    = "|cffaaaaaa",
    accent  = "|cffffd100",
    r       = "|r",
}

NC.TAG = NC.COL.title .. "[NaerControl]" .. NC.COL.r .. " "

------------------------------------------------------------
-- Iconos
--
-- No fijamos rutas de textura a mano: adivinar nombres de icono de
-- 3.3.5a es como fallaba antes (una ruta inexistente no da error, deja
-- el hueco en blanco). Los iconos se sacan de GetItemIcon sobre objetos
-- de la propia tabla de botin, que ya estan verificados y que el cliente
-- resuelve desde su DBC aunque el objeto no este en cache.
--
-- Si algun dia quieres una textura concreta para una banda, ponla aqui
-- y tendra prioridad.
------------------------------------------------------------
NC.RAID_ICON = {
    -- ICC = "Interface\\Icons\\...",
}
NC.UNKNOWN_ICON = "Interface\\Icons\\INV_Misc_QuestionMark"

-- Objeto elegido A MANO por su icono reconocible para cada jefe.
-- Todos estos IDs existen en data.lua (comprobado al generar), asi que
-- GetItemIcon siempre devuelve textura; nunca hay hueco en blanco.
-- Tiene prioridad sobre el icono derivado automaticamente.
NC.BOSS_ICON = {
    ["Tuétano"] = 50610,
    ["Susurramuerte"] = 50641,
    ["Batalla Aérea"] = 50654,
    ["Libramorte Colmillosaurio"] = 50672,
    ["Panzachancro"] = 50692,
    ["Caraputrea"] = 50353,
    ["Putricidio"] = 50708,
    ["Consejo de Príncipes"] = 50710,
    ["Reina de Sangre"] = 50725,
    ["Valithria Caminasueños"] = 50626,
    ["Sindragosa"] = 50633,
    ["El Rey Exánime"] = 50730,
    ["Las bestias de Rasganorte"] = 46958,
    ["Jaraxxus"] = 46996,
    ["Campeones de la Horda"] = 47718,
    ["Gemelas Val'kyr"] = 47746,
    ["Anub'arak"] = 47897,
    ["Homenaje a la carrera"] = 48713,
    ["Halion"] = 53103,
}

-- Retratos "Achievement_Boss_*" CANDIDATOS pendientes de verificar.
-- Se probaron dos rondas de nombres en NAERZONE y solo 4 jefes tienen
-- retrato (ver BOSS_ICON_TEX). El resto no existe con ningun patron de
-- nombre conocido, asi que usan su objeto representativo. Tabla vacia:
-- si algun dia quieres reintentar, anade rutas aqui y usa /nc iconos.
NC.BOSS_ICON_CANDIDATES = {
}

-- Retexturas CONFIRMADAS en el cliente de NAERZONE (verificadas con /nc iconos).
-- Lo que este aqui tiene prioridad sobre el objeto de BOSS_ICON.
NC.BOSS_ICON_TEX = {
    ["Susurramuerte"] = "Interface\\Icons\\Achievement_Boss_LadyDeathwhisper",
    ["El Rey Exánime"]     = "Interface\\Icons\\Achievement_Boss_LichKing",
    ["Sindragosa"]         = "Interface\\Icons\\Achievement_Boss_Sindragosa",
    ["Anub'arak"]          = "Interface\\Icons\\Achievement_Boss_Anubarak",
}

------------------------------------------------------------
-- Modos de banda (orden del menu del escaner)
------------------------------------------------------------
NC.MODES = {
    { key = "ICC10N", label = "ICC 10 Normal",  raid = "ICC" },
    { key = "ICC10H", label = "ICC 10 Heroico", raid = "ICC" },
    { key = "ICC25N", label = "ICC 25 Normal",  raid = "ICC" },
    { key = "ICC25H", label = "ICC 25 Heroico", raid = "ICC" },
    { key = "TOC10N", label = "TOC 10 Normal",  raid = "TOC" },
    { key = "TOC10H", label = "TOC 10 Heroico", raid = "TOC" },
    { key = "TOC25N", label = "TOC 25 Normal",  raid = "TOC" },
    { key = "TOC25H", label = "TOC 25 Heroico", raid = "TOC" },
    { key = "SR10N",  label = "SR 10 Normal",   raid = "SR"  },
    { key = "SR10H",  label = "SR 10 Heroico",  raid = "SR"  },
    { key = "SR25N",  label = "SR 25 Normal",   raid = "SR"  },
    { key = "SR25H",  label = "SR 25 Heroico",  raid = "SR"  },
    { key = "Naxx10N", label = "Naxx 10 Normal", raid = "Naxx" },
    { key = "Naxx25N", label = "Naxx 25 Normal", raid = "Naxx" },
    { key = "Uld10N", label = "Ulduar 10 Normal", raid = "Uld" },
    { key = "Uld25N", label = "Ulduar 25 Normal", raid = "Uld" },
    { key = "Ojo10N", label = "Ojo Eternidad 10", raid = "Ojo" },
    { key = "Ojo25N", label = "Ojo Eternidad 25", raid = "Ojo" },
    { key = "Obsi10N", label = "S. Obsidiana 10", raid = "Obsi" },
    { key = "Obsi25N", label = "S. Obsidiana 25", raid = "Obsi" },
    { key = "Ony10N", label = "Onyxia 10", raid = "Ony" },
    { key = "Ony25N", label = "Onyxia 25", raid = "Ony" },
    { key = "Arch10N", label = "Archavon 10", raid = "Arch" },
    { key = "Arch25N", label = "Archavon 25", raid = "Arch" },
    { key = "Kara", label = "Karazhan", raid = "Kara" },
    { key = "Gruul", label = "Gruul", raid = "Gruul" },
    { key = "Mag", label = "Mag", raid = "Mag" },
    { key = "SSC", label = "SSC", raid = "SSC" },
    { key = "TK", label = "TK", raid = "TK" },
    { key = "Hyjal", label = "Hyjal", raid = "Hyjal" },
    { key = "BT", label = "BT", raid = "BT" },
    { key = "ZA", label = "ZA", raid = "ZA" },
    { key = "Sunwell", label = "Sunwell", raid = "Sunwell" },
    { key = "MC", label = "MC", raid = "MC" },
    { key = "BWL", label = "BWL", raid = "BWL" },
    { key = "ZG", label = "ZG", raid = "ZG" },
    { key = "AQ20", label = "AQ20", raid = "AQ20" },
    { key = "AQ40", label = "AQ40", raid = "AQ40" },
}

-- ------------------------------------------------------------------
-- Navegación por niveles: Expansión -> Banda -> Dificultad -> Jefes.
-- Cada banda tiene una lista "diffs" de { label, key(modo) }. Si una
-- banda tiene una sola dificultad, la navegación salta ese nivel y va
-- directa a los jefes. Los "key" apuntan a NC.MODES/NC.Loot (los datos
-- no cambian); esta capa es solo para agrupar la navegación.
-- ------------------------------------------------------------------
NC.EXPANSIONS = {
    {
        key = "WotLK", label = "Wrath of the Lich King",
        raids = {
            { raid = "Naxx", label = "Naxxramas", diffs = {
                { label = "10 Normal", key = "Naxx10N" },
                { label = "25 Normal", key = "Naxx25N" },
            }},
            { raid = "Uld", label = "Ulduar", diffs = {
                { label = "10 Normal", key = "Uld10N" },
                { label = "25 Normal", key = "Uld25N" },
            }},
            { raid = "Ojo", label = "El Ojo de la Eternidad", diffs = {
                { label = "10 Normal", key = "Ojo10N" },
                { label = "25 Normal", key = "Ojo25N" },
            }},
            { raid = "Obsi", label = "El Sagrario Obsidiana", diffs = {
                { label = "10 Normal", key = "Obsi10N" },
                { label = "25 Normal", key = "Obsi25N" },
            }},
            { raid = "Ony", label = "Guarida de Onyxia", diffs = {
                { label = "10 Normal", key = "Ony10N" },
                { label = "25 Normal", key = "Ony25N" },
            }},
            { raid = "TOC", label = "Prueba del Cruzado", diffs = {
                { label = "10 Normal", key = "TOC10N" },
                { label = "10 Heroico", key = "TOC10H" },
                { label = "25 Normal", key = "TOC25N" },
                { label = "25 Heroico", key = "TOC25H" },
            }},
            { raid = "Arch", label = "La Cámara de Archavon", diffs = {
                { label = "10 Normal", key = "Arch10N" },
                { label = "25 Normal", key = "Arch25N" },
            }},
            { raid = "SR", label = "El Sagrario Rubí", diffs = {
                { label = "10 Normal", key = "SR10N" },
                { label = "10 Heroico", key = "SR10H" },
                { label = "25 Normal", key = "SR25N" },
                { label = "25 Heroico", key = "SR25H" },
            }},
            { raid = "ICC", label = "Ciudadela de la Corona de Hielo", diffs = {
                { label = "10 Normal", key = "ICC10N" },
                { label = "10 Heroico", key = "ICC10H" },
                { label = "25 Normal", key = "ICC25N" },
                { label = "25 Heroico", key = "ICC25H" },
            }},
        },
    },
    {
        key = "TBC", label = "The Burning Crusade",
        raids = {
            { raid = "Kara", label = "Karazhan", diffs = {
                { label = "Normal", key = "Kara" },
            }},
            { raid = "Gruul", label = "Guarida de Gruul", diffs = {
                { label = "Normal", key = "Gruul" },
            }},
            { raid = "Mag", label = "Guarida de Magtheridon", diffs = {
                { label = "Normal", key = "Mag" },
            }},
            { raid = "SSC", label = "Caverna Santuario Serpiente", diffs = {
                { label = "Normal", key = "SSC" },
            }},
            { raid = "TK", label = "El Castillo de la Tempestad", diffs = {
                { label = "Normal", key = "TK" },
            }},
            { raid = "Hyjal", label = "Cumbre de Hyjal", diffs = {
                { label = "Normal", key = "Hyjal" },
            }},
            { raid = "BT", label = "Templo Oscuro", diffs = {
                { label = "Normal", key = "BT" },
            }},
            { raid = "ZA", label = "Zul'Aman", diffs = {
                { label = "Normal", key = "ZA" },
            }},
            { raid = "Sunwell", label = "Meseta de la Fuente del Sol", diffs = {
                { label = "Normal", key = "Sunwell" },
            }},
        },
    },
    {
        key = "Classic", label = "Classic",
        raids = {
            { raid = "MC", label = "Núcleo de Magma", diffs = {
                { label = "Normal", key = "MC" },
            }},
            { raid = "BWL", label = "Guarida Alanegra", diffs = {
                { label = "Normal", key = "BWL" },
            }},
            { raid = "ZG", label = "Zul'Gurub", diffs = {
                { label = "Normal", key = "ZG" },
            }},
            { raid = "AQ20", label = "Ruinas de Ahn'Qiraj", diffs = {
                { label = "Normal", key = "AQ20" },
            }},
            { raid = "AQ40", label = "Templo de Ahn'Qiraj", diffs = {
                { label = "Normal", key = "AQ40" },
            }},
        },
    },
}

------------------------------------------------------------
-- Jefes por banda, en orden de encuentro.
------------------------------------------------------------
NC.BOSSES = {
    ICC = {
        { name = "Tuétano" },
        { name = "Susurramuerte" },
        { name = "Batalla Aérea" },
        { name = "Libramorte Colmillosaurio" },
        { name = "Panzachancro" },
        { name = "Caraputrea" },
        { name = "Putricidio" },
        { name = "Consejo de Príncipes" },
        { name = "Reina de Sangre" },
        { name = "Valithria Caminasueños" },
        { name = "Sindragosa" },
        { name = "El Rey Exánime" },
    },
    TOC = {
        { name = "Las bestias de Rasganorte" },
        { name = "Jaraxxus" },
        { name = "Campeones de la Horda" },
        { name = "Gemelas Val'kyr" },
        { name = "Anub'arak" },
        { name = "Homenaje a la carrera",     heroicOnly = true },
    },
    SR = {
        { name = "Halion" },
    },
    Naxx = {
        { name = "Anub'Rekhan" },
        { name = "Faerlina" },
        { name = "Maexxna" },
        { name = "Noth el Pesteador" },
        { name = "Heigan el Impuro" },
        { name = "Loatheb" },
        { name = "Razuvious" },
        { name = "Gothik el Cosechador" },
        { name = "Los Cuatro Jinetes" },
        { name = "Remendejo" },
        { name = "Grobbulus" },
        { name = "Gluth" },
        { name = "Thaddius" },
        { name = "Sapphiron" },
        { name = "Kel'Thuzad" },
    },
    Uld = {
        { name = "Leviatán de llamas" },
        { name = "Ignis el Maestro de la Caldera" },
        { name = "Tajoescama" },
        { name = "Desarmador XA-002" },
        { name = "La Asamblea de Hierro" },
        { name = "Kologarn" },
        { name = "Auriaya" },
        { name = "Hodir" },
        { name = "Thorim" },
        { name = "Freya" },
        { name = "Mimiron" },
        { name = "Vezax" },
        { name = "Yogg-Saron" },
        { name = "Algalon el Observador" },
    },
    Ojo = {
        { name = "Malygos" },
    },
    Obsi = {
        { name = "Sartharion" },
    },
    Ony = {
        { name = "Onyxia" },
    },
    Arch = {
        { name = "Archavon el Vigía de la Piedra" },
        { name = "Emalon el Vigía de la Tormenta" },
        { name = "Toravon el Vigía del Hielo" },
        { name = "Koralon el Vigía de las Llamas" },
    },
    Kara = {
        { name = "Attumen el Montero" },
        { name = "Moroes" },
        { name = "Doncella de Virtud" },
        { name = "Sala de la Ópera" },
        { name = "Curator" },
        { name = "Sombra de Aran" },
        { name = "Terestian Pezuña Enferma" },
        { name = "Rencor Abisal" },
        { name = "Evento del Ajedrez" },
        { name = "Malchezaar" },
        { name = "Nocturno" },
    },
    Gruul = {
        { name = "Maulgar" },
        { name = "Gruul el Asesino de Dragones" },
    },
    Mag = {
        { name = "Magtheridon" },
    },
    SSC = {
        { name = "Hydross el Inestable" },
        { name = "El Acechador de las Profundidades" },
        { name = "Leotheras el Ciego" },
        { name = "Karathress" },
        { name = "Morogrim Caminamareas" },
        { name = "Vashj" },
    },
    TK = {
        { name = "Al'ar" },
        { name = "Atracador del Vacío" },
        { name = "Solarian" },
        { name = "Kael'thas Caminante del Sol" },
    },
    Hyjal = {
        { name = "Ira Fríoinvierno" },
        { name = "Anetheron" },
        { name = "Kaz'rogal" },
        { name = "Azgalor" },
        { name = "Archimonde" },
    },
    BT = {
        { name = "Naj'entus" },
        { name = "Supremus" },
        { name = "Sombra de Akama" },
        { name = "Teron Sangrevil" },
        { name = "Gurtogg Sangrehirviente" },
        { name = "Relicario de las Almas" },
        { name = "Madre Shahraz" },
        { name = "Consejo Illidari" },
        { name = "Illidan Tempestira" },
    },
    ZA = {
        { name = "Akil'zon" },
        { name = "Nalorakk" },
        { name = "Jan'alai" },
        { name = "Halazzi" },
        { name = "Malacrass" },
        { name = "Zul'jin" },
    },
    Sunwell = {
        { name = "Kalecgos" },
        { name = "Brutallus" },
        { name = "Felmyst" },
        { name = "Gemelas Eredar" },
        { name = "M'uru" },
        { name = "Kil'jaeden" },
    },
    MC = {
        { name = "Lucifron" },
        { name = "Magmadar" },
        { name = "Gehennas" },
        { name = "Garr" },
        { name = "Geddon" },
        { name = "Shazzrah" },
        { name = "Sulfuron" },
        { name = "Golemagg" },
        { name = "Executus" },
        { name = "Ragnaros" },
    },
    BWL = {
        { name = "Sangrevil" },
        { name = "Vaelastrasz" },
        { name = "Cizallador" },
        { name = "Faucedragón" },
        { name = "Ebanroc" },
        { name = "Flamagor" },
        { name = "Chromaggus" },
    },
    ZG = {
        { name = "Venoxis" },
        { name = "Jeklik" },
        { name = "Mar'li" },
        { name = "Mandokir" },
        { name = "Thekal" },
        { name = "Arlokk" },
        { name = "Jin'do" },
        { name = "Gahz'ranka" },
        { name = "Hakkar" },
    },
    AQ20 = {
        { name = "Kurinnaxx" },
        { name = "Rajaxx" },
        { name = "Moam" },
        { name = "Buru" },
        { name = "Ayamiss" },
        { name = "Ossirian" },
    },
    AQ40 = {
        { name = "Skeram" },
        { name = "Familia de Insectos (Yauj, Kri, Vem)" },
        { name = "Sartura" },
        { name = "Fankriss" },
        { name = "Viscidus" },
        { name = "Huhuran" },
        { name = "Emperadores Gemelos (Vek'lor y Vek'nilash)" },
        { name = "Ouro" },
        { name = "C'Thun" },
    },
}

------------------------------------------------------------
-- Pestanas de comandos simples.
--  input  : "none" | "number" | "name"
--  hint   : texto gris dentro de la caja
------------------------------------------------------------
NC.TABS = {
    {
        name = "Experiencia",
        commands = {
            { desc = "Consultar rates actuales", cmd = ".xprate",         input = "none", ratesRefresh = true },
            { desc = "Rates al máximo",          cmd = ".xprate default", input = "none", ratesMax = true },
            { desc = "XP de misiones",           cmd = ".xprate quest",   input = "rate", rateKey = "quest" },
            { desc = "XP de criaturas",          cmd = ".xprate kill",    input = "rate", rateKey = "kill" },
            { desc = "XP de exploración",        cmd = "",                input = "rateFixed", fixedValue = 1 },
        },
        note = "Recuerda que el fin de semana el rate aumenta ligeramente y se verá afectado según mayor sea el rate escogido.",
    },
    {
        name   = "Escáner",
        render = "scanner",
    },
    {
        name = "Eventos",
        render = "events",
    },
    {
        name   = "Información",
        render = "info",
    },
    {
        name   = "Campos de batalla",
        render = "bg",
    },
    {
        name   = "SoloQ",
        render = "soloq",
    },
    {
        name   = "Chat",
        render = "chat",
    },
    {
        name   = "Mazmorras",
        render = "dungeons",
    },
    {
        name   = "Ajustes",
        render = "settings",
    },
    {
        name     = "Ayuda",
        render   = "help",
        disabled = true,   -- en construcción: botón en gris, sin acción
    },
}

------------------------------------------------------------
-- Respuestas de NAERZONE a ".player iteminfo" (confirmadas en vivo):
--   "Objeto encontrado en inventario/banco: ID 50457, Cantidad 1, Jugador: Odnel"
--   "Objeto no encontrado: ID 49623, Jugador: Odnel"
-- Se analizan en NC.ParseItemInfo (util.lua), que saca ID y jugador del
-- propio mensaje: no dependemos del orden ni de que la cola vaya al dia.
------------------------------------------------------------
