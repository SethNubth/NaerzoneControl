local ADDON, NC = ...

local COL = NC.COL

-- La ventana es grande y FIJA para todas las pestañas. Antes cambiaba de
-- tamaño al entrar en Chat (que necesita dos columnas) y "saltaba"; ahora
-- se queda siempre igual. Las pestañas de loot tienen espacio de sobra.
local WIDTH, HEIGHT = 820, 690
local SIDEBAR_W     = 140

------------------------------------------------------------
-- Helper: ScrollFrame con rueda del raton
------------------------------------------------------------
function NC.CreateScroll(parent)
    local scroll = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    local content = CreateFrame("Frame", nil, scroll)
    content:SetWidth(1)
    content:SetHeight(1)
    scroll:SetScrollChild(content)

    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local cur = self:GetVerticalScroll()
        local max = self:GetVerticalScrollRange()
        local new = cur - (delta * 40)
        if new < 0 then new = 0 elseif new > max then new = max end
        self:SetVerticalScroll(new)
    end)

    scroll.content = content
    if NC.SkinScrollOf then NC.SkinScrollOf(scroll) end
    return scroll, content
end

------------------------------------------------------------
-- Marco principal
------------------------------------------------------------
-- La ventana es grande (820x690). La escala por defecto es AUTOMATICA:
-- se calcula para que quepa en la pantalla con margen (techo 1.0). En
-- cuanto el usuario mueve el deslizador, su valor manda (0.5 a 1.5) y el
-- automatico deja de actuar. SetClampedToScreen evita que se salga.
local MIN_SCALE, MAX_SCALE = 0.5, 1.5
local FIT_MARGIN = 0.92   -- no ocupar mas del 92% de la pantalla

local frame = CreateFrame("Frame", "NaerControlFrame", UIParent)
frame:SetWidth(WIDTH)
frame:SetHeight(HEIGHT)
frame:SetPoint("CENTER")
frame:SetFrameStrata("HIGH")
frame:SetToplevel(true)
frame:SetClampedToScreen(true)   -- red de seguridad: nunca fuera de pantalla
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    NC.SaveWindowPos()
end)
frame:Hide()
tinsert(UISpecialFrames, "NaerControlFrame")

NC.Frame = frame

-- Skin propio (texturas de la carpeta media)
local bg = frame:CreateTexture(nil, "BACKGROUND")
bg:SetAllPoints(frame)
bg:SetTexture(NC.MEDIA .. "background")

local border = frame:CreateTexture(nil, "BORDER")
border:SetAllPoints(frame)
border:SetTexture(NC.MEDIA .. "border")

-- Capa OPACA de relleno: la textura del cuadro de diálogo SÍ rinde sólida en
-- este cliente (WHITE8X8 no). Va por encima del fondo de media y bajo el
-- contenido; permite dejar la ventana oscura del todo al 100%.
local solidBg = frame:CreateTexture(nil, "BACKGROUND")
solidBg:SetAllPoints(frame)
solidBg:SetTexture(1, 1, 1)                 -- técnica fiable en este cliente: rinde sólido
solidBg:SetVertexColor(0.05, 0.05, 0.06, 1) -- color oscuro; la opacidad la controla SetAlpha
solidBg:SetDrawLayer("BACKGROUND", 3)

local BLIZZ_BACKDROP = {
    bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
}

function NC.GetOpacity()
    return (NC.db and NC.db.opacity) or 1
end

-- Opacidad del fondo (0.3 a 1.0). Usa el BACKDROP del marco (WHITE8X8 sólido,
-- que sí renderiza en este cliente, como las tarjetas) para poder llegar a
-- opacidad TOTAL. La textura de media acompaña por encima como decoración.
function NC.ApplyOpacity(v)
    v = tonumber(v) or NC.GetOpacity()
    if v < 0.3 then v = 0.3 elseif v > 1 then v = 1 end
    if NC.db then NC.db.opacity = v end
    solidBg:SetAlpha(v)
    bg:SetAlpha(v)
    if (NC.db and NC.db.skin) == "blizzard" and frame.SetBackdropColor then
        frame:SetBackdropColor(1, 1, 1, v)
    end
    if NC.SyncOpacity then NC.SyncOpacity() end
end

-- Chrome de la ventana según el tema: en Moderno tinta el marco de media con
-- el acento; en Clásico lo deja natural (dorado). Si el skin Blizzard está
-- activo, tinta el borde del backdrop en su lugar. No toca opacidad ni relleno.
local function applyChromeTheme()
    local t = NC.Theme
    local ac = (t and t.accent) or { 1, 1, 1 }
    local modern = t and t.name == "modern"
    if modern then
        border:SetVertexColor(ac[1], ac[2], ac[3])
    else
        border:SetVertexColor(1, 1, 1)
    end
    -- relleno oscuro: leve tinte por tema (frío/cálido). La opacidad va aparte (SetAlpha).
    if modern then
        solidBg:SetVertexColor(0.05, 0.06, 0.09, 1)
    else
        solidBg:SetVertexColor(0.07, 0.06, 0.05, 1)
    end
    if (NC.db and NC.db.skin) == "blizzard" and frame.SetBackdropBorderColor then
        if modern then
            frame:SetBackdropBorderColor(ac[1], ac[2], ac[3], 1)
        else
            frame:SetBackdropBorderColor(1, 1, 1, 1)
        end
    end
end
if NC.RegisterThemeable then NC.RegisterThemeable(applyChromeTheme) end

function NC.ApplySkin()
    local skin = (NC.db and NC.db.skin) or "naer"
    if skin == "blizzard" then
        bg:Hide()
        border:Hide()
        solidBg:Hide()
        frame:SetBackdrop(BLIZZ_BACKDROP)
        frame:SetBackdropColor(1, 1, 1, 1)
    else
        frame:SetBackdrop(nil)
        bg:Show()
        border:Show()
        solidBg:Show()
    end
    NC.ApplyOpacity(NC.GetOpacity())
    applyChromeTheme()
end

------------------------------------------------------------
-- Titulo y cierre
------------------------------------------------------------
local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOPLEFT", 20, -16)
-- "Naer" blanco + "Control" azul frost + "2" destacado en dorado.
local function skinTitle(th)
    local hex = (NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3"
    title:SetText("|cffffffffNaer|r|cff" .. hex .. "Control|r")
end
if NC.RegisterThemeable then NC.RegisterThemeable(skinTitle) else skinTitle() end

local ver = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
ver:SetPoint("BOTTOMLEFT", title, "BOTTOMRIGHT", 6, 1)
ver:SetText(NC.VERSION or "1.0.2")
ver:SetTextColor(0.55, 0.55, 0.60)

-- La versión ya no se muestra destacada en la cabecera (queda para la pestaña
-- de Ayuda). "NaerControl 2" es la marca visible; 2.4 es la versión interna.

local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", -8, -8)

------------------------------------------------------------
-- El control de tamaño (- valor + Auto) y el botón "Consola" se movieron a la
-- pestaña Ajustes. Aquí sólo queda la función que refresca el número mostrado.
------------------------------------------------------------

-- Refresca el número del tamaño mostrado (ahora vive en la pestaña Ajustes,
-- NC._scaleFS). Es sólo texto: no mueve ningún control, no hay reentrada.
function NC.SyncScaleSlider()
    local fs = NC._scaleFS
    if not fs then return end
    local auto = not (NC.db and NC.db.uiScale)
    local s = frame:GetScale() or 1
    fs:SetText(string.format("%.2f", s))
    if auto then
        fs:SetTextColor(0.5, 0.8, 1)   -- azul = automatico
    else
        fs:SetTextColor(0.85, 0.85, 0.9)
    end
end

-- Linea de estado (abajo)
local status = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
status:SetPoint("BOTTOMLEFT", 20, 14)
status:SetPoint("BOTTOMRIGHT", -20, 14)
status:SetJustifyH("LEFT")
status:SetTextColor(0.65, 0.65, 0.65)
NC.StatusText = status

local statusTimer = 0
frame:SetScript("OnUpdate", function(self, elapsed)
    if statusTimer > 0 then
        statusTimer = statusTimer - elapsed
        if statusTimer <= 0 then
            status:SetText("")
        end
    end
end)

function NC.SetStatus(text, isError, seconds)
    if isError then
        status:SetTextColor(1, 0.4, 0.4)
        if NC.Console and NC.Console.LogWarn and text then
            NC.Console:LogWarn(text)
        end
    else
        status:SetTextColor(0.65, 0.85, 0.65)
    end
    status:SetText(text or "")
    statusTimer = seconds or 5
end

------------------------------------------------------------
-- Barra lateral y contenedor de contenido
------------------------------------------------------------
local sidebar = CreateFrame("Frame", nil, frame)
sidebar:SetWidth(SIDEBAR_W)
sidebar:SetPoint("TOPLEFT", 18, -48)
sidebar:SetPoint("BOTTOMLEFT", 18, 34)

NC.Content = CreateFrame("Frame", nil, frame)
NC.Content:SetPoint("TOPLEFT", sidebar, "TOPRIGHT", 12, 0)
NC.Content:SetPoint("BOTTOMRIGHT", -18, 34)

local tabButtons = {}

function NC.ShowTab(index)
    index = index or 1
    if not NC.TABS[index] then index = 1 end
    -- si la pestaña está deshabilitada (en construcción), ir a la primera
    if NC.TABS[index] and NC.TABS[index].disabled then index = 1 end
    if NC.db then NC.db.lastTab = index end

    -- ocultar todas las vistas
    if NC.HideCommandsView then NC.HideCommandsView() end
    if NC.HideScannerView  then NC.HideScannerView()  end
    if NC.HideChatView     then NC.HideChatView()     end
    if NC.HideDungeonsView then NC.HideDungeonsView() end
    if NC.HideEventsView   then NC.HideEventsView()   end
    if NC.HideInfoView     then NC.HideInfoView()     end
    if NC.HideBGView       then NC.HideBGView()       end
    if NC.HideSoloQView    then NC.HideSoloQView()    end
    if NC.HideSettingsView then NC.HideSettingsView() end
    if NC.HideHelpView     then NC.HideHelpView()     end

    for i, btn in ipairs(tabButtons) do
        btn._active = (i == index)
        if NC.SkinTabButton then NC.SkinTabButton(btn) end
    end

    local tab = NC.TABS[index]

    -- Despacho protegido: si una vista falla, NO debe impedir que la ventana se
    -- muestre ni romper el resto de la UI. Capturamos el error y lo enseñamos.
    local function dispatch()
        if tab.render == "scanner" then
            NC.ShowScannerView()
        elseif tab.render == "chat" then
            NC.ShowChatView()
        elseif tab.render == "dungeons" then
            NC.ShowDungeonsView()
        elseif tab.render == "events" then
            NC.ShowEventsView()
        elseif tab.render == "info" then
        NC.ShowInfoView()
        elseif tab.render == "bg" then
        NC.ShowBGView()
    elseif tab.render == "soloq" then
        NC.ShowSoloQView()
    elseif tab.render == "settings" then
        NC.ShowSettingsView()
        elseif tab.render == "help" then
            NC.ShowHelpView()
        else
            NC.ShowCommandsView(tab)
        end
    end
    local ok, err = pcall(dispatch)
    if not ok then
        if NC.Content then NC.Content:Show() end
        NC.Print("|cffff4040Error al abrir la pestaña '" .. tostring(tab.name) .. "':|r " .. tostring(err))
    end

    -- Aplica el tema (skin de botones/casillas) al contenido de la pestaña actual.
    if NC.SkinPanel and NC.Content then pcall(NC.SkinPanel, NC.Content) end
end

-- Botón de pestaña con aspecto propio (sigue el tema). Sustituye al botón
-- Blizzard para que la columna lateral cambie con el tema.
function NC.SkinTabButton(btn)
    if not btn then return end
    if NC.SkinButton then NC.SkinButton(btn) end   -- base: modern oscuro / classic Blizzard
    -- overlay persistente de "activa" (no lo pisa el hover)
    if not btn._activeHL then
        local hl = btn:CreateTexture(nil, "ARTWORK")
        hl:SetPoint("TOPLEFT", 1, -1); hl:SetPoint("BOTTOMRIGHT", -1, 1)
        hl:SetTexture(1, 1, 1); hl:Hide()
        btn._activeHL = hl
    end
    local modern = (NC.Theme and NC.Theme.name == "modern")
    local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }
    local fs = btn.GetFontString and btn:GetFontString()
    if btn._disabled then
        btn._activeHL:Hide()
        if btn.Disable then btn:Disable() end
    elseif btn._active then
        if modern then
            -- moderno: relleno azul (este estilo no tiene highlight Blizzard)
            btn._activeHL:SetVertexColor(ac[1] * 0.5, ac[2] * 0.6, ac[3] * 0.8, 1)
            btn._activeHL:Show()
            if fs then fs:SetTextColor(1, 1, 1) end
            if btn.UnlockHighlight then btn:UnlockHighlight() end
        else
            -- clásico: el resalte del mouseover (highlight de Blizzard) fijo, sin gris
            btn._activeHL:Hide()
            if btn.LockHighlight then btn:LockHighlight() end
        end
        if btn.Enable then btn:Enable() end
    else
        btn._activeHL:Hide()
        if btn.Enable then btn:Enable() end
        if btn.UnlockHighlight then btn:UnlockHighlight() end
    end
end

for i, tab in ipairs(NC.TABS) do
    local btn = CreateFrame("Button", nil, sidebar, "UIPanelButtonTemplate")
    btn:SetWidth(SIDEBAR_W)
    btn:SetHeight(28)
    btn:SetText(tab.name)
    if i == 1 then
        btn:SetPoint("TOP", sidebar, "TOP", 0, 0)
    else
        btn:SetPoint("TOP", tabButtons[i - 1], "BOTTOM", 0, -8)
    end
    btn._disabled = tab.disabled and true or false
    if not btn._disabled then
        btn:SetScript("OnClick", function() NC.ShowTab(i) end)
    else
        btn:Disable()
    end
    NC.SkinTabButton(btn)
    tabButtons[i] = btn
end

if NC.RegisterThemeable then
    NC.RegisterThemeable(function()
        for _, b in ipairs(tabButtons) do NC.SkinTabButton(b) end
    end)
end

------------------------------------------------------------
-- Posicion recordada
------------------------------------------------------------
function NC.SaveWindowPos()
    if not NC.cdb then return end
    local x, y = frame:GetCenter()
    if not x then return end
    -- GetCenter del frame esta en su sistema escalado; UIParent en escala 1.
    -- Llevamos el centro del frame a coordenadas de UIParent multiplicando
    -- por la escala efectiva, para que la posicion no dependa de la pestana.
    local s = frame:GetScale() or 1
    x, y = x * s, y * s
    local px, py = UIParent:GetCenter()
    NC.cdb.winX = x - px
    NC.cdb.winY = y - py
end

function NC.RestoreWindowPos()
    if not NC.cdb or not NC.cdb.winX then return end
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", NC.cdb.winX, NC.cdb.winY)
end

-- Escala que hace caber la ventana en la pantalla (techo 1.0).
function NC.AutoScale()
    local sw = (GetScreenWidth  and GetScreenWidth())  or 1024
    local sh = (GetScreenHeight and GetScreenHeight()) or 768
    local fitW = (sw * FIT_MARGIN) / WIDTH
    local fitH = (sh * FIT_MARGIN) / HEIGHT
    local s = math.min(fitW, fitH, 1.0)   -- no agrandar por encima de 1 en auto
    if s < MIN_SCALE then s = MIN_SCALE end
    return s
end

-- Aplica la escala efectiva: la manual del usuario si la fijo, si no la auto.
function NC.ApplyScale()
    local s
    if NC.db and NC.db.uiScale then
        s = NC.db.uiScale               -- el usuario decidio a mano
    else
        s = NC.AutoScale()              -- automatica segun pantalla
    end
    if s < MIN_SCALE then s = MIN_SCALE elseif s > MAX_SCALE then s = MAX_SCALE end
    frame:SetScale(s)
    return s
end

-- Fija la escala a mano (botones o comando). A partir de aqui manda.
-- silent = true para los botones +/- (el feedback es el numero, no el chat).
function NC.SetScale(v, silent)
    v = tonumber(v)
    if not v then
        NC.Print("Uso: " .. NC.COL.accent .. "/naer escala <0.5-1.5|auto>" .. NC.COL.r
            .. "  (actual: " .. string.format("%.2f", frame:GetScale() or 1) .. ")")
        return
    end
    if v < MIN_SCALE then v = MIN_SCALE elseif v > MAX_SCALE then v = MAX_SCALE end
    NC.db.uiScale = v
    NC.ApplyScale()
    if NC.SyncScaleSlider then NC.SyncScaleSlider() end
    if not silent then
        NC.Print("Escala de la ventana: " .. NC.COL.accent .. string.format("%.2f", v) .. NC.COL.r)
    end
end

-- Vuelve al modo automatico.
function NC.ResetScaleAuto()
    NC.db.uiScale = nil
    local s = NC.ApplyScale()
    if NC.SyncScaleSlider then NC.SyncScaleSlider() end
    NC.Print("Escala de la ventana: " .. NC.COL.accent .. "automática" .. NC.COL.r
        .. " (" .. string.format("%.2f", s) .. " para tu resolución)")
end

------------------------------------------------------------
-- Abrir / cerrar
------------------------------------------------------------
function NC.ToggleWindow()
    if frame:IsShown() then
        frame:Hide()
    else
        -- mostramos el marco ANTES de construir la pestaña: si una vista fallara,
        -- la ventana igual aparece (no se queda "sin abrir").
        frame:Show()
        NC.ShowTab(NC.db and NC.db.lastTab or 1)
    end
end

-- Abre (sin alternar) la ventana en la pestaña "Información".
function NC.OpenInfoTab()
    local idx = 1
    for i, t in ipairs(NC.TABS) do
        if t.render == "info" then idx = i break end
    end
    NC.ShowTab(idx)
    frame:Show()
end
