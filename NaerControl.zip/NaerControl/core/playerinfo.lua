local ADDON, NC = ...

------------------------------------------------------------
-- Módulo de consultas de información: acumula las respuestas del servidor
-- (.player info, .raid list, .raid info) que llegan línea a línea, las arma
-- en estructuras, y avisa a la UI. Las respuestas se ocultan del chat.
------------------------------------------------------------

NC.Info = NC.Info or {}

-- Estado de la ficha actual del jugador consultado.
NC.Info.player = nil      -- { name, guild, race, class, talents, role, gs, ilvl, arenas={}, bgRating, pveRating }
NC.Info.raidList = nil    -- { player, locks = { {raidId, map, diff, active}, ... } }
NC.Info.raidInfo = nil    -- { raidId, map, diff, encounters, leader, players, roles, gs, ilvl }

-- Callback que la UI define para refrescar cuando cambian los datos.
NC.Info.OnChanged = nil

local function fire()
    if NC.Info.OnChanged then NC.Info.OnChanged() end
end

-- Normaliza el nombre a la forma de WoW (inicial en MAYÚSCULA, resto en
-- minúsculas): el servidor DISTINGUE mayúsculas, así "vyr" -> "Vyr". Sólo toca
-- la inicial si es ASCII a-z; si empieza por acento u otro byte alto, se deja
-- tal cual (no partir un carácter UTF-8).
local function capName(s)
    if type(s) ~= "string" or s == "" then return s end
    local b = string.byte(s, 1)
    if b >= 97 and b <= 122 then          -- a-z
        return string.upper(string.sub(s, 1, 1)) .. string.lower(string.sub(s, 2))
    elseif b >= 65 and b <= 90 then       -- A-Z: baja sólo el resto
        return string.sub(s, 1, 1) .. string.lower(string.sub(s, 2))
    end
    return s
end

------------------------------------------------------------
-- Recepción de .player info
------------------------------------------------------------
-- Empezamos a acumular cuando llega la cabecera; cada línea añade un campo;
-- terminamos cuando llega la línea de ayuda ".raid list" o una nueva cabecera.

function NC.Info:BeginPlayer()
    self._pAccum = { arenas = {} }
    self._pActive = true
    self._pStartedAt = GetTime and GetTime() or 0
    self._pFinishAt = nil     -- arranca sin cierre diferido pendiente
    self._pSawData = false     -- ¿ha llegado al menos un campo "Clave: Valor"?
    NC._playerInfoActive = true
    -- limpiar posibles bloques de otros tipos que hubieran quedado abiertos
    self._rlActive = false
    self._riActive = false
end

function NC.Info:FinishPlayer()
    local a = self._pAccum
    local sawData = self._pSawData
    self._pAccum = nil
    self._pActive = false
    self._pFinishAt = nil
    NC._playerInfoActive = false
    self._blockDoneAt = GetTime and GetTime() or 0

    -- Regla clave: sólo publicamos una ficha que tenga NOMBRE. Un bloque que
    -- se cierra sin nombre (borde "====" adelantado, cabecera suelta, etc.) NO
    -- debe pisar una ficha buena ni pintar una vacía; de eso se encarga el
    -- watchdog de "sin respuesta" y sólo si de verdad no llegó nada.
    -- Publicamos la ficha si tenemos NOMBRE (parseo OK) o, como red de
    -- seguridad, si llegaron líneas crudas del servidor (passthrough). Nunca
    -- pisamos una ficha buena ni pintamos vacío sin datos.
    if a and (a.name or (a.rawLines and #a.rawLines > 0)) then
        a.empty = nil
        if a.rawLines and #a.rawLines > 0 then
            a.raw = table.concat(a.rawLines, "\n")
        end
        self.player = a
        self._answered = true
        -- cache de sesión para "Recientes" (mostrar sin reenviar comandos)
        local key = string.lower(a.name or self._queriedName or "")
        if key ~= "" then
            self._cache = self._cache or {}
            self._cache[key] = self._cache[key] or {}
            self._cache[key].player = a
        end
    end

    if NC._infoDiag and NC.Console and NC.Console.LogInfo then
        NC.Console:LogInfo("[diag] FinishPlayer: accum.name=" .. tostring(a and a.name)
            .. " sawData=" .. tostring(sawData)
            .. " -> player.name=" .. tostring(self.player and self.player.name))
    end
    fire()
end

-- Procesa una línea de player info. Devuelve true si la reconoció.
function NC.Info:FeedPlayer(msg)
    local clean = NC.StripColors(msg)

    -- (1) Cabecera de player info.
    if NC.IsInfoHeader(msg, "player") then
        -- El servidor manda la cabecera DUPLICADA (a veces con retardo). Si ya
        -- hay un bloque abierto que YA capturó el nombre, esta cabecera es un
        -- duplicado: NO reiniciar (reiniciar borraría el nombre acumulado).
        -- Si el bloque abierto aún no tiene nombre, reiniciar no pierde nada.
        if self._pActive and self._pAccum and self._pAccum.name then
            return true
        end
        self:BeginPlayer()
        return true
    end
    -- (1a) Línea de ayuda terminal del servidor: "NaerZone - Puedes usar .raid
    -- list $nombre ...". Es la última del bloque y llega por dos vías (filtro +
    -- listener): la reconocemos SIEMPRE (por su texto propio) para ocultarla
    -- aunque el bloque ya se haya cerrado en la primera entrega. Si sigue
    -- activo, además cierra la ficha.
    if string.find(clean, "Puedes usar", 1, true)
       and string.find(clean, ".raid list", 1, true) then
        if self._pActive then self:FinishPlayer() end
        return true
    end

    if not self._pActive then
        -- Separador de cierre "====" huérfano que llega justo DESPUÉS de cerrar
        -- el bloque (p.ej. tras la línea ".raid list"): el bloque ya está
        -- cerrado, pero conviene tragarlo para que no se cuele solo en el chat.
        local now = GetTime and GetTime() or 0
        if self._blockDoneAt and (now - self._blockDoneAt) <= 2
           and string.find(clean, "^%s*=+%s*$") then
            return true
        end
        return false
    end

    -- (1b) Si aparece la cabecera de OTRO bloque (raid list / raid info) con un
    -- bloque de player abierto, cerramos el nuestro y cedemos: que lo procese su
    -- propio feeder (return false).
    if NC.IsInfoHeader(msg, "raidlist") or NC.IsInfoHeader(msg, "raidinfo") then
        self:FinishPlayer()
        return false
    end

    -- (2) Línea de ayuda terminal ".raid list ...": es SIEMPRE la última del
    -- bloque, así que cerramos ya (sin depender del temporizador diferido).
    if string.find(clean, ".raid list", 1, true) then
        self:FinishPlayer()
        return true
    end

    -- (3) Línea decorativa de sólo "====" (bordes de la cabecera o separador).
    -- Si aún no tenemos nombre es un borde SUPERIOR → la ignoramos (no cerrar,
    -- o descartaríamos el bloque entero). Si ya tenemos nombre, es el cierre.
    if string.find(clean, "^%s*=+%s*$") then
        if self._pAccum and self._pAccum.name then
            self:FinishPlayer()
        end
        return true
    end

    -- Passthrough: guardamos la línea tal cual (sin colores ni invisibles) como
    -- red de seguridad. Aunque el parseo por campos fallara, la tarjeta podrá
    -- mostrar el bloque completo del servidor. Dedup para la doble entrega.
    do
        local shown = clean
        shown = string.gsub(shown, "\194\160", " ")
        shown = string.gsub(shown, "\160", " ")
        shown = string.gsub(shown, "\226\128\175", " ")
        shown = string.gsub(shown, "\226\128\139", "")
        shown = strtrim(shown)
        if shown ~= "" and not string.find(shown, "^=+$") then
            self._pAccum.rawLines = self._pAccum.rawLines or {}
            local dup = false
            for _, l in ipairs(self._pAccum.rawLines) do
                if l == shown then dup = true break end
            end
            if not dup then
                self._pAccum.rawLines[#self._pAccum.rawLines + 1] = shown
            end
        end
    end

    -- (4) Línea "Clave: Valor".
    local key, val = NC.ParsePlayerInfoLine(msg)
    -- Dentro de un bloque activo, una línea no reconocida se traga igualmente
    -- (return true) para no filtrarla al chat ni romper el bloque.
    if not key then return true end
    -- El servidor mete un espacio duro (NBSP, 0xC2 0xA0 en UTF-8) tras cada
    -- código de color, y strtrim sólo quita espacios ASCII, así que sobrevive
    -- pegado a la etiqueta y al valor. Lo normalizamos a espacio y recortamos.
    key = strtrim((string.gsub(string.gsub(key, "\194\160", " "), "\160", " ")))
    val = strtrim((string.gsub(string.gsub(val or "", "\194\160", " "), "\160", " ")))
    local a = self._pAccum
    if not a then return true end
    self._pSawData = true
    self._pFinishAt = (GetTime and GetTime() or 0) + 1.0
    -- Comparación tolerante a acentos/mayúsculas por si el core varía la etiqueta.
    local nkey = NC.Normalize and NC.Normalize(key) or string.lower(key)
    -- Clave canónica: quitamos TODO lo que no sea letra/dígito ASCII o '&'.
    -- Esto la hace inmune a cualquier carácter invisible que el servidor meta
    -- (NBSP 0xA0/0xC2A0, espacios finos, tabs, etc.), sea cual sea su byte.
    -- Clave canónica INDEPENDIENTE DEL LOCALE: rangos ASCII explícitos.
    -- (%l/%d dependen del locale; en un cliente en español los bytes altos del
    --  NBSP cuentan como "letra" y sobrevivían, rompiendo el emparejamiento.)
    local ck = string.lower(string.gsub(key, "[^a-zA-Z0-9&]", ""))
    -- Valor: normalizamos espacios invisibles conocidos y recortamos.
    val = val or ""
    val = string.gsub(val, "\194\160", " ")        -- NBSP UTF-8 -> espacio
    val = string.gsub(val, "\160", " ")             -- NBSP Latin-1 -> espacio
    val = string.gsub(val, "\226\128\175", " ")    -- espacio fino -> espacio
    val = string.gsub(val, "\226\128\139", "")     -- zero-width -> fuera
    val = strtrim(val)
    -- Emparejamiento por SUBCADENA sobre la clave canónica: casa aunque delante
    -- (o detrás) quede residuo de código de color o caracteres invisibles, sea
    -- cual sea su byte. Las etiquetas son mutuamente excluyentes, no colisionan.
    local function has(kw) return string.find(ck, kw, 1, true) ~= nil end
    if has("nombre") then
        a.name = val
    elseif has("hermandad") then a.guild = val
    elseif has("clase") and has("raza") then
        -- "Humano - Paladín"
        local race, class = string.match(val, "^(.-)%s*%-%s*(.+)$")
        a.race = race and strtrim(race) or val
        a.class = class and strtrim(class) or nil
    elseif has("talentos") then a.talents = val
    elseif has("posiblerol") then a.role = val
    elseif has("gstotal") then a.gs = val
    elseif has("ilvlequipado") then a.ilvl = val
    elseif has("pverating") then a.pveRating = val
    elseif has("ratedbattleground") then a.bgRating = val
    elseif has("equipodearenas") then
        -- "Equipo de Arenas 2c2" : val "Nombre - TR: N - PR: N - MMR: N"
        local bracket = string.match(key, "(%dc%d)")
        local tr = string.match(val, "TR:%s*(%d+)")
        local pr = string.match(val, "PR:%s*(%d+)")
        local mmr = string.match(val, "MMR:%s*(%d+)")
        local teamName = string.match(val, "^(.-)%s*%-%s*TR:")
        -- dedup: si este bracket ya está (la línea llegó duplicada), lo saltamos
        local dup = false
        for _, ar in ipairs(a.arenas) do
            if ar.bracket == (bracket or "?") then dup = true; break end
        end
        if not dup then
            table.insert(a.arenas, {
                bracket = bracket or "?", team = teamName and strtrim(teamName) or "",
                tr = tr, pr = pr, mmr = mmr,
            })
        end
    end
    return true
end

------------------------------------------------------------
-- Recepción de .raid list (CDs del jugador)
------------------------------------------------------------
function NC.Info:BeginRaidList()
    self._rlAccum = { player = nil, locks = {} }
    self._rlActive = true
    self._rlActiveSince = GetTime and GetTime() or 0
    self._rlPending = false
    self._rlFinishAt = nil
    NC._raidListActive = true
end

function NC.Info:FinishRaidList()
    if self._rlAccum then self.raidList = self._rlAccum end
    -- cache de sesión (CDs) para "Recientes"
    if self._rlQueried and self.raidList then
        local key = string.lower(self._rlQueried)
        self._cache = self._cache or {}
        self._cache[key] = self._cache[key] or {}
        self._cache[key].raidList = self.raidList
    end
    self._rlAccum = nil
    self._rlActive = false
    self._rlPending = false
    self._rlFinishAt = nil
    NC._raidListActive = false
    self._blockDoneAt = GetTime and GetTime() or 0
    fire()
    if self.OnRaidList then self.OnRaidList() end
end

function NC.Info:FeedRaidList(msg)
    if NC.IsInfoHeader(msg, "raidlist") then
        self:BeginRaidList()
        return true
    end
    local clean = NC.StripColors(msg)
    -- Footer de ayuda del servidor tras .raid list: "Puedes utilizar .player
    -- info $nombre para conocer detalles...". Llega con la respuesta de la
    -- consulta de IDs; lo ocultamos del chat.
    local low0 = string.lower(clean)
    if string.find(low0, "puedes", 1, true) and string.find(low0, ".player info", 1, true) then
        return true
    end
    -- Separadores "====" del bloque de CDs: ocultarlos del chat. Si el bloque
    -- está activo, además lo cierran; si hay consulta pendiente o acaba de
    -- cerrarse, son los separadores de apertura/cierre y también se tragan.
    if string.find(clean, "^%s*=+%s*$") then
        if self._rlActive then
            self:FinishRaidList()
            return true
        end
        if self._rlPending then return true end
        if self._blockDoneAt and GetTime and (GetTime() - self._blockDoneAt) <= 2 then
            return true
        end
        return false
    end
    local r = NC.ParseRaidListLine(msg)
    if not r then return false end
    -- Este core NO envía cabecera "RAID LIST NAERZONE": auto-arrancamos el
    -- bloque en cuanto llega una línea de raid list si hay consulta pendiente.
    if not self._rlActive then
        if self._rlPending then self:BeginRaidList() else return false end
    end
    local a = self._rlAccum
    self._rlFinishAt = (GetTime and GetTime() or 0) + 1.0
    if r.kind == "player" then
        -- consultamos por nombre => normalmente un único jugador; si llegaran
        -- varios, nos quedamos con el último (sus locks van debajo).
        a.player = r.player
        a.locks = {}
        a._pendingId = nil
    elseif r.kind == "id" then
        a._pendingId = r.raidId
    elseif r.kind == "map" then
        local id = a._pendingId
        a._pendingId = nil
        -- dedup: la doble entrega (filtro + listener) puede repetir la línea de
        -- mapa; si ya existe un lock con mismo mapa+dificultad no lo duplicamos
        -- (era el bug del ID repetido como "?"). Sólo mejoramos su ID si el
        -- nuevo es válido.
        local dup = false
        for _, L in ipairs(a.locks) do
            if L.map == r.map and L.diff == r.diff then
                dup = true
                if (not L.raidId or L.raidId == 0) and id and id ~= 0 then
                    L.raidId = id
                end
                break
            end
        end
        if not dup then
            a.locks[#a.locks + 1] = {
                raidId = id, map = r.map, diff = r.diff, active = r.active,
            }
        end
    end
    return true
end

------------------------------------------------------------
-- Recepción de .raid info (por número)
------------------------------------------------------------
function NC.Info:BeginRaidInfo()
    self._riAccum = {}
    self._riActive = true
    self._riActiveSince = GetTime and GetTime() or 0
    self._riPending = false
    NC._raidInfoActive = true
end

function NC.Info:FinishRaidInfo()
    if self._riAccum then self.raidInfo = self._riAccum end
    self._riAccum = nil
    self._riActive = false
    self._riPending = false
    NC._raidInfoActive = false
    self._blockDoneAt = GetTime and GetTime() or 0
    fire()
    if self.OnRaidInfo then self.OnRaidInfo() end
end

function NC.Info:FeedRaidInfo(msg)
    if NC.IsInfoHeader(msg, "raidinfo") then
        self:BeginRaidInfo()
        return true
    end
    local clean = NC.StripColors(msg)
    local low = string.lower(clean)
    -- Respuesta de "sin miembros / ID finalizado o erróneo": el servidor manda
    -- un texto de error SIN cabecera. Si hay una consulta de raid info en curso,
    -- lo capturamos (para ocultarlo del chat) y marcamos la composición vacía.
    if (self._riPending or self._riActive)
       and (string.find(low, "ninguno de los integrantes", 1, true)
            or (string.find(low, "raidid", 1, true) and string.find(low, "conectado", 1, true))) then
        self._riActive = false
        self._riAccum = nil
        self._riPending = false
        NC._raidInfoActive = false
        self._blockDoneAt = GetTime and GetTime() or 0
        self.raidInfo = { empty = true,
            reason = "Nadie conectado en este ID (raid finalizado o vacío)." }
        fire()
        if self.OnRaidInfo then self.OnRaidInfo() end
        return true
    end
    if not self._riActive then
        -- footer suelto "NaerZone" justo tras cerrar/errar una consulta: tragarlo
        if self._blockDoneAt and GetTime and (GetTime() - self._blockDoneAt) <= 2
           and low == "naerzone" then
            return true
        end
        return false
    end
    if string.find(clean, ".player info", 1, true) then
        self:FinishRaidInfo()
        return true
    end
    local r = NC.ParseRaidInfoLine(msg)
    if not r then return false end
    local a = self._riAccum
    if r.k == "id" then a.raidId = r.v
    elseif r.k == "map" then a.map = r.map; a.diff = r.diff
    elseif r.k == "encounters" then a.encounters = r.v
    elseif r.k == "leader" then a.leader = r.v
    elseif r.k == "players" then a.players = r.v
    elseif r.k == "roles" then a.roles = r.v
    elseif r.k == "gs" then a.gs = r.gs; a.ilvl = r.ilvl
    end
    return true
end

------------------------------------------------------------
-- Punto de entrada: procesa un mensaje del sistema. Devuelve true si lo
-- reconoció (para que el filtro lo oculte del chat).
------------------------------------------------------------
function NC.Info:OnSystemMessage(msg)
    if type(msg) ~= "string" then return false end

    -- Idempotencia: la MISMA línea puede llegarnos por dos vías en el mismo
    -- instante (el filtro de chat + el listener dedicado, o varias ventanas de
    -- chat). Procesamos cada (mensaje, tick) una sola vez y devolvemos el mismo
    -- resultado a las llamadas repetidas, sin volver a mutar estado.
    local now = GetTime and GetTime() or 0
    if self._lastMsg == msg and self._lastMsgAt == now then
        return self._lastMsgResult
    end

    -- Errores del servidor a NUESTRAS consultas (jugador offline / no
    -- encontrado): los ocultamos del chat y reflejamos "sin respuesta" en el
    -- addon (ficha y/o IDs), en vez de dejar que se cuelen al chat de juego.
    -- (una ventana breve _errHideUntil oculta también la 2a entrega del error,
    --  que llega por filtro+listener en ticks distintos cuando el estado ya se
    --  limpió.)
    local elow = string.lower(NC.StripColors(msg))
    local isNotExist = string.find(elow, "does not exist", 1, true)
                    or string.find(elow, "no existe", 1, true)
    local isRiEmpty = string.find(elow, "ninguno de los integrantes", 1, true)
                   or (string.find(elow, "raidid", 1, true) and string.find(elow, "conectado", 1, true))
    local isErr = isNotExist or isRiEmpty
               or string.find(elow, "no se encuentra online", 1, true)
               or string.find(elow, "player not found", 1, true)
    if isErr and (self._queryAt or self._pActive or self._rlPending or self._rlActive
                  or self._riPending or self._riActive
                  or (self._errHideUntil and now <= self._errHideUntil)) then
        self._errHideUntil = now + 2
        -- Personaje INEXISTENTE: lo recordamos para no reenviar comandos sobre
        -- él en esta sesión (offline es distinto: puede conectarse luego).
        if isNotExist then
            self._notExist = self._notExist or {}
            local nm = self._queriedName or self._rlQueried
            if nm and nm ~= "" then
                if not self._notExist[string.lower(nm)] and NC.SetStatus then
                    NC.SetStatus("El personaje \"" .. nm .. "\" no existe.", true)
                end
                self._notExist[string.lower(nm)] = true
            end
        end
        -- consulta de ficha -> "Sin respuesta"
        if self._queryAt or self._pActive then
            self._pActive = false; self._pAccum = nil
            NC._playerInfoActive = false
            self._answered = true; self._queryAt = nil
            if not (self.player and self.player.name) then
                self.player = { empty = true, queried = self._queriedName }
            end
        end
        -- consulta de IDs -> "Sin bloqueos"
        if self._rlPending or self._rlActive then
            self._rlPending = false; self._rlActive = false
            self._rlAccum = nil; NC._raidListActive = false
            self.raidList = { player = self._rlQueried, locks = {}, empty = true }
            if self.OnRaidList then self.OnRaidList() end
        end
        -- consulta de composición -> vacía
        if self._riPending or self._riActive then
            self._riPending = false; self._riActive = false
            self._riAccum = nil; NC._raidInfoActive = false
            local reason = isRiEmpty
                and "Nadie conectado en este ID (raid finalizado o vacío)."
                or "Jugador no encontrado o sin conexión."
            self.raidInfo = { empty = true, reason = reason }
            if self.OnRaidInfo then self.OnRaidInfo() end
        end
        fire()
        self._lastMsg = msg; self._lastMsgAt = now; self._lastMsgResult = true
        return true
    end

    -- Se procesa cada línea directamente.
    local recognized = false
    if self:FeedPlayer(msg) then recognized = true
    elseif self:FeedRaidList(msg) then recognized = true
    elseif self:FeedRaidInfo(msg) then recognized = true end

    if recognized then
        self._rxCount = (self._rxCount or 0) + 1
        -- Historial en la consola: registramos la respuesta (que se oculta del
        -- chat) igual que hace .xprate/.iteminfo, para que la consola muestre
        -- "la info de los comandos". Saltamos separadores "====" puros.
        if NC.Console and NC.Console.LogHidden then
            local clean = NC.StripColors(msg)
            clean = string.gsub(clean, "^%s+", "")
            clean = string.gsub(clean, "%s+$", "")
            if clean ~= "" and not string.find(clean, "^=+$") then
                NC.Console:LogHidden(clean)
            end
        end
    end

    self._lastMsg = msg
    self._lastMsgAt = now
    self._lastMsgResult = recognized
    return recognized
end

------------------------------------------------------------
-- Peticiones al servidor
------------------------------------------------------------
function NC.Info:QueryPlayer(name)
    if not name or name == "" then
        if NC.SetStatus then NC.SetStatus("Escribe un nombre de personaje.", true) end
        return
    end
    name = capName(name)   -- el servidor distingue mayúsculas: "vyr" -> "Vyr"
    -- Personaje ya confirmado INEXISTENTE en esta sesión: no reenviamos nada.
    if self._notExist and self._notExist[string.lower(name)] then
        self.player = { empty = true, queried = name }
        self.raidList = { player = name, locks = {}, empty = true }
        if NC.SetStatus then NC.SetStatus("El personaje \"" .. name .. "\" no existe.", true) end
        if NC.Info.OnChanged then NC.Info.OnChanged() end
        return
    end
    self.player = nil
    self._lastLine = nil   -- permite reconsultar el mismo personaje
    self._pActive = false
    self._pAccum = nil
    self._pFinishAt = nil
    self._pSawData = false
    self._queriedName = name
    self._rxCount = 0
    self._queryAt = GetTime and GetTime() or 0
    self._answered = false
    if NC.Info.OnChanged then NC.Info.OnChanged() end   -- limpia la tarjeta
    NC.Send(".player info " .. name)
    -- Además, consultamos sus bloqueos de banda para que la pestaña muestre la
    -- ficha Y los CDs juntos (UI pareja). Son 2 comandos = el límite 2/10s.
    self:QueryRaidList(name)
end

-- Muestra en la ficha la info CACHEADA de un jugador (sesión) SIN reenviar
-- comandos. Devuelve true si había cache; false si no.
function NC.Info:ShowCached(name)
    if not name or name == "" then return false end
    local c = self._cache and self._cache[string.lower(name)]
    if not c then return false end
    self.player = c.player
    self.raidList = c.raidList
    self._queriedName = name
    if NC.Info.OnChanged then NC.Info.OnChanged() end
    return true
end

function NC.Info:ClearInfo()
    self.player = nil; self.raidList = nil; self.raidInfo = nil
    if NC.Info.OnChanged then NC.Info.OnChanged() end
end

function NC.Info:ForgetCached(name)
    if not self._cache then return end
    if name then self._cache[string.lower(name)] = nil else self._cache = {} end
end

function NC.Info:QueryRaidList(name)
    -- name explícito (p.ej. desde el menú del ojo) o el objetivo actual.
    if not name or name == "" then
        if UnitExists("target") and UnitIsPlayer("target") then
            name = UnitName("target")
        end
    end
    if not name or name == "" then
        if NC.SetStatus then NC.SetStatus("Selecciona a un jugador como objetivo.", true) end
        return
    end
    name = capName(name)   -- el servidor distingue mayúsculas
    if self._notExist and self._notExist[string.lower(name)] then
        self.raidList = { player = name, locks = {}, empty = true }
        self._rlQueried = name
        if self.OnRaidList then self.OnRaidList() end
        return
    end
    self.raidList = nil
    self._lastLine = nil
    self._rlActive = false
    self._rlAccum = nil
    self._rlFinishAt = nil
    self._rlPending = true
    self._rlPendingAt = nil   -- se fija cuando el comando SE ENVÍA de verdad
    self._rlQueryStart = GetTime and GetTime() or 0   -- tope duro desde la consulta
    self._rlQueried = name
    NC.Send(".raid list " .. name, function()
        NC.Info._rlPendingAt = GetTime and GetTime() or 0
    end)
end

function NC.Info:QueryRaidInfo(id)
    if not id or id == "" then
        if NC.SetStatus then NC.SetStatus("Escribe un ID de banda.", true) end
        return
    end
    self.raidInfo = nil
    self._lastLine = nil
    self._riActive = false
    self._riPending = true
    self._riQueryStart = GetTime and GetTime() or 0
    NC.Send(".raid info " .. id)
end

------------------------------------------------------------
-- Watchdog de respuesta: si tras consultar a un jugador no llega ninguna ficha
-- con datos en 2s, el servidor no devolvió información (jugador desconectado o
-- inexistente). Mostramos un aviso en la tarjeta en vez de dejarla en blanco.
------------------------------------------------------------
local answerWatch = CreateFrame("Frame")
answerWatch:SetScript("OnUpdate", function()
    local I = NC.Info
    local now = GetTime and GetTime() or 0

    -- cierre diferido del bloque de player info: si dejaron de llegar líneas,
    -- cerramos y pintamos la ficha (aunque no llegara el separador de cierre).
    -- FinishPlayer ya limpia _pFinishAt.
    if I._pActive and I._pFinishAt and now >= I._pFinishAt then
        I:FinishPlayer()
    end

    -- cierre diferido del bloque de raid list (CDs): mismo criterio.
    if I._rlActive and I._rlFinishAt and now >= I._rlFinishAt then
        I:FinishRaidList()
    end

    -- red de seguridad: un bloque de CDs que arrancó pero no cierra (p.ej. sólo
    -- llegó la cabecera, sin datos ni línea terminal) se FUERZA a cerrar a los
    -- 6s, para que la ventana nunca se quede en "Consultando…".
    if I._rlActive and I._rlActiveSince and (now - I._rlActiveSince) >= 6 then
        I:FinishRaidList()
    end

    -- timeout de la consulta de CDs. Damos por "sin bloqueos" si:
    --  - pasó 10s desde el ENVÍO real (_rlPendingAt), o
    --  - pasó 15s desde la CONSULTA (_rlQueryStart) — tope duro por si el envío
    --    se quedó en cola o el callback de envío no llegó a dispararse.
    if I._rlPending and not I._rlActive then
        local bySent  = I._rlPendingAt  and (now - I._rlPendingAt)  >= 10
        local byQuery = I._rlQueryStart and (now - I._rlQueryStart) >= 15
        if bySent or byQuery then
            I._rlPending = false
            I.raidList = { player = I._rlQueried, locks = {}, empty = true }
            fire()
            if I.OnRaidList then I.OnRaidList() end
        end
    end

    -- cierre forzado del bloque de composición (.raid info) si arranca y no
    -- cierra en 6s, para que la vista de composición no se cuelgue.
    if I._riActive and I._riActiveSince and (now - I._riActiveSince) >= 6 then
        I:FinishRaidInfo()
    end
    -- timeout de la consulta de composición: 15s desde la consulta sin respuesta.
    if I._riPending and not I._riActive and I._riQueryStart
       and (now - I._riQueryStart) >= 15 then
        I._riPending = false
        I.raidInfo = nil
        fire()
        if I.OnRaidInfo then I.OnRaidInfo() end
    end

    -- sin respuesta: consultamos y en 3s no hubo ficha con datos.
    if I._queryAt and not I._answered then
        if (now - I._queryAt) >= 3 then
            if NC._infoDiag and NC.Console and NC.Console.LogInfo then
                NC.Console:LogInfo("[diag] watchdog 3s: rxLines=" .. tostring(I._rxCount or 0)
                    .. " pActive=" .. tostring(I._pActive)
                    .. " accum.name=" .. tostring(I._pAccum and I._pAccum.name)
                    .. " sawData=" .. tostring(I._pSawData))
            end
            if I._pActive and I._pAccum and (I._pAccum.name
               or (I._pAccum.rawLines and #I._pAccum.rawLines > 0)) then
                -- bloque a medio acumular con datos (nombre o líneas crudas):
                -- ciérralo (aunque no llegara la línea de cierre).
                I:FinishPlayer()
            else
                -- de verdad no llegó nada útil para este nombre: aborta el
                -- bloque abierto (si lo hay) para no seguir tragando mensajes,
                -- y marca "sin respuesta" SIN pisar una ficha buena previa.
                if I._pActive then
                    I._pActive = false
                    I._pAccum = nil
                    I._pFinishAt = nil
                    NC._playerInfoActive = false
                end
                if not (I.player and (I.player.name or I.player.raw)) then
                    I.player = { empty = true, queried = I._queriedName }
                    if I.OnChanged then I.OnChanged() end
                end
            end
            I._queryAt = nil
        end
    end

    -- red de seguridad: un bloque abierto que no recibió NINGÚN dato y lleva
    -- demasiado tiempo (p.ej. sólo llegó una cabecera suelta) se aborta para no
    -- quedarse tragando mensajes del sistema indefinidamente.
    if I._pActive and not I._pSawData and I._pStartedAt and (now - I._pStartedAt) >= 5 then
        I._pActive = false
        I._pAccum = nil
        I._pFinishAt = nil
        NC._playerInfoActive = false
    end
end)

------------------------------------------------------------
-- Listener dedicado (register-based). Motivo: en este core, el ".player info"
-- de OTROS jugadores NO llega por CHAT_MSG_SYSTEM, y el filtro de chat
-- (ChatFrame_AddMessageEventFilter) sólo se ejecuta si ALGÚN ChatFrame muestra
-- ese evento. Con un frame propio que registra los eventos candidatos nos
-- aseguramos de recibir la respuesta pase por el evento que pase, sin depender
-- de la configuración de ventanas de chat. El filtro sigue existiendo sólo
-- para OCULTAR la línea del chat; aquí sólo la LEEMOS (OnSystemMessage es
-- idempotente por (mensaje, tick), así que no hay doble procesado).
------------------------------------------------------------
local RELAY_EVENTS = {
    "CHAT_MSG_SYSTEM", "CHAT_MSG_CHANNEL", "CHAT_MSG_SAY", "CHAT_MSG_YELL",
    "CHAT_MSG_MONSTER_SAY", "CHAT_MSG_MONSTER_YELL", "CHAT_MSG_MONSTER_WHISPER",
    "CHAT_MSG_MONSTER_EMOTE", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_RAID_BOSS_EMOTE", "CHAT_MSG_RAID_BOSS_WHISPER",
}

local infoListener = CreateFrame("Frame")
for _, e in ipairs(RELAY_EVENTS) do infoListener:RegisterEvent(e) end
infoListener:SetScript("OnEvent", function(_, event, msg)
    if not (NC.Info and NC.Info.OnSystemMessage) then return end
    NC.Info:OnSystemMessage(msg)
end)

