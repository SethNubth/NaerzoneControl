local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña "Mazmorras".
--   Bloque 1: limite de instancias/hora. Cada entrada activa con personaje,
--             hora y su cuenta atras individual (reloj B).
--   Bloque 2: registro de la cuenta. 2 columnas de 5 personajes, con icono
--             de clase + nombre + sus lockouts (id y reset).
------------------------------------------------------------

-- Coordenadas de cada clase en la textura de iconos de clase (3.3.5a).
local CLASS_ICON_TEX = "Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes"
local CLASS_COORDS = {
    WARRIOR     = {0,    0.25, 0,    0.25},
    MAGE        = {0.25, 0.5,  0,    0.25},
    ROGUE       = {0.5,  0.75, 0,    0.25},
    DRUID       = {0.75, 1,    0,    0.25},
    HUNTER      = {0,    0.25, 0.25, 0.5},
    SHAMAN      = {0.25, 0.5,  0.25, 0.5},
    PRIEST      = {0.5,  0.75, 0.25, 0.5},
    WARLOCK     = {0.75, 1,    0.25, 0.5},
    PALADIN     = {0,    0.25, 0.5,  0.75},
    DEATHKNIGHT = {0.25, 0.5,  0.5,  0.75},
}

local panel, counterFS, entriesHost, colHost
local entryRows = {}
local charCells = {}
local RefreshCharGrid   -- forward declaration (la usan los selectores)

-- Estado del filtro-semáforo. Cuando hay instancia elegida, la rejilla se
-- pinta verde/rojo/gris para esa instancia; sin filtro, muestra el resumen.
local filter = { kind = nil, name = nil, diff = nil }  -- kind: "raid"|"heroic"
local fBtnKind, fBtnName, fBtnDiff, fClearBtn

-- Menú desplegable propio (más robusto que UIDropDownMenu). Muestra una
-- lista de opciones bajo un botón; al elegir, llama onPick(value).
local openMenu
local menuWatcher
local function ShowMenu(anchor, options, onPick)
    if openMenu then openMenu:Hide(); openMenu = nil end
    -- Vigilante: cierra el menú si se hace clic fuera, SIN consumir el clic
    -- (así lo que pulses fuera se activa a la vez).
    if not menuWatcher then
        menuWatcher = CreateFrame("Frame")
        menuWatcher:Hide()
        menuWatcher:SetScript("OnUpdate", function(self)
            if not openMenu then self:Hide(); return end
            local down = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
            if down and not self._wasDown and not MouseIsOver(openMenu) then
                openMenu:Hide(); openMenu = nil
                self:Hide()
            end
            self._wasDown = down
        end)
    end
    local m = CreateFrame("Frame", nil, UIParent)
    m:SetFrameStrata("FULLSCREEN_DIALOG")
    m:SetScript("OnHide", function() if menuWatcher then menuWatcher:Hide() end end)
    m:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    local w = 220
    m:SetWidth(w)
    m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
    local y = -8
    for _, opt in ipairs(options) do
        local b = CreateFrame("Button", nil, m)
        b:SetHeight(18); b:SetWidth(w - 16)
        b:SetPoint("TOPLEFT", 8, y)
        local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        fs:SetPoint("LEFT", 2, 0)
        fs:SetText(opt.text)
        fs:SetJustifyH("LEFT")
        b:SetFontString(fs)
        local hl = b:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetTexture("Interface\\Buttons\\WHITE8X8")
        hl:SetVertexColor(0.3, 0.5, 0.8, 0.3)
        b:SetScript("OnClick", function()
            m:Hide()
            openMenu = nil
            onPick(opt.value)
        end)
        y = y - 18
    end
    m:SetHeight(-y + 12)
    openMenu = m
    menuWatcher._wasDown = IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton")
    menuWatcher:Show()
    m:Show()
end

local function BuildFilterSelector(parent, anchorFS)
    parent:HookScript("OnHide", function()
        if openMenu then openMenu:Hide(); openMenu = nil end
    end)
    local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("TOPLEFT", 6, -198)
    lbl:SetText("Ver disponibilidad de:")
    lbl:SetTextColor(0.6, 0.6, 0.65)

    fBtnKind = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    fBtnKind:SetSize(90, 20)
    fBtnKind:SetPoint("TOPLEFT", 150, -194)
    fBtnKind:SetText("Tipo…")

    fBtnName = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    fBtnName:SetSize(210, 20)
    fBtnName:SetPoint("LEFT", fBtnKind, "RIGHT", 6, 0)
    fBtnName:SetText("Instancia…")
    NC.SetButtonEnabled(fBtnName, false)

    fBtnDiff = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    fBtnDiff:SetSize(70, 20)
    fBtnDiff:SetPoint("LEFT", fBtnName, "RIGHT", 6, 0)
    fBtnDiff:SetText("Dif.")
    NC.SetButtonEnabled(fBtnDiff, false)

    fClearBtn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    fClearBtn:SetSize(60, 20)
    fClearBtn:SetPoint("LEFT", fBtnDiff, "RIGHT", 6, 0)
    fClearBtn:SetText("Quitar")
    fClearBtn:Hide()

    -- Nivel 1: tipo
    fBtnKind:SetScript("OnClick", function(self)
        ShowMenu(self, {
            { text = "Raids", value = "raid" },
            { text = "Heroicas", value = "heroic" },
        }, function(v)
            filter.kind = v; filter.name = nil; filter.diff = nil
            fBtnKind:SetText(v == "raid" and "Raids" or "Heroicas")
            fBtnName:SetText("Instancia…"); NC.SetButtonEnabled(fBtnName, true)
            fBtnDiff:SetText("Dif."); NC.SetButtonEnabled(fBtnDiff, false)
            RefreshCharGrid()
        end)
    end)

    -- Nivel 2: nombre
    fBtnName:SetScript("OnClick", function(self)
        if not filter.kind then return end
        local opts = {}
        if filter.kind == "raid" then
            for _, r in ipairs(NC.Dungeons.RAIDS) do
                table.insert(opts, { text = r.name, value = r.name })
            end
        else
            for _, h in ipairs(NC.Dungeons.HEROICS) do
                table.insert(opts, { text = h, value = h })
            end
        end
        ShowMenu(self, opts, function(v)
            filter.name = v; filter.diff = nil
            fBtnName:SetText(v)
            if filter.kind == "raid" then
                fBtnDiff:SetText("Dif."); NC.SetButtonEnabled(fBtnDiff, true)
            else
                NC.SetButtonEnabled(fBtnDiff, false)   -- heroicas no tienen dificultad
                fClearBtn:Show()
            end
            RefreshCharGrid()
        end)
    end)

    -- Nivel 3: dificultad (solo raids)
    fBtnDiff:SetScript("OnClick", function(self)
        if filter.kind ~= "raid" or not filter.name then return end
        local raid
        for _, r in ipairs(NC.Dungeons.RAIDS) do
            if r.name == filter.name then raid = r break end
        end
        if not raid then return end
        local opts = {}
        local labels = { ["10N"]="10 Normal", ["10H"]="10 Heroico",
                         ["25N"]="25 Normal", ["25H"]="25 Heroico" }
        for _, d in ipairs(raid.diffs) do
            table.insert(opts, { text = labels[d] or d, value = d })
        end
        ShowMenu(self, opts, function(v)
            filter.diff = v
            fBtnDiff:SetText(v)
            fClearBtn:Show()
            RefreshCharGrid()
        end)
    end)

    fClearBtn:SetScript("OnClick", function()
        filter.kind = nil; filter.name = nil; filter.diff = nil
        fBtnKind:SetText("Tipo…")
        fBtnName:SetText("Instancia…"); NC.SetButtonEnabled(fBtnName, false)
        fBtnDiff:SetText("Dif."); NC.SetButtonEnabled(fBtnDiff, false)
        fClearBtn:Hide()
        RefreshCharGrid()
    end)
end

------------------------------------------------------------
-- Construccion (una vez)
------------------------------------------------------------
local function BuildPanel()
    if panel then return end

    panel = CreateFrame("Frame", nil, NC.Content)
    panel:SetAllPoints(NC.Content)

    -- ===== BLOQUE 1: limite =====
    local t1 = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t1:SetPoint("TOPLEFT", 6, -6)
    t1:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "Límite de mazmorras|r  |cff888888(máx. 5 por hora, toda la cuenta)|r")

    counterFS = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    counterFS:SetPoint("TOPLEFT", 8, -30)

    -- host de las filas de entradas activas
    entriesHost = CreateFrame("Frame", nil, panel)
    entriesHost:SetPoint("TOPLEFT", 8, -52)
    entriesHost:SetPoint("TOPRIGHT", -8, -52)
    entriesHost:SetHeight(5 * 20)

    -- separador
    local sep = panel:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOPLEFT", 6, -158)
    sep:SetPoint("TOPRIGHT", -6, -158)
    sep:SetHeight(1)
    sep:SetTexture("Interface\\Buttons\\WHITE8X8")
    sep:SetVertexColor(0.3, 0.3, 0.35, 0.8)

    -- ===== BLOQUE 2: registro de la cuenta =====
    local t2 = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t2:SetPoint("TOPLEFT", 6, -170)
    t2:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "Bloqueos por personaje|r")

    -- Selector-filtro de 3 niveles (tipo / nombre / dificultad)
    BuildFilterSelector(panel, t2)

    colHost = CreateFrame("Frame", nil, panel)
    colHost:SetPoint("TOPLEFT", 6, -230)
    colHost:SetPoint("BOTTOMRIGHT", -6, 8)
end

------------------------------------------------------------
-- Bloque 1: filas de entradas activas
------------------------------------------------------------
local function GetEntryRow(i)
    if entryRows[i] then return entryRows[i] end
    local r = CreateFrame("Frame", nil, entriesHost)
    r:SetPoint("TOPLEFT", 0, -(i - 1) * 21)
    r:SetPoint("TOPRIGHT", 0, -(i - 1) * 21)
    r:SetHeight(20)

    -- punto de estado: cuadradito pequeño coloreado (textura fiable)
    r.dot = r:CreateTexture(nil, "OVERLAY")
    r.dot:SetPoint("LEFT", 8, 0)
    r.dot:SetWidth(8); r.dot:SetHeight(8)
    r.dot:SetTexture("Interface\\Buttons\\WHITE8X8")

    -- columnas alineadas
    r.who = r:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    r.who:SetPoint("LEFT", 24, 0)
    r.who:SetWidth(90); r.who:SetJustifyH("LEFT")

    r.zone = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.zone:SetPoint("LEFT", 118, 0)
    r.zone:SetWidth(160); r.zone:SetJustifyH("LEFT")
    r.zone:SetTextColor(0.85, 0.85, 0.9)

    r.time = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.time:SetPoint("LEFT", 286, 0)
    r.time:SetWidth(70); r.time:SetJustifyH("LEFT")
    r.time:SetTextColor(0.6, 0.6, 0.65)

    r.frees = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.frees:SetPoint("LEFT", 366, 0)
    r.frees:SetJustifyH("LEFT")

    entryRows[i] = r
    return r
end

local function RefreshCounter()
    if not NC.Dungeons then return end
    local used = NC.Dungeons:CountInWindow()
    local left = NC.Dungeons:Remaining()

    if left > 0 then
        counterFS:SetText("Esta hora: |cffffffff" .. used .. " / 5|r    ·    te quedan "
            .. (left <= 1 and "|cffffcc00" or "|cff9fd98f") .. left .. "|r")
    else
        counterFS:SetText("Esta hora: |cffff4040" .. used .. " / 5  ·  BLOQUEADO|r   "
            .. "|cff888888(libre en " .. NC.Dungeons:FmtTime(NC.Dungeons:TimeUntilFree()) .. ")|r")
    end

    -- filas de entradas activas
    local entries = NC.Dungeons:ActiveEntries()
    for _, r in ipairs(entryRows) do r:Hide() end
    if table.getn(entries) == 0 then
        local r = GetEntryRow(1)
        r.dot:Hide()
        r.who:SetText("|cff888888Sin mazmorras esta hora.|r")
        r.zone:SetText(""); r.time:SetText(""); r.frees:SetText("")
        r:Show()
        return
    end
    for i, e in ipairs(entries) do
        local r = GetEntryRow(i)
        r.dot:Show()
        -- color del punto segun cuanto le queda para liberarse
        if e.frees < 600 then r.dot:SetVertexColor(0.4, 1, 0.4)       -- <10m: casi libre
        elseif e.frees < 1800 then r.dot:SetVertexColor(1, 0.82, 0)   -- <30m
        else r.dot:SetVertexColor(1, 0.4, 0.4) end                    -- reciente
        r.who:SetText("|cffffd100" .. tostring(e.who) .. "|r")
        r.zone:SetText(tostring(e.zone))
        r.time:SetText(NC.Dungeons:HourMinAt(e.at))
        r.frees:SetText("|cff9fd98f" .. NC.Dungeons:FmtTime(e.frees) .. "|r")
        r:Show()
    end
end

------------------------------------------------------------
-- Bloque 2: rejilla 2x5 de personajes
------------------------------------------------------------
local CELL_W, CELL_H = 275, 46

local function BuildTooltip(cell, charName)
    local lks = NC.Dungeons:LockoutsFor(charName)
    GameTooltip:SetOwner(cell, "ANCHOR_RIGHT")
    GameTooltip:AddLine(charName, 0.35, 0.8, 1)

    -- si hay filtro activo, muestra el estado para esa instancia
    local instName = filter.name
    local ready = instName and (filter.kind == "heroic" or filter.diff)
    if ready then
        local status = NC.Dungeons:StatusFor(charName, instName,
            filter.kind == "raid" and filter.diff or nil)
        local label = instName .. (filter.diff and (" " .. filter.diff) or "")
        if status == "locked" then
            GameTooltip:AddLine(label .. ": BLOQUEADO", 1, 0.3, 0.3)
        elseif status == "free" then
            GameTooltip:AddLine(label .. ": disponible", 0.4, 1, 0.4)
        else
            GameTooltip:AddLine(label .. ": sin datos", 0.6, 0.6, 0.6)
            GameTooltip:AddLine("No te has conectado con este personaje.", 0.5, 0.5, 0.5, true)
        end
        GameTooltip:AddLine(" ")
    end

    if table.getn(lks) == 0 then
        GameTooltip:AddLine("Sin bloqueos activos.", 0.6, 0.6, 0.6)
    else
        for _, lk in ipairs(lks) do
            local kind = lk.isRaid and "|cffff8800raid|r" or "|cff66bbffheroica|r"
            GameTooltip:AddLine(string.format("%s (%s) %s  ·  %s",
                lk.name, tostring(lk.diffName or lk.maxP), kind,
                NC.Dungeons:FmtTime(lk.remain)), 1, 1, 1)
        end
    end
    GameTooltip:Show()
end

local function GetCharCell(i)
    if charCells[i] then return charCells[i] end
    local cell = CreateFrame("Frame", nil, colHost)
    local col = (i - 1) % 2
    local rowI = math.floor((i - 1) / 2)
    cell:SetPoint("TOPLEFT", col * (CELL_W + 14), -rowI * (CELL_H + 6))
    cell:SetWidth(CELL_W); cell:SetHeight(CELL_H)
    cell:EnableMouse(true)

    -- fondo para el semáforo (verde/rojo/gris cuando hay filtro)
    cell.bg = cell:CreateTexture(nil, "BACKGROUND")
    cell.bg:SetAllPoints()
    cell.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    cell.bg:SetVertexColor(0, 0, 0, 0)   -- transparente por defecto

    cell.icon = cell:CreateTexture(nil, "OVERLAY")
    cell.icon:SetPoint("TOPLEFT", 2, -2)
    cell.icon:SetWidth(32); cell.icon:SetHeight(32)

    cell.name = cell:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    cell.name:SetPoint("TOPLEFT", cell.icon, "TOPRIGHT", 8, -1)

    cell.summary = cell:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    cell.summary:SetPoint("TOPLEFT", cell.icon, "TOPRIGHT", 8, -18)
    cell.summary:SetJustifyH("LEFT")

    -- tooltip con el detalle al pasar el raton
    cell:SetScript("OnEnter", function(self)
        if self._char then BuildTooltip(self, self._char) end
    end)
    cell:SetScript("OnLeave", function() GameTooltip:Hide() end)

    charCells[i] = cell
    return cell
end

function RefreshCharGrid()
    if not NC.Dungeons then return end
    for _, c in ipairs(charCells) do c:Hide() end

    local chars = NC.Dungeons:AllChars()
    if table.getn(chars) == 0 then
        local cell = GetCharCell(1)
        cell._char = nil
        cell.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        cell.icon:SetTexCoord(0, 1, 0, 1)
        cell.name:SetText("|cff888888Sin personajes|r")
        cell.summary:SetText("|cff666666Conéctate con cada uno para registrarlo.|r")
        cell:Show()
        return
    end

    for i, ch in ipairs(chars) do
        local cell = GetCharCell(i)
        cell._char = ch.name

        local coords = ch.class and CLASS_COORDS[ch.class]
        if coords then
            cell.icon:SetTexture(CLASS_ICON_TEX)
            cell.icon:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
        else
            cell.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
            cell.icon:SetTexCoord(0, 1, 0, 1)
        end
        cell.name:SetText(ch.name)

        local raids, heroics, total = NC.Dungeons:LockoutSummary(ch.name)
        if total == 0 then
            cell.summary:SetText("|cff555555sin bloqueos|r")
        else
            local parts = {}
            if raids > 0 then
                table.insert(parts, "|cffff8800" .. raids .. (raids == 1 and " raid" or " raids") .. "|r")
            end
            if heroics > 0 then
                table.insert(parts, "|cff66bbff" .. heroics .. (heroics == 1 and " heroica" or " heroicas") .. "|r")
            end
            cell.summary:SetText(table.concat(parts, "  ·  ") .. "  |cff888888(pasa el ratón)|r")
        end

        -- semáforo: si hay filtro con instancia elegida, pinta el fondo
        local instName = filter.name
        local ready = instName and (filter.kind == "heroic" or filter.diff)
        if ready then
            local status = NC.Dungeons:StatusFor(ch.name, instName,
                filter.kind == "raid" and filter.diff or nil)
            if status == "locked" then
                cell.bg:SetVertexColor(0.6, 0.1, 0.1, 0.45)      -- rojo
            elseif status == "free" then
                cell.bg:SetVertexColor(0.1, 0.5, 0.1, 0.40)      -- verde
            else
                cell.bg:SetVertexColor(0.3, 0.3, 0.3, 0.45)      -- gris: sin datos
            end
        else
            cell.bg:SetVertexColor(0, 0, 0, 0)                   -- sin filtro
        end

        cell:Show()
    end
end

------------------------------------------------------------
-- Mostrar / ocultar
------------------------------------------------------------
function NC.ShowDungeonsView()
    BuildPanel()
    if NC.Dungeons then NC.Dungeons:RefreshLockouts() end
    RefreshCounter()
    RefreshCharGrid()
    panel:Show()

    if not panel._ticking then
        panel._ticking = true
        panel:SetScript("OnUpdate", function(self, elapsed)
            self._acc = (self._acc or 0) + (elapsed or 0)
            if self._acc < 1 then return end
            self._acc = 0
            if self:IsShown() then
                RefreshCounter()
                RefreshCharGrid()
            end
        end)
    end
end

function NC.HideDungeonsView()
    if panel then panel:Hide() end
end
