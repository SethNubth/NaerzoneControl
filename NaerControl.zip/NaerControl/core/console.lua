local ADDON, NC = ...

------------------------------------------------------------
-- Consola de comandos.
--
-- Registra cada comando que el addon envia (via NC.Send -> DoSend) con su
-- hora, y empareja la respuesta del servidor cuando la reconocemos (rates,
-- iteminfo). El historial es de la SESION: no se guarda en disco, se limpia
-- al recargar. Resuelve ademas que el "Enviado: ..." de la barra de estado
-- desaparecia en segundos; aqui queda el registro.
------------------------------------------------------------

NC.Console = {}

local MAX_LINES = 200
local lines = {}          -- { time, cmd, reply }
local frame, msgFrame

local function Now()
    return date("%H:%M:%S")
end

-- Añade una linea de comando enviado.
function NC.Console:LogSent(cmd)
    table.insert(lines, { time = Now(), cmd = cmd, reply = nil })
    while table.getn(lines) > MAX_LINES do table.remove(lines, 1) end
    self.pendingIdx = table.getn(lines)   -- para emparejar la proxima respuesta
    if frame and frame:IsShown() then self:Redraw() end
end

-- Asocia una respuesta del servidor al ultimo comando compatible.
-- match: subcadena que debe contener el comando para emparejar (p.ej. "xprate").
function NC.Console:LogReply(text, match)
    -- busca hacia atras el ultimo comando que encaje y no tenga respuesta
    for i = table.getn(lines), 1, -1 do
        local L = lines[i]
        if L.cmd and not L.reply and (not match or string.find(L.cmd, match, 1, true)) then
            L.reply = text
            if frame and frame:IsShown() then self:Redraw() end
            return
        end
    end
    -- respuesta sin comando asociado: la registramos como linea suelta
    table.insert(lines, { time = Now(), cmd = nil, reply = text })
    while table.getn(lines) > MAX_LINES do table.remove(lines, 1) end
    if frame and frame:IsShown() then self:Redraw() end
end

function NC.Console:LineCount()
    return table.getn(lines)
end

function NC.Console:Clear()
    while table.getn(lines) > 0 do table.remove(lines) end
    if frame and frame:IsShown() then self:Redraw() end
end

------------------------------------------------------------
-- Registro central: cualquier mensaje relevante del addon.
-- kind decide el color:
--   "sent"   comando enviado          (azul)
--   "reply"  respuesta del servidor   (verde)
--   "hidden" mensaje del sistema ocultado del chat (verde apagado)
--   "info"   aviso normal del addon   (blanco)
--   "warn"   aviso de error / cola    (rojo)
------------------------------------------------------------
function NC.Console:LogEntry(kind, text)
    if type(text) ~= "string" or text == "" then return end
    -- limpiar códigos de color para guardar el texto plano; el color lo pone
    -- la consola según el tipo.
    local clean = NC.StripColors and NC.StripColors(text) or text

    -- Deduplicación: el filtro de chat se ejecuta una vez por cada ventana de
    -- chat, así que el mismo mensaje llega varias veces casi a la vez. Ignoramos
    -- un registro idéntico (mismo tipo y texto) si es muy reciente.
    local now = GetTime and GetTime() or 0
    if self._lastKind == kind and self._lastMsg == clean
        and (now - (self._lastAt or 0)) < 0.5 then
        return
    end
    self._lastKind = kind
    self._lastMsg = clean
    self._lastAt = now

    table.insert(lines, { time = Now(), kind = kind, msg = clean })
    while table.getn(lines) > MAX_LINES do table.remove(lines, 1) end
    if frame and frame:IsShown() then self:Redraw() end
end

-- Atajos
function NC.Console:LogHidden(text) self:LogEntry("hidden", text) end
function NC.Console:LogInfo(text)   self:LogEntry("info", text)   end
function NC.Console:LogWarn(text)   self:LogEntry("warn", text)   end

function NC.Console:Redraw()
    if not msgFrame then return end
    msgFrame:Clear()
    local COLORS = {
        sent   = "|cff7ec8e3",   -- azul
        reply  = "|cff9fd98f",   -- verde
        hidden = "|cff7fae7f",   -- verde apagado (ocultado del chat)
        info   = "|cffdddddd",   -- blanco
        warn   = "|cffff5555",   -- rojo
    }
    for i = 1, table.getn(lines) do
        local L = lines[i]
        if L.kind and L.msg then
            -- línea de registro central (LogEntry)
            local col = COLORS[L.kind] or "|cffffffff"
            local prefix = ""
            if L.kind == "hidden" then prefix = "· " end
            if L.kind == "warn" then prefix = "⚠ " end
            msgFrame:AddMessage("|cff888888" .. L.time .. "|r  " .. col .. prefix .. L.msg .. "|r")
        else
            -- línea clásica comando + respuesta
            if L.cmd then
                msgFrame:AddMessage("|cff888888" .. L.time .. "|r  |cff7ec8e3"
                    .. L.cmd .. "|r", 1, 1, 1)
            end
            if L.reply then
                msgFrame:AddMessage("        |cff9fd98f> " .. L.reply .. "|r", 0.6, 0.85, 0.55)
            end
        end
    end
end

function NC.Console:Build()
    if frame then return frame end

    frame = CreateFrame("Frame", "NaerControlConsole", UIParent)
    frame:SetWidth(460)
    frame:SetHeight(340)
    frame:SetPoint("CENTER", 260, 0)
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetClampedToScreen(true)
    frame:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    frame:Hide()
    tinsert(UISpecialFrames, "NaerControlConsole")

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 16, -14)
    title:SetText("Consola de comandos")
    title:SetTextColor(0.35, 0.8, 1)

    local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hint:SetPoint("TOPLEFT", 16, -32)
    hint:SetText("Historial de esta sesión. En azul lo enviado, en verde la respuesta del servidor.")
    hint:SetTextColor(0.6, 0.6, 0.65)

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    local bg = CreateFrame("Frame", nil, frame)
    bg:SetPoint("TOPLEFT", 16, -52)
    bg:SetPoint("BOTTOMRIGHT", -16, 44)
    bg:SetBackdrop({
        bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    bg:SetBackdropColor(0, 0, 0, 0.5)
    bg:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.8)
    if NC.RegisterThemeable then
        NC.RegisterThemeable(function(t)
            local ac = (t and t.accent) or {0.35, 0.8, 1}
            title:SetTextColor(ac[1], ac[2], ac[3])
            if t and t.name == "modern" then
                frame:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.9)
                bg:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.6)
            else
                frame:SetBackdropBorderColor(1, 1, 1, 1)
                bg:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.8)
            end
        end)
    end

    msgFrame = CreateFrame("ScrollingMessageFrame", "NaerControlConsoleMessages", frame)
    msgFrame:SetPoint("TOPLEFT", bg, "TOPLEFT", 8, -8)
    msgFrame:SetPoint("BOTTOMRIGHT", bg, "BOTTOMRIGHT", -8, 8)
    msgFrame:SetFontObject(GameFontHighlightSmall)
    msgFrame:SetJustifyH("LEFT")
    msgFrame:SetMaxLines(MAX_LINES)
    msgFrame:SetFading(false)
    msgFrame:EnableMouseWheel(true)
    msgFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then self:ScrollUp() else self:ScrollDown() end
    end)

    local clearBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    clearBtn:SetSize(90, 22)
    clearBtn:SetPoint("BOTTOMRIGHT", -16, 14)
    clearBtn:SetText("Limpiar")
    clearBtn:SetScript("OnClick", function() NC.Console:Clear() end)

    frame:SetScript("OnShow", function() NC.Console:Redraw(); msgFrame:ScrollToBottom() end)

    return frame
end

function NC.Console:Toggle()
    self:Build()
    if frame:IsShown() then frame:Hide() else frame:Show() end
    return frame:IsShown()
end
