local ADDON, NC = ...

------------------------------------------------------------
-- Traducción de nombres de instancias.
--
-- El servidor manda el nombre en INGLÉS (p.ej. "Icecrown Citadel",
-- "Halls of Stone"). Aquí lo mapeamos al español OFICIAL (nombres tal
-- como aparecen en Wowhead ES / cliente es-ES).
--
-- La clave se NORMALIZA (minúsculas, sin "the " inicial, recortada) para
-- tolerar variantes de mayúsculas/espacios/artículo.
--
-- Lo que NO esté en la tabla se muestra en INGLÉS tal cual (fallback
-- seguro): nunca se rompe ni sale vacío. Se irá ampliando la tabla.
------------------------------------------------------------

local T = {
    -- ===== Bandas WotLK =====
    ["vault of archavon"]           = "La Cámara de Archavon",
    ["naxxramas"]                   = "Naxxramas",
    ["obsidian sanctum"]            = "El Sagrario Obsidiana",
    ["eye of eternity"]             = "El Ojo de la Eternidad",
    ["ulduar"]                      = "Ulduar",
    ["trial of the crusader"]       = "Prueba del Cruzado",
    ["trial of the grand crusader"] = "Prueba del Gran Cruzado",
    ["onyxia's lair"]               = "Guarida de Onyxia",
    ["icecrown citadel"]            = "Ciudadela de la Corona de Hielo",
    ["ruby sanctum"]                = "El Sagrario Rubí",

    -- ===== Mazmorras WotLK =====
    ["utgarde keep"]                = "Fortaleza de Utgarde",
    ["utgarde pinnacle"]            = "Pináculo de Utgarde",
    ["nexus"]                       = "El Nexo",
    ["oculus"]                      = "El Óculo",
    ["azjol-nerub"]                 = "Azjol-Nerub",
    ["ahn'kahet: the old kingdom"]  = "Ahn'kahet: El Antiguo Reino",
    ["ahn'kahet"]                   = "Ahn'kahet: El Antiguo Reino",
    ["drak'tharon keep"]            = "Fortaleza de Drak'Tharon",
    ["gundrak"]                     = "Gundrak",
    ["halls of stone"]              = "Cámaras de Piedra",
    ["halls of lightning"]          = "Cámaras de Relámpagos",
    ["violet hold"]                 = "Bastión Violeta",
    ["culling of stratholme"]       = "La Matanza de Stratholme",
    ["trial of the champion"]       = "Prueba del Campeón",
    ["forge of souls"]              = "La Forja de Almas",
    ["pit of saron"]                = "Foso de Saron",
    ["halls of reflection"]         = "Cámaras de Reflexión",

    -- ===== Bandas Classic =====
    ["molten core"]                 = "Núcleo de Magma",
    ["blackwing lair"]              = "Guarida de Alanegra",
    ["zul'gurub"]                   = "Zul'Gurub",
    ["ruins of ahn'qiraj"]          = "Ruinas de Ahn'Qiraj",
    ["ahn'qiraj temple"]            = "Templo de Ahn'Qiraj",
    ["temple of ahn'qiraj"]         = "Templo de Ahn'Qiraj",

    -- ===== Bandas TBC =====
    ["karazhan"]                    = "Karazhan",
    ["gruul's lair"]                = "Guarida de Gruul",
    ["magtheridon's lair"]          = "Guarida de Magtheridon",
    ["serpentshrine cavern"]        = "Caverna Santuario Serpiente",
    ["tempest keep"]                = "El Castillo de la Tempestad",
    ["the eye"]                     = "El Castillo de la Tempestad",
    ["hyjal summit"]                = "Pasado Hyjal",
    ["battle for mount hyjal"]      = "Pasado Hyjal",
    ["black temple"]                = "Templo Oscuro",
    ["zul'aman"]                    = "Zul'Aman",
    ["sunwell plateau"]             = "La Fuente del Sol",

    -- ===== Mazmorras heróicas TBC (verificadas en Wowhead ES) =====
    -- El servidor manda "Complejo: Instancia"; LocalizeInstance recorta el
    -- prefijo y busca la parte final, así que la clave es el nombre propio
    -- (en forma normalizada, sin "the" inicial).
    ["hellfire ramparts"]           = "Murallas del Fuego Infernal",
    ["ramparts"]                    = "Murallas del Fuego Infernal",
    ["blood furnace"]               = "El Horno de Sangre",
    ["shattered halls"]             = "Salas Arrasadas",
    ["slave pens"]                  = "Recinto de los Esclavos",
    ["underbog"]                    = "La Sotiénaga",
    ["steamvault"]                  = "La Cámara de Vapor",
    ["mana-tombs"]                  = "Tumbas de Maná",
    ["mana tombs"]                  = "Tumbas de Maná",
    ["auchenai crypts"]             = "Criptas Auchenai",
    ["sethekk halls"]               = "Salas Sethekk",
    ["shadow labyrinth"]            = "Laberinto de las Sombras",
    ["mechanar"]                    = "El Mechanar",
    ["botanica"]                    = "El Invernáculo",
    ["arcatraz"]                    = "El Arcatraz",
    ["old hillsbrad foothills"]     = "La huida de Durnholde",
    ["old hillsbrad"]               = "La huida de Durnholde",
    ["black morass"]                = "La Ciénaga Negra",
    ["magisters' terrace"]          = "Bancal del Magister",
    ["magister's terrace"]          = "Bancal del Magister",

    -- ===== Mazmorras Classic (no bloquean pero dan ID, salen en el reporte) =====
    -- (Gnomeregan, Uldaman, Zul'Farrak, Maraudon, Stratholme son iguales en
    --  inglés/español; el fallback ya las muestra bien, no hace falta listarlas.)
    ["ragefire chasm"]              = "Sima Ígnea",
    ["wailing caverns"]             = "Cuevas de los Lamentos",
    ["deadmines"]                   = "Las Minas de la Muerte",
    ["shadowfang keep"]             = "Castillo de Colmillo Oscuro",
    ["blackfathom deeps"]           = "Cavernas de Brazanegra",
    ["stockade"]                    = "Mazmorras de Ventormenta",
    ["stormwind stockade"]          = "Mazmorras de Ventormenta",
    ["razorfen kraul"]              = "Horado Rajacieno",
    ["razorfen downs"]              = "Zahúrda Rajacieno",
    ["scarlet monastery"]           = "Monasterio Escarlata",
    ["temple of atal'hakkar"]       = "Templo Sumergido",
    ["sunken temple"]               = "Templo Sumergido",
    ["blackrock depths"]            = "Profundidades de Roca Negra",
    ["blackrock spire"]             = "Cumbre de Roca Negra",
    ["lower blackrock spire"]       = "Cumbre de Roca Negra Inferior",
    ["upper blackrock spire"]       = "Cumbre de Roca Negra Superior",
    ["dire maul"]                   = "La Masacre",
    ["scholomance"]                 = "Scholomance",
}

-- Normaliza una clave/nombre: minúsculas, recortado, sin "the " inicial.
local function norm(s)
    if type(s) ~= "string" then return "" end
    s = string.lower(s)
    s = string.gsub(s, "^%s+", "")
    s = string.gsub(s, "%s+$", "")
    s = string.gsub(s, "^the%s+", "")
    return s
end

-- Traduce un nombre de instancia al español SI la opción está activada y hay
-- traducción. Si la opción está desactivada o no hay traducción, devuelve el
-- nombre original (inglés). Nunca devuelve nil ni cadena vacía si le llega uno
-- válido.
function NC.LocalizeInstance(name)
    if type(name) ~= "string" or name == "" then return name end
    -- La opción vive en NC.db.translateInstances (por defecto activada: solo se
    -- desactiva si el usuario la pone en false explícitamente).
    if NC.db and NC.db.translateInstances == false then
        return name
    end
    local hit = T[norm(name)]
    if hit then return hit end
    -- Nombre compuesto "Complejo: Instancia" (p.ej. "Tempest Keep: The
    -- Arcatraz"): traducimos la parte final; si no está, mostramos al menos esa
    -- parte (más corta y limpia que el compuesto en inglés).
    local suffix = string.match(name, ":%s*(.+)$")
    if suffix then
        suffix = string.gsub(suffix, "^%s+", "")
        suffix = string.gsub(suffix, "%s+$", "")
        return T[norm(suffix)] or suffix
    end
    return name
end

-- ¿El lock es de BANDA (10/25/40) o de MAZMORRA (5)? Se decide por el número
-- de la dificultad ("5N", "5H", "10N", "25H"...). Fallback seguro: si no hay
-- número reconocible, se trata como banda (mejor mostrar de más que esconder
-- un ID de banda útil).
function NC.IsRaidLock(diff)
    if type(diff) ~= "string" then return true end
    local n = tonumber(string.match(diff, "%d+"))
    if not n then return true end
    return n ~= 5
end

-- Expuesto por si algún día se quiere consultar/ampliar desde otro módulo.
NC.INSTANCE_ES = T
