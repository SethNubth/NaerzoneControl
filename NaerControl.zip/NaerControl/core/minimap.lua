local ADDON, NC = ...

------------------------------------------------------------
-- Boton de minimapa autonomo.
-- Sustituye a LibStub + LibDataBroker + LibDBIcon + CallbackHandler.
-- Guarda el angulo en NaerControlDB.minimapAngle.
------------------------------------------------------------

local RADIUS = 80
local button

-- ¿Está Carbonite (u otro reemplazo de minimapa) cargado? Carbonite oculta
-- o reparenta el Minimap DESPUÉS de nuestra carga, así que detectarlo por
-- nombre es más fiable que inspeccionar el estado del minimapa.
local function CarboniteLoaded()
    if IsAddOnLoaded then
        if IsAddOnLoaded("Carbonite") or IsAddOnLoaded("NxMap")
            or IsAddOnLoaded("Cartographer") then
            return true
        end
    end
    -- frames típicos que crea Carbonite
    if _G.Nx or _G.CarboniteFrame or _G.Nx_Minimap then return true end
    return false
end

-- ¿El minimapa estándar está disponible y visible? Con Carbonite (u otros
-- addons que reemplazan el minimapa), Minimap queda oculto y un botón anclado
-- a él desaparece. En ese caso pasamos a modo flotante libre.
local function MinimapUsable()
    if NC.db and NC.db.minimapForceFloat then return false end   -- forzado manual
    if CarboniteLoaded() then return false end   -- Carbonite: directo a flotante
    if not Minimap then return false end
    if not Minimap:IsShown() then return false end
    -- si el minimapa no está visible en la jerarquía (padre oculto), no vale
    if Minimap.IsVisible and not Minimap:IsVisible() then return false end
    local w = Minimap:GetWidth() or 0
    if w < 10 then return false end
    return true
end

-- Coloca el botón: orbitando el minimapa si es usable, o flotante si no.
local function UpdatePosition()
    if not button then return end

    if not MinimapUsable() then
        -- MODO FLOTANTE (Carbonite u otro): posición libre en UIParent.
        local pos = NC.db and NC.db.minimapFloat
        button:ClearAllPoints()
        if pos and pos.x and pos.y then
            button:SetPoint("CENTER", UIParent, "BOTTOMLEFT", pos.x, pos.y)
        else
            -- primera vez: esquina superior izquierda, visible
            button:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -20)
        end
        button.floating = true
        -- asegurar visibilidad (salvo que el usuario lo ocultara a propósito)
        if not (NC.db and NC.db.minimapHide) then
            button:Show()
        end
        return
    end

    -- MODO ORBITAL (minimapa normal).
    button.floating = false
    local angle = math.rad(NC.db and NC.db.minimapAngle or 220)
    local x, y = math.cos(angle), math.sin(angle)

    local shape = (GetMinimapShape and GetMinimapShape()) or "ROUND"
    if shape ~= "ROUND" then
        x = math.max(-RADIUS, math.min(x * 103.13, RADIUS))
        y = math.max(-RADIUS, math.min(y * 103.13, RADIUS))
    else
        x, y = x * RADIUS, y * RADIUS
    end

    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function OnDragUpdate(self)
    if self.floating then
        -- flotante: sigue el cursor libremente y guarda posición absoluta
        local px, py = GetCursorPosition()
        local scale = UIParent:GetEffectiveScale()
        px, py = px / scale, py / scale
        self:ClearAllPoints()
        self:SetPoint("CENTER", UIParent, "BOTTOMLEFT", px, py)
        NC.db.minimapFloat = { x = px, y = py }
        return
    end
    -- orbital: gira alrededor del minimapa
    local mx, my = Minimap:GetCenter()
    local px, py = GetCursorPosition()
    local scale = Minimap:GetEffectiveScale()
    px, py = px / scale, py / scale
    if NC.db then
        NC.db.minimapAngle = math.deg(math.atan2(py - my, px - mx)) % 360
    end
    UpdatePosition()
end

function NC.CreateMinimapButton()
    if button then return button end

    -- Parent UIParent (no Minimap): si Carbonite oculta el minimapa, un hijo
    -- suyo se ocultaría también. Colgando de UIParent el botón sobrevive, y
    -- UpdatePosition decide si orbita el minimapa o flota libre.
    button = CreateFrame("Button", "NaerControlMinimapButton", UIParent)
    button:SetWidth(31)
    button:SetHeight(31)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)
    button:RegisterForClicks("anyUp")
    button:RegisterForDrag("LeftButton")
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetWidth(20)
    icon:SetHeight(20)
    icon:SetTexture(NC.MEDIA .. "icon")
    icon:SetTexCoord(0.06, 0.94, 0.06, 0.94)
    icon:SetPoint("TOPLEFT", 7, -6)
    button.icon = icon

    local overlay = button:CreateTexture(nil, "OVERLAY")
    overlay:SetWidth(53)
    overlay:SetHeight(53)
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    overlay:SetPoint("TOPLEFT")

    button:SetScript("OnDragStart", function(self)
        self:LockHighlight()
        self:SetScript("OnUpdate", OnDragUpdate)
        self.isMoving = true
        GameTooltip:Hide()
    end)

    button:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
        self:UnlockHighlight()
        self.isMoving = nil
    end)

    button:SetScript("OnClick", function(self, mouseButton)
        if mouseButton == "RightButton" then
            NC.ToggleEye()
        else
            NC.ToggleWindow()
        end
    end)

    button:SetScript("OnEnter", function(self)
        if self.isMoving then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("NaerControl")
        GameTooltip:AddLine("Clic izquierdo: abrir / cerrar", 1, 1, 1)
        GameTooltip:AddLine("Clic derecho: mostrar / ocultar el ojo", 1, 1, 1)
        GameTooltip:AddLine("Arrastrar: mover el botón", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)

    button:SetScript("OnLeave", function() GameTooltip:Hide() end)

    UpdatePosition()

    -- Reevaluación diferida: Carbonite (u otros) pueden ocultar el minimapa
    -- DESPUÉS de nuestra carga. Reintentamos a los pocos segundos para
    -- detectar el modo correcto (orbital vs flotante).
    local recheck = CreateFrame("Frame")
    recheck.t = 0
    recheck.tries = 0
    recheck:RegisterEvent("PLAYER_ENTERING_WORLD")
    recheck:SetScript("OnEvent", function() UpdatePosition() end)
    recheck:SetScript("OnUpdate", function(self, elapsed)
        self.t = self.t + (elapsed or 0)
        if self.t < 1 then return end
        self.t = 0
        self.tries = self.tries + 1
        UpdatePosition()
        if self.tries >= 10 then
            self:SetScript("OnUpdate", nil)   -- tras 10s dejamos de comprobar
        end
    end)

    if NC.db and NC.db.minimapHide then
        button:Hide()
    end

    return button
end

function NC.ToggleMinimapButton()
    if not button then return end
    if button:IsShown() then
        button:Hide()
        NC.db.minimapHide = true
        NC.Print("Botón de minimapa oculto. Usa /nc icono para recuperarlo.")
    else
        button:Show()
        NC.db.minimapHide = false
        UpdatePosition()
    end
end

-- Alterna el modo flotante forzado (red de seguridad para Carbonite u otros
-- reemplazos de minimapa que la detección automática no capte).
function NC.ToggleFloatButton()
    if not NC.db then return end
    NC.db.minimapForceFloat = not NC.db.minimapForceFloat
    if NC.db.minimapForceFloat then
        NC.db.minimapFloat = nil   -- reinicia posición para que aparezca visible
        NC.Print("Botón en modo |cffffd100flotante|r (arrástralo donde quieras). "
            .. "Repite el comando para volver al minimapa.")
    else
        NC.Print("Botón vuelve al |cffffd100minimapa|r.")
    end
    if button and not NC.db.minimapHide then button:Show() end
    UpdatePosition()
end
