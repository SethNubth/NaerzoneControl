local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña "Ajustes": hub central de opciones, organizadas por CATEGORÍAS.
--
-- Cada entrada de OPTIONS tiene un 'type':
--   "header"   -> encabezado de sección  { type="header", label="..." }
--   "check"    -> casilla (por defecto)   usa dbKey/default o get/set a medida
--   "dropdown" -> desplegable             { dbKey, default, choices={{value,text}...} }
--   "custom"   -> fila a medida           { build = function(parent, y) ... return y end }
------------------------------------------------------------

local OPTIONS = {
    -- ===== Apariencia =====
    { type = "header", label = "Apariencia" },
    {
        type    = "dropdown",
        dbKey   = "theme",
        default = "classic",
        label   = "Tema",
        note    = "El cambio de tema global se aplicará próximamente.",
        choices = {
            { value = "classic", text = "Clásico" },
            { value = "modern",  text = "Escarcha" },
        },
        onChange = function(v)
            if NC.ApplyTheme then NC.ApplyTheme(v) end
            if NC.SetStatus then
                NC.SetStatus("Tema seleccionado: " .. (v == "modern" and "Escarcha" or "Clásico"))
            end
        end,
    },
    {
        type    = "check",
        label   = "Mostrar botón en el minimapa",
        tooltip = "Muestra u oculta el icono de NaerControl en el minimapa.",
        note    = "Usa /naer para mostrar el addon",
        get = function() return not (NC.db and NC.db.minimapHide) end,
        set = function(on)
            if NC.db then NC.db.minimapHide = not on end
            local btn = _G.NaerControlMinimapButton
            if btn then if on then btn:Show() else btn:Hide() end end
        end,
    },
    {
        type  = "custom",
        build = function(parent, y)
            local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            lbl:SetPoint("TOPLEFT", 8, y)
            lbl:SetText("Tamaño de la ventana")

            local minus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            minus:SetSize(24, 22); minus:SetText("-")
            minus:SetPoint("TOPLEFT", 230, y + 4)

            local valFS = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            valFS:SetPoint("LEFT", minus, "RIGHT", 6, 0)
            valFS:SetWidth(42); valFS:SetJustifyH("CENTER")
            NC._scaleFS = valFS

            local plus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            plus:SetSize(24, 22); plus:SetText("+")
            plus:SetPoint("LEFT", valFS, "RIGHT", 6, 0)

            local autoB = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            autoB:SetSize(96, 22); autoB:SetText("Automático")
            autoB:SetPoint("LEFT", plus, "RIGHT", 10, 0)

            local STEP = 0.05
            minus:SetScript("OnClick", function()
                local f = NC.Frame
                if NC.SetScale then NC.SetScale(((f and f:GetScale()) or 1) - STEP, true) end
            end)
            plus:SetScript("OnClick", function()
                local f = NC.Frame
                if NC.SetScale then NC.SetScale(((f and f:GetScale()) or 1) + STEP, true) end
            end)
            autoB:SetScript("OnClick", function()
                if NC.ResetScaleAuto then NC.ResetScaleAuto() end
            end)

            if NC.SyncScaleSlider then NC.SyncScaleSlider() end
            return y - 36
        end,
    },
    {
        type  = "custom",
        build = function(parent, y)
            local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            lbl:SetPoint("TOPLEFT", 8, y)
            lbl:SetText("Opacidad del fondo")

            local minus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            minus:SetSize(24, 22); minus:SetText("-")
            minus:SetPoint("TOPLEFT", 230, y + 4)

            local valFS = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            valFS:SetPoint("LEFT", minus, "RIGHT", 6, 0)
            valFS:SetWidth(48); valFS:SetJustifyH("CENTER")
            NC._opacityFS = valFS

            local plus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            plus:SetSize(24, 22); plus:SetText("+")
            plus:SetPoint("LEFT", valFS, "RIGHT", 6, 0)

            local STEP = 0.1
            minus:SetScript("OnClick", function()
                if NC.ApplyOpacity then NC.ApplyOpacity((NC.GetOpacity and NC.GetOpacity() or 1) - STEP) end
            end)
            plus:SetScript("OnClick", function()
                if NC.ApplyOpacity then NC.ApplyOpacity((NC.GetOpacity and NC.GetOpacity() or 1) + STEP) end
            end)

            if NC.SyncOpacity then NC.SyncOpacity() end
            return y - 36
        end,
    },

    -- ===== Información =====
    { type = "header", label = "Información" },
    {
        type    = "check",
        dbKey   = "translateInstances",
        default = true,
        label   = "Traducir nombres de instancias al español",
        tooltip = "Muestra los nombres de bandas y mazmorras en español (Wowhead ES) "
               .. "en lugar del inglés que envía el servidor. Los nombres que aún no "
               .. "estén traducidos se muestran en inglés.",
        onChange = function()
            if NC.RefreshIdsWindow then NC.RefreshIdsWindow() end
            if NC.Info and NC.Info.OnChanged then NC.Info.OnChanged() end
        end,
    },
    {
        type    = "check",
        dbKey   = "showDungeonLocks",
        default = false,
        label   = "Mostrar también mazmorras (5) en los IDs",
        tooltip = "Por defecto la lista de IDs muestra solo BANDAS (10/25/40), que son "
               .. "las útiles para .raid info. Actívalo para ver también los bloqueos "
               .. "de mazmorra heroica (5), que suelen ser muchos y meter ruido.",
        onChange = function()
            if NC.RefreshIdsWindow then NC.RefreshIdsWindow() end
            if NC.Info and NC.Info.OnChanged then NC.Info.OnChanged() end
        end,
    },

    -- ===== Ojo del escáner =====
    { type = "header", label = "Ojo del escáner" },
    {
        type  = "custom",
        build = function(parent, y)
            local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            lbl:SetPoint("TOPLEFT", 8, y)
            lbl:SetText("Tamaño del ojo")
            local minus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            minus:SetSize(24, 22); minus:SetText("-")
            minus:SetPoint("TOPLEFT", 230, y + 4)
            local valFS = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            valFS:SetPoint("LEFT", minus, "RIGHT", 6, 0)
            valFS:SetWidth(48); valFS:SetJustifyH("CENTER")
            NC._eyeScaleFS = valFS
            local plus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            plus:SetSize(24, 22); plus:SetText("+")
            plus:SetPoint("LEFT", valFS, "RIGHT", 6, 0)
            minus:SetScript("OnClick", function() if NC.EyeAddScale then NC.EyeAddScale(-0.1) end end)
            plus:SetScript("OnClick", function() if NC.EyeAddScale then NC.EyeAddScale(0.1) end end)
            if NC.SyncEyeSettings then NC.SyncEyeSettings() end
            return y - 36
        end,
    },
    {
        type  = "custom",
        build = function(parent, y)
            local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            lbl:SetPoint("TOPLEFT", 8, y)
            lbl:SetText("Transparencia del ojo")
            local minus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            minus:SetSize(24, 22); minus:SetText("-")
            minus:SetPoint("TOPLEFT", 230, y + 4)
            local valFS = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            valFS:SetPoint("LEFT", minus, "RIGHT", 6, 0)
            valFS:SetWidth(48); valFS:SetJustifyH("CENTER")
            NC._eyeAlphaFS = valFS
            local plus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            plus:SetSize(24, 22); plus:SetText("+")
            plus:SetPoint("LEFT", valFS, "RIGHT", 6, 0)
            minus:SetScript("OnClick", function() if NC.EyeAddAlpha then NC.EyeAddAlpha(-0.1) end end)
            plus:SetScript("OnClick", function() if NC.EyeAddAlpha then NC.EyeAddAlpha(0.1) end end)
            if NC.SyncEyeSettings then NC.SyncEyeSettings() end
            return y - 36
        end,
    },
    {
        type = "check",
        label = "Atenuar el ojo cuando no paso el ratón",
        tooltip = "El ojo se ve tenue en reposo y opaco al pasar el ratón por encima.",
        get = function() return NC.db and NC.db.eyeFade == true end,
        set = function(on)
            if NC.db then NC.db.eyeFade = on and true or false end
            if NC.Eye then NC.Eye:ApplySettings() end
        end,
    },
    {
        type = "check",
        label = "Bloquear la posición del ojo",
        tooltip = "Impide mover el ojo al arrastrarlo.",
        get = function() return NC.db and NC.db.eyeLock == true end,
        set = function(on)
            if NC.db then NC.db.eyeLock = on and true or false end
            if NC.Eye then NC.Eye:ApplySettings() end
        end,
    },
    {
        type = "check",
        label = "Ocultar el ojo en combate",
        tooltip = "Esconde el ojo mientras estás en combate y lo recupera al salir.",
        get = function() return NC.db and NC.db.eyeHideCombat == true end,
        set = function(on)
            if NC.db then NC.db.eyeHideCombat = on and true or false end
            if NC.Eye then NC.Eye:ApplySettings() end
        end,
    },
    {
        type  = "custom",
        build = function(parent, y)
            local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            btn:SetSize(170, 22)
            btn:SetPoint("TOPLEFT", 8, y)
            btn:SetText("Resetear posición del ojo")
            btn:SetScript("OnClick", function()
                if NC.ResetEyePosition then NC.ResetEyePosition() end
            end)
            return y - 30
        end,
    },

    { type = "header", label = "Herramientas" },
    {
        type  = "custom",
        build = function(parent, y)
            local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
            btn:SetSize(150, 22); btn:SetText("Abrir consola")
            btn:SetPoint("TOPLEFT", 6, y + 2)
            btn:SetScript("OnClick", function() if NC.Console then NC.Console:Toggle() end end)
            local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            lbl:SetPoint("LEFT", btn, "RIGHT", 10, 0)
            lbl:SetText("Historial de comandos enviados y respuestas del servidor.")
            return y - 36
        end,
    },
}

local panel, outer

local function optValue(opt)
    if opt.get then return opt.get() and true or false end
    local v = NC.db and NC.db[opt.dbKey]
    if v == nil then v = opt.default end
    return v and true or false
end

-- Encabezado de sección (barra de acento + título). Sigue el tema.
local function buildHeader(opt, y)
    local accent = panel:CreateTexture(nil, "ARTWORK")
    accent:SetPoint("TOPLEFT", 6, y - 1)
    accent:SetSize(3, 16)
    local h = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    h:SetPoint("TOPLEFT", 14, y)
    local function skin(th)
        accent:SetTexture(th.accent[1], th.accent[2], th.accent[3], 1)
        h:SetText("|cff" .. (NC.ThemeHex and NC.ThemeHex("accent") or "7ec8e3") .. opt.label .. "|r")
    end
    if NC.RegisterThemeable then NC.RegisterThemeable(skin) else skin(NC.Theme or NC.THEMES.classic) end
    return y - 26
end

-- Casilla (soporta get/set a medida, p.ej. el minimapa).
local function buildCheck(opt, y)
    local cb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", 10, y)
    cb:SetWidth(26); cb:SetHeight(26)
    cb:SetChecked(optValue(opt))

    local lbl = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    lbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    lbl:SetText(opt.label)

    cb:SetScript("OnClick", function(self)
        local on = self:GetChecked() and true or false
        if opt.set then opt.set(on)
        elseif NC.db then NC.db[opt.dbKey] = on end
        if opt.onChange then opt.onChange() end
        if NC.SetStatus then
            NC.SetStatus("Ajuste " .. (on and "activado" or "desactivado") .. ": " .. opt.label)
        end
    end)
    cb:SetScript("OnEnter", function(self)
        if not opt.tooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(opt.label)
        GameTooltip:AddLine(opt.tooltip, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    cb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local ny = y - 34
    if opt.note then
        local note = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        note:SetPoint("TOPLEFT", 14, ny + 6)
        note:SetText(opt.note)
        ny = ny - 14
    end
    return ny
end

-- Desplegable (UIDropDownMenu). Guarda opt.dbKey; onChange(valor).
local function buildDropdown(opt, y)
    local lbl = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    lbl:SetPoint("TOPLEFT", 12, y)
    lbl:SetText(opt.label)

    local function current()
        local v = NC.db and NC.db[opt.dbKey]
        if v == nil then v = opt.default end
        return v
    end
    local function textFor(val)
        for _, c in ipairs(opt.choices) do if c.value == val then return c.text end end
        return tostring(val)
    end
    local function apply(v)
        if NC.db then NC.db[opt.dbKey] = v end
        if opt.onChange then opt.onChange(v) end
    end

    -- Desplegable PROPIO (tema Moderno)
    local ddModern = NC.CreateDropdown(panel, {
        width = 150, choices = opt.choices, get = current,
        onChange = function(v) apply(v) end,
    })
    ddModern:SetPoint("TOPLEFT", 150, y + 6)

    -- Desplegable BLIZZARD (tema Clásico)
    local ddClassic = CreateFrame("Frame", "NaerControlDD_" .. tostring(opt.dbKey or "x"), panel, "UIDropDownMenuTemplate")
    ddClassic:SetPoint("TOPLEFT", 134, y + 2)
    if UIDropDownMenu_SetWidth then UIDropDownMenu_SetWidth(ddClassic, 130) end
    UIDropDownMenu_Initialize(ddClassic, function(_, level)
        for _, c in ipairs(opt.choices) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = c.text; info.value = c.value
            info.checked = (current() == c.value)
            info.func = function()
                UIDropDownMenu_SetText(ddClassic, c.text)
                if CloseDropDownMenus then CloseDropDownMenus() end
                apply(c.value)
            end
            UIDropDownMenu_AddButton(info, level)
        end
    end)
    UIDropDownMenu_SetText(ddClassic, textFor(current()))

    -- Alternar cuál se ve según el tema (DIFERIDO: no tocar el dropdown en uso)
    local function toggle()
        if NC.Theme and NC.Theme.name == "modern" then
            ddClassic:Hide(); ddModern:Show()
            if ddModern.Refresh then ddModern:Refresh() end
        else
            ddModern:Hide(); ddClassic:Show()
            UIDropDownMenu_SetText(ddClassic, textFor(current()))
        end
    end
    local defer = CreateFrame("Frame"); defer:Hide()
    defer:SetScript("OnUpdate", function(self) self:Hide(); toggle() end)
    if NC.RegisterThemeable then NC.RegisterThemeable(function() defer:Show() end) end
    toggle()   -- estado inicial

    local ny = y - 34
    if opt.note then
        local note = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        note:SetPoint("TOPLEFT", 14, ny + 4)
        note:SetText(opt.note)
        ny = ny - 16
    end
    return ny
end

local function build()
    outer = CreateFrame("Frame", nil, NC.Content)
    outer:SetAllPoints(NC.Content)

    local title = outer:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 4, -4)
    title:SetText("|cffffffffAjustes|r")

    local intro = outer:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    intro:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    intro:SetText("Se guardan automáticamente.")
    intro:SetTextColor(0.7, 0.7, 0.75)

    -- Área scrolleable con las opciones (para poder crecer en el futuro).
    local scroll, content = NC.CreateScroll(outer)
    scroll:SetPoint("TOPLEFT", 0, -46)
    scroll:SetPoint("BOTTOMRIGHT", -22, 4)
    content:SetWidth(scroll:GetWidth() or 1)
    scroll:SetScript("OnSizeChanged", function(_, w) content:SetWidth(w or 1) end)
    panel = content   -- los constructores de opciones dibujan sobre 'panel'

    local y = -6
    for _, opt in ipairs(OPTIONS) do
        if opt.type == "header" then
            y = buildHeader(opt, y)
        elseif opt.type == "dropdown" then
            y = buildDropdown(opt, y)
        elseif opt.type == "custom" and opt.build then
            y = opt.build(panel, y)
        else
            y = buildCheck(opt, y)
        end
    end
    content:SetHeight(-y + 12)

    if NC.SkinPanel then NC.SkinPanel(panel) end   -- skin de tema a botones/casillas
    if NC.SkinScrollOf then NC.SkinScrollOf(scroll) end
end

-- Refresca el porcentaje de opacidad mostrado en Ajustes.
function NC.SyncOpacity()
    if NC._opacityFS then
        NC._opacityFS:SetText(math.floor((NC.GetOpacity and NC.GetOpacity() or 1) * 100 + 0.5) .. "%")
    end
end

function NC.ShowSettingsView()
    if not outer then build() end
    if outer then outer:Show() end
    NC.Content:Show()
    if NC.SyncScaleSlider then NC.SyncScaleSlider() end
    if NC.SyncOpacity then NC.SyncOpacity() end
end

function NC.HideSettingsView()
    if outer then outer:Hide() end
end
