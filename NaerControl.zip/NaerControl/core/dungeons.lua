local ADDON, NC = ...

------------------------------------------------------------
-- Mazmorras: lockouts y limite de instancias por hora.
--
-- LIMITE 5/HORA (de cuenta): cada instancia nueva generada cuenta. Una
-- entrada cuenta si es la primera o viene tras un reinicio. Cada entrada
-- guarda personaje + hora + zona, y tiene su propio reloj de 1h (reloj B):
-- caduca (deja de contar) 1h despues de generarse. Confirmado con sesion
-- real: 5 ciclos entrar+reiniciar y la 6a da bloqueo. El mensaje del
-- servidor corrige el contador si se desincroniza.
--
-- LOCKOUTS: 100% fiables (GetSavedInstanceInfo). Por personaje, visibles
-- para toda la cuenta. Cada personaje registra su clase al conectarse.
------------------------------------------------------------

NC.Dungeons = {}

------------------------------------------------------------
-- Catálogo de instancias de NAERZONE (nombres exactos del cliente).
-- Las raids tienen sus modalidades; las heroicas son todas de 5 heroico.
------------------------------------------------------------
NC.Dungeons.RAIDS = {
    { name = "Naxxramas",                        diffs = { "10N", "25N" } },
    { name = "El Ojo de la Eternidad",           diffs = { "10N", "25N" } },
    { name = "El Sagrario Obsidiana",            diffs = { "10N", "25N" } },
    { name = "Ulduar",                           diffs = { "10N", "25N" } },
    { name = "Guarida de Onyxia",                diffs = { "10N", "25N" } },
    { name = "La Cámara de Archavon",            diffs = { "10N", "25N" } },
    { name = "Prueba del Cruzado",               diffs = { "10N", "10H", "25N", "25H" } },
    { name = "Ciudadela de la Corona de Hielo",  diffs = { "10N", "10H", "25N", "25H" } },
    { name = "El Sagrario Rubí",                 diffs = { "10N", "10H", "25N", "25H" } },
}

NC.Dungeons.HEROICS = {
    "Ahn'Kahet: El Antiguo Reino", "Azjol-Nerub", "Cámaras de Piedra",
    "Cámaras de Reflexión", "Cámaras de Relámpagos", "El Bastión Violeta",
    "El Nexo", "El Oculus", "Fortaleza de Drak'Tharon", "Fortaleza de Utgarde",
    "Foso de Saron", "Gundrak", "La Forja de Almas", "La Matanza de Stratholme",
    "Pináculo de Utgarde", "Prueba del Campeón",
}

-- Traduce (diff numérico + maxPlayers) del juego a nuestra etiqueta "10N"...
-- En 3.3.5a: diff 1=10N, 2=heroico5, 3=10H, 4=25N... con matices por raid.
-- Para raids: 10N=diff1(maxP10), 25N=diff2(maxP25), 10H=diff3, 25H=diff4.
function NC.Dungeons.DiffLabel(diff, maxP, isRaid)
    if not isRaid then return "H5" end   -- heroica de 5
    if diff == 1 then return "10N"
    elseif diff == 2 then return "25N"
    elseif diff == 3 then return "10H"
    elseif diff == 4 then return "25H" end
    -- respaldo por maxPlayers
    if maxP == 25 then return "25N" else return "10N" end
end


local HOUR = 3600
local LIMIT = 5

------------------------------------------------------------
-- Registro de personajes de la cuenta (clase + nombre)
------------------------------------------------------------
local function CharStore()
    NaerControlDB.chars = NaerControlDB.chars or {}
    return NaerControlDB.chars
end

-- ¿Estás en una mazmorra del BUSCADOR (aleatoria)? Esas no cuentan para el
-- límite manual de 5/hora. Probamos varias APIs de 3.3.5a de forma defensiva.
local function IsRandomFinderDungeon()
    if type(IsPartyLFG) == "function" then
        local ok, res = pcall(IsPartyLFG)
        if ok and res then return true end
    end
    if type(IsInLFGDungeon) == "function" then
        local ok, res = pcall(IsInLFGDungeon)
        if ok and res then return true end
    end
    if type(GetLFGMode) == "function" then
        local ok, mode = pcall(GetLFGMode)
        if ok and mode then return true end
    end
    return false
end

-- Nombre de la mazmorra actual. GetRealZoneText a veces devuelve la zona
-- exterior (p.ej. "Corona de Hielo") al entrar a Forja; GetInstanceInfo da
-- el nombre real de la instancia. Preferimos ese.
local function CurrentInstanceName()
    if type(GetInstanceInfo) == "function" then
        local name = GetInstanceInfo()
        if name and name ~= "" then return name end
    end
    return GetRealZoneText and GetRealZoneText() or "?"
end

-- Registra el personaje actual (clase, para el icono). Se llama al conectar.
function NC.Dungeons:RegisterChar()
    local me = UnitName("player")
    if not me then return end
    local _, classFile = UnitClass("player")   -- p.ej. "WARRIOR"
    local store = CharStore()
    store[me] = store[me] or {}
    store[me].class = classFile
    store[me].lastSeen = time()
end

-- Lista de personajes conocidos, ordenados por nombre.
function NC.Dungeons:AllChars()
    local out = {}
    for name, data in pairs(CharStore()) do
        table.insert(out, { name = name, class = data.class })
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

------------------------------------------------------------
-- Lockouts (por personaje, visibles para toda la cuenta)
------------------------------------------------------------
local function LockStore()
    NaerControlDB.lockouts = NaerControlDB.lockouts or {}
    return NaerControlDB.lockouts
end

function NC.Dungeons:RefreshLockouts()
    if type(GetNumSavedInstances) ~= "function" then return end
    local me = UnitName("player")
    if not me then return end
    local now = time()
    local list = {}
    local n = GetNumSavedInstances() or 0
    for i = 1, n do
        local name, id, reset, diff, locked, ext, mostSig, isRaid, maxP, diffName =
            GetSavedInstanceInfo(i)
        if name and locked then
            table.insert(list, {
                name = name, id = id, diff = diff, diffName = diffName,
                isRaid = isRaid, maxP = maxP,
                resetAt = now + (tonumber(reset) or 0),
            })
        end
    end
    LockStore()[me] = { updated = now, list = list }
end

-- Lockouts de un personaje concreto, con tiempo restante recalculado.
function NC.Dungeons:LockoutsFor(char)
    local data = LockStore()[char]
    if not data then return {} end
    local out = {}
    local now = time()
    for _, lk in ipairs(data.list or {}) do
        local remain = (lk.resetAt or 0) - now
        if remain > 0 then
            table.insert(out, {
                name = lk.name, id = lk.id, diffName = lk.diffName,
                isRaid = lk.isRaid, maxP = lk.maxP, remain = remain,
            })
        end
    end
    table.sort(out, function(a, b)
        if a.isRaid ~= b.isRaid then return a.isRaid end
        return a.remain < b.remain
    end)
    return out
end

------------------------------------------------------------
-- Contador de instancias por hora (de cuenta)
-- Cada marca: { t = epoch, who = personaje, zone = nombre }
------------------------------------------------------------
local function EnterStore()
    NaerControlDB.instEnters = NaerControlDB.instEnters or {}
    return NaerControlDB.instEnters
end

local function Purge()
    local now = time()
    local s = EnterStore()
    -- Migracion: versiones antiguas guardaban solo el epoch (numero).
    -- Convertimos a la estructura nueva para no petar al leer .t
    for i = 1, table.getn(s) do
        if type(s[i]) == "number" then
            s[i] = { t = s[i], who = "?", zone = "?", approx = true }
        end
    end
    local i = 1
    while i <= table.getn(s) do
        if now - s[i].t > HOUR then
            table.remove(s, i)
        else
            i = i + 1
        end
    end
end

-- Registra una instancia nueva. approx=true si no sabemos el momento exacto
-- del reinicio (usamos la hora de entrada como estimacion).
function NC.Dungeons:CountEntry(approx)
    table.insert(EnterStore(), {
        t = time(),
        who = UnitName("player"),
        zone = CurrentInstanceName(),
        approx = approx and true or false,
    })
    Purge()
end

function NC.Dungeons:CountInWindow()
    Purge()
    return table.getn(EnterStore())
end

-- Lista de entradas activas (con su tiempo restante para liberarse).
function NC.Dungeons:ActiveEntries()
    Purge()
    local out = {}
    local now = time()
    for _, e in ipairs(EnterStore()) do
        table.insert(out, {
            who = e.who, zone = e.zone, approx = e.approx,
            at = e.t,
            frees = (e.t + HOUR) - now,   -- reloj B: cuanto para que caduque
        })
    end
    table.sort(out, function(a, b) return a.at < b.at end)
    return out
end

function NC.Dungeons:TimeUntilFree()
    Purge()
    local s = EnterStore()
    local n = table.getn(s)
    if n < LIMIT then return 0 end
    local oldest = s[n - LIMIT + 1]
    local free = (oldest.t + HOUR) - time()
    return free > 0 and free or 0
end

function NC.Dungeons:Remaining()
    local left = LIMIT - self:CountInWindow()
    return left > 0 and left or 0
end

function NC.Dungeons:OnServerBlock()
    Purge()
    local s = EnterStore()
    -- El servidor bloquea: hay 5 instancias activas y el ultimo intento fue
    -- rechazado. Si registramos una entrada de mas (la 6a rechazada), es la
    -- MAS RECIENTE: la quitamos. Si nos falta alguna, rellenamos.
    while table.getn(s) > LIMIT do
        table.remove(s)          -- quita la ultima (la rechazada)
    end
    while table.getn(s) < LIMIT do
        table.insert(s, 1, { t = time() - 1, who = UnitName("player"),
                             zone = "?", approx = true })
    end
end

function NC.Dungeons:FmtTime(sec)
    sec = math.floor(sec)
    if sec < 0 then sec = 0 end
    if sec >= HOUR then
        return string.format("%dh %dm", math.floor(sec / HOUR), math.floor((sec % HOUR) / 60))
    elseif sec >= 60 then
        return string.format("%dm", math.floor(sec / 60))
    end
    return sec .. "s"
end

-- Devuelve "HH:MM" de una marca de epoch, sin usar date(fmt, epoch) que en
-- 3.3.5a no es fiable. Calcula a partir de la hora actual y la diferencia.
function NC.Dungeons:HourMinAt(epoch)
    local now = time()
    local nowH = tonumber(date("%H")) or 0
    local nowM = tonumber(date("%M")) or 0
    local nowS = tonumber(date("%S")) or 0
    -- segundos desde medianoche ahora, menos la diferencia hasta la marca
    local secOfDay = nowH * 3600 + nowM * 60 + nowS - (now - epoch)
    -- normaliza al rango de un dia
    secOfDay = secOfDay % 86400
    if secOfDay < 0 then secOfDay = secOfDay + 86400 end
    local h = math.floor(secOfDay / 3600)
    local m = math.floor((secOfDay % 3600) / 60)
    return string.format("%02d:%02d", h, m)
end

-- Resumen de lockouts de un personaje: cuenta raids y heroicas.
function NC.Dungeons:LockoutSummary(char)
    local lks = self:LockoutsFor(char)
    local raids, heroics = 0, 0
    for _, lk in ipairs(lks) do
        if lk.isRaid then raids = raids + 1 else heroics = heroics + 1 end
    end
    return raids, heroics, table.getn(lks)
end

------------------------------------------------------------
-- Filtro-semáforo: estado de cada personaje para una instancia elegida.
--
-- Resets de NAERZONE (hora española del servidor):
--   heroicas: cada día a las 9:00
--   raids:    martes a las 9:00
-- Con esos horarios podemos caducar lockouts aunque no nos hayamos
-- reconectado con el personaje, haciendo el semáforo mas fiable.
------------------------------------------------------------

-- Hora española (UTC+1 invierno / UTC+2 verano). Aproximacion por horario
-- de verano europeo (ultimo domingo de marzo a ultimo domingo de octubre).
local function SpainOffset()
    local m = tonumber(date("!%m")) or 1
    -- meses claramente en verano/invierno; en los limite tiramos por lo comun
    if m > 3 and m < 10 then return 2 end
    return 1
end

-- epoch del ultimo reset diario (hoy o ayer a las 9:00 hora española).
local function LastDailyReset()
    local off = SpainOffset()
    local nowUtc = time()
    -- hora española actual
    local h = (tonumber(date("!%H")) or 0) + off
    local resetHour = 9
    -- segundos desde las 9:00 de hoy (español)
    local secSinceMidnight = ((h % 24) * 3600)
        + (tonumber(date("!%M")) or 0) * 60 + (tonumber(date("!%S")) or 0)
    local sinceReset = secSinceMidnight - resetHour * 3600
    if sinceReset < 0 then sinceReset = sinceReset + 86400 end
    return nowUtc - sinceReset
end

-- ¿Un lockout guardado sigue vigente, según su tipo y los horarios de reset?
-- Usamos el resetAt real de la API si esta disponible; los horarios son un
-- respaldo para datos viejos.
function NC.Dungeons:LockoutStillValid(lk)
    if not lk then return false end
    -- si tenemos el resetAt real, es la verdad
    if lk.resetAt then return lk.resetAt > time() end
    return true
end

-- Estado de un personaje para una instancia (nombre + etiqueta de dificultad).
-- Devuelve "locked" | "free" | "nodata".
function NC.Dungeons:StatusFor(char, instName, diffLabel)
    local data = LockStore()[char]
    if not data then return "nodata" end   -- nunca logueado con el addon
    for _, lk in ipairs(data.list or {}) do
        local label = NC.Dungeons.DiffLabel(lk.diff, lk.maxP, lk.isRaid)
        local matchDiff = (diffLabel == nil) or (label == diffLabel)
        if lk.name == instName and matchDiff then
            if (lk.resetAt or 0) > time() then
                return "locked"
            end
        end
    end
    return "free"
end

------------------------------------------------------------
-- Listener permanente (siempre activo)
------------------------------------------------------------
local watcher

function NC.Dungeons:Init()
    self:RegisterChar()
    if not watcher then
        watcher = CreateFrame("Frame")
        watcher:RegisterEvent("PLAYER_ENTERING_WORLD")
        watcher:RegisterEvent("ZONE_CHANGED_NEW_AREA")
        watcher:RegisterEvent("UPDATE_INSTANCE_INFO")
        watcher:RegisterEvent("CHAT_MSG_SYSTEM")
        watcher:SetScript("OnEvent", function(self, event, ...)
            NC.Dungeons:OnEvent(event, ...)
        end)
    end
    self:RefreshLockouts()
end

function NC.Dungeons:OnEvent(event, a1)
    if event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
        local inInst, instType = IsInInstance()
        if inInst and instType == "party" then
            local here = CurrentInstanceName()
            -- Las aleatorias del buscador NO cuentan para el limite manual.
            if IsRandomFinderDungeon() then
                self._afterReset = false
                self._lastZone = here
                self._insideNow = true
                return
            end
            -- Cuenta una instancia nueva si: es la primera, viene tras un
            -- reinicio, o es una mazmorra DISTINTA de la ultima en la que
            -- estabas (cambiar de Foso a Forja cuenta, aunque no reinicies).
            -- Salir y reentrar a la MISMA sin reinicio no cuenta.
            local isNew = self._afterReset
                or not self._everCounted
                or (self._lastZone ~= nil and here ~= self._lastZone)
            if isNew then
                self:CountEntry(not self._afterReset)
                self:AnnounceOnEntry()
                self._everCounted = true
            end
            self._afterReset = false
            self._lastZone = here
            self._insideNow = true
        elseif not inInst then
            self._insideNow = false
        end

    elseif event == "UPDATE_INSTANCE_INFO" then
        self:RefreshLockouts()

    elseif event == "CHAT_MSG_SYSTEM" then
        local low = string.lower(a1 or "")
        if string.find(low, "demasiadas estancias", 1, true) then
            self:OnServerBlock()
        elseif string.find(low, "se ha reiniciado", 1, true) then
            self._afterReset = true
        end
    end
end

function NC.Dungeons:AnnounceOnEntry()
    local used = self:CountInWindow()
    local left = LIMIT - used
    if left > 0 then
        NC.Print("Mazmorras esta hora: " .. NC.COL.accent .. used .. "/" .. LIMIT .. NC.COL.r
            .. ".  Te quedan " .. NC.COL.accent .. left .. NC.COL.r .. " antes del bloqueo.")
    else
        NC.Print("Límite de " .. LIMIT .. " mazmorras/hora alcanzado. "
            .. "Podrás entrar en " .. NC.COL.accent .. self:FmtTime(self:TimeUntilFree()) .. NC.COL.r .. ".")
    end
end
