local ADDON, NC = ...

local CFG = NC.CFG

local container, scroll, content, backBtn, breadcrumb, allBtn
local menuPool, itemPool = {}, {}

NC.Scanner = {
    view    = "expansions",  -- expansions -> raids -> diffs -> bosses -> items
    expac   = nil,           -- índice de expansión elegida
    raidsel = nil,           -- tabla de banda elegida (de EXPANSIONS[x].raids)
    mode    = nil,           -- clave de modo/dificultad (p.ej. "ICC10N")
    boss    = nil,
    awaiting = nil,   -- { id, name, target, time }
}

-- Resultados de la sesion:
--   Results[jugador][itemID] = { state = "yes"|"no"|"pending", place, count, time }
NC.Results = {}

local MARK = {
    pending = "Interface\\RaidFrame\\ReadyCheck-Waiting",
    yes     = "Interface\\RaidFrame\\ReadyCheck-Ready",
    no      = "Interface\\RaidFrame\\ReadyCheck-NotReady",
    -- vendido para recuperar: se ve, pero avisamos aparte con el borde naranja
    sold    = "Interface\\RaidFrame\\ReadyCheck-Ready",
}

------------------------------------------------------------
-- Pools
------------------------------------------------------------
local function CurrentResult(itemID)
    local target = UnitExists("target") and UnitName("target") or nil
    if not target then return nil end
    local t = NC.Results[target]
    return t and t[itemID]
end

local function HideAll()
    for _, b in ipairs(menuPool) do b:Hide() end
    for _, b in ipairs(itemPool) do b:Hide() end
end

local function GetMenuButton(i)
    if menuPool[i] then return menuPool[i] end

    local btn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
    btn:SetHeight(38)

    -- Icono a la izquierda del botón: oculto a propósito. Los iconos de objeto
    -- daban problemas (texturas erróneas o vacías), así que dejamos solo el
    -- texto. Se conserva el objeto por si se quisiera reactivar en el futuro.
    btn.icon = btn:CreateTexture(nil, "ARTWORK")
    btn.icon:SetWidth(28)
    btn.icon:SetHeight(28)
    btn.icon:SetPoint("LEFT", 6, 0)
    btn.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    btn.icon:Hide()

    btn.label = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    -- Texto centrado: el UIPanelButtonTemplate tiene un degradado en los
    -- extremos que "come" el texto pegado al borde. Centrándolo con margen
    -- simétrico, el texto queda limpio y legible en ambos lados.
    btn.label:SetPoint("LEFT", btn, "LEFT", 12, 0)
    btn.label:SetPoint("RIGHT", btn, "RIGHT", -12, 0)
    btn.label:SetJustifyH("CENTER")
    btn:SetFontString(btn.label)

    if NC.SkinButton then NC.SkinButton(btn) end   -- tema (Blizzard/oscuro) en toda la pool, no solo los visibles al abrir
    menuPool[i] = btn
    return btn
end

local function GetItemButton(i)
    if itemPool[i] then return itemPool[i] end

    local btn = CreateFrame("Button", nil, content)
    btn:SetWidth(CFG.IconSize)
    btn:SetHeight(CFG.IconSize)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    btn.icon = btn:CreateTexture(nil, "BACKGROUND")
    btn.icon:SetAllPoints()
    btn.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    local hl = btn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
    hl:SetBlendMode("ADD")

    btn.border = btn:CreateTexture(nil, "OVERLAY")
    btn.border:SetPoint("TOPLEFT", -2, 2)
    btn.border:SetPoint("BOTTOMRIGHT", 2, -2)
    btn.border:SetTexture("Interface\\Buttons\\WHITE8X8")
    btn.border:SetVertexColor(0, 0, 0, 0)

    btn.mark = btn:CreateTexture(nil, "OVERLAY")
    btn.mark:SetWidth(20)
    btn.mark:SetHeight(20)
    btn.mark:SetPoint("TOPRIGHT", 3, 3)
    btn.mark:Hide()

    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetHyperlink("item:" .. self.itemID)
        GameTooltip:AddLine(" ")

        local info = CurrentResult(self.itemID)
        if info then
            local who = UnitName("target") or "objetivo"
            if info.state == "sold" then
                GameTooltip:AddLine(who .. ": VENDIDO PARA RECUPERAR", 1, 0.5, 0)
                GameTooltip:AddLine("Lo tiene en la lista del vendedor", 1, 0.7, 0.2)
            elseif info.state == "yes" then
                local place = info.place or "inventario"
                local cant  = info.count and (" x" .. info.count) or ""
                GameTooltip:AddLine(who .. ": lo tiene (" .. place .. cant .. ")", 0.4, 1, 0.4)
            elseif info.state == "no" then
                GameTooltip:AddLine(who .. ": no lo tiene", 1, 0.4, 0.4)
            else
                GameTooltip:AddLine(who .. ": esperando respuesta...", 1, 0.82, 0)
            end
            GameTooltip:AddLine(" ")
        end

        GameTooltip:AddLine("Clic: preguntar por este objeto", 0.6, 0.85, 1)
        GameTooltip:AddLine("Ctrl + clic: ver en el probador", 0.6, 0.85, 1)
        GameTooltip:AddLine("Mayús + clic: enlazar en el chat", 0.6, 0.85, 1)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    btn:SetScript("OnClick", function(self)
        -- Shift: linkear en el chat (comportamiento previo, intacto).
        if IsShiftKeyDown() then
            local _, link = GetItemInfo(self.itemID)
            if link and ChatEdit_InsertLink then
                ChatEdit_InsertLink(link)
            else
                NC.SetStatus("El cliente aún no tiene ese objeto en caché.", true)
            end
            return
        end
        -- Ctrl: abrir el probador (dressing room). Necesita el objeto en caché.
        -- Envuelto en pcall para que un fallo nunca rompa el uso normal.
        if IsControlKeyDown() then
            local _, link = GetItemInfo(self.itemID)
            if link and DressUpItemLink then
                local ok = pcall(DressUpItemLink, link)
                if not ok then
                    NC.SetStatus("No se pudo abrir el probador.", true)
                end
            else
                NC.SetStatus("El cliente aún no tiene ese objeto en caché.", true)
            end
            return
        end
        -- Sin modificador: comprobar con el escáner (comportamiento normal).
        NC.Scanner:AskItem(self.itemID, self.fallbackName)
    end)

    itemPool[i] = btn
    return btn
end

------------------------------------------------------------
-- Construccion de la vista
------------------------------------------------------------
local function BuildView()
    if container then return end

    container = CreateFrame("Frame", nil, NC.Content)
    container:SetAllPoints()

    backBtn = CreateFrame("Button", nil, container, "UIPanelButtonTemplate")
    backBtn:SetWidth(90)
    backBtn:SetHeight(22)
    backBtn:SetPoint("TOPLEFT", 0, 0)
    backBtn:SetText("< Volver")
    backBtn:SetScript("OnClick", function() NC.Scanner:Back() end)

    breadcrumb = container:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    breadcrumb:SetPoint("LEFT", backBtn, "RIGHT", 10, 0)
    breadcrumb:SetJustifyH("LEFT")
    breadcrumb:SetTextColor(1, 0.82, 0)

    allBtn = CreateFrame("Button", nil, container, "UIPanelButtonTemplate")
    allBtn:SetWidth(130)
    allBtn:SetHeight(22)
    allBtn:SetPoint("TOPRIGHT", -26, 0)
    allBtn:SetText("Preguntar todo")
    allBtn:SetScript("OnClick", function()
        if NC.QueueSize() > 0 then
            local n = NC.ClearQueue()
            NC.SetStatus("Cola cancelada (" .. n .. " consultas descartadas).", true)
        else
            NC.Scanner:AskAll()
        end
    end)
    allBtn:Hide()

    -- refresco del boton y del aviso de cola
    local acc = 0
    container:SetScript("OnUpdate", function(self, elapsed)
        acc = acc + (elapsed or 0)
        if acc < 0.2 then return end
        acc = 0
        local pend, espera = NC.QueueInfo()
        if pend > 0 then
            allBtn:SetText("Cancelar (" .. pend .. ")")
            NC.SetStatus("Quedan " .. pend .. " consultas · siguiente en "
                .. string.format("%.0f", espera) .. " s", false, 2)
        else
            allBtn:SetText("Preguntar todo")
        end
    end)

    scroll, content = NC.CreateScroll(container)
    scroll:SetPoint("TOPLEFT", 0, -30)
    scroll:SetPoint("BOTTOMRIGHT", -26, 0)
    content:SetWidth(460)
end

------------------------------------------------------------
-- Vistas
------------------------------------------------------------
-- Nivel 1: elegir expansión
function NC.Scanner:ShowExpansions()
    self.view = "expansions"
    self.expac, self.raidsel, self.mode, self.boss = nil, nil, nil, nil
    HideAll()
    backBtn:Hide()
    allBtn:Hide()
    breadcrumb:ClearAllPoints()
    breadcrumb:SetPoint("TOPLEFT", container, "TOPLEFT", 2, -6)
    breadcrumb:SetText("Elige expansión")

    for i, expac in ipairs(NC.EXPANSIONS) do
        local btn = GetMenuButton(i)
        btn:SetWidth(450)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(i - 1) * 44)
        btn.icon:Hide()
        btn.label:SetTextColor(1, 1, 1)
        local nraids = table.getn(expac.raids)
        if nraids > 0 then
            btn:SetText(expac.label .. "   |cff888888(" .. nraids .. " bandas)|r")
            NC.SetButtonEnabled(btn, true)
            local idx = i
            btn:SetScript("OnClick", function() NC.Scanner:ShowRaids(idx) end)
        else
            btn:SetText("|cff777777" .. expac.label .. "   (próximamente)|r")
            NC.SetButtonEnabled(btn, false)
        end
        btn:Show()
    end

    content:SetHeight(table.getn(NC.EXPANSIONS) * 44 + 10)
    scroll:SetVerticalScroll(0)
end

-- Nivel 2: elegir banda dentro de la expansión
function NC.Scanner:ShowRaids(expacIdx)
    self.view, self.expac = "raids", expacIdx
    self.raidsel, self.mode, self.boss = nil, nil, nil
    HideAll()
    backBtn:Show()
    allBtn:Hide()
    breadcrumb:ClearAllPoints()
    breadcrumb:SetPoint("LEFT", backBtn, "RIGHT", 10, 0)

    local expac = NC.EXPANSIONS[expacIdx]
    if not expac then return self:ShowExpansions() end
    breadcrumb:SetText(expac.label)

    for i, raidDef in ipairs(expac.raids) do
        local btn = GetMenuButton(i)
        btn:SetWidth(450)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(i - 1) * 44)
        btn.icon:Hide()
        btn.label:SetTextColor(1, 1, 1)
        btn:SetText(raidDef.label)
        NC.SetButtonEnabled(btn, true)
        local rd = raidDef
        btn:SetScript("OnClick", function() NC.Scanner:ChooseRaid(rd) end)
        btn:Show()
    end

    content:SetHeight(table.getn(expac.raids) * 44 + 10)
    scroll:SetVerticalScroll(0)
end

-- Al elegir banda: si tiene una sola dificultad, salta directo a jefes;
-- si tiene varias, muestra el selector de dificultad.
function NC.Scanner:ChooseRaid(raidDef)
    self.raidsel = raidDef
    if table.getn(raidDef.diffs) == 1 then
        self:ShowBosses(raidDef.diffs[1].key)
    else
        self:ShowDiffs(raidDef)
    end
end

-- Nivel 3: elegir dificultad (solo si la banda tiene más de una)
function NC.Scanner:ShowDiffs(raidDef)
    self.view = "diffs"
    self.raidsel = raidDef
    self.mode, self.boss = nil, nil
    HideAll()
    backBtn:Show()
    allBtn:Hide()
    breadcrumb:ClearAllPoints()
    breadcrumb:SetPoint("LEFT", backBtn, "RIGHT", 10, 0)
    breadcrumb:SetText(raidDef.label)

    for i, diff in ipairs(raidDef.diffs) do
        local btn = GetMenuButton(i)
        local col = (i - 1) % 2
        local row = math.floor((i - 1) / 2)
        btn:SetWidth(220)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", content, "TOPLEFT", col * 230, -row * 46)
        btn.icon:Hide()
        btn.label:SetTextColor(1, 1, 1)
        btn:SetText(diff.label)
        NC.SetButtonEnabled(btn, true)
        local dk = diff.key
        btn:SetScript("OnClick", function() NC.Scanner:ShowBosses(dk) end)
        btn:Show()
    end

    content:SetHeight(math.ceil(table.getn(raidDef.diffs) / 2) * 46 + 10)
    scroll:SetVerticalScroll(0)
end

-- Compatibilidad: por si algo llama al nombre antiguo.
function NC.Scanner:ShowModes()
    self:ShowExpansions()
end

function NC.Scanner:ShowBosses(modeKey)
    self.view, self.mode, self.boss = "bosses", modeKey, nil
    HideAll()
    backBtn:Show()
    allBtn:Hide()

    -- Resolver a qué banda/expansión pertenece este modo, para que "Volver"
    -- funcione aunque se haya entrado directo (p. ej. al restaurar posición).
    if not self.raidsel or not self.expac then
        for ei, expac in ipairs(NC.EXPANSIONS) do
            for _, rd in ipairs(expac.raids) do
                for _, d in ipairs(rd.diffs) do
                    if d.key == modeKey then
                        self.expac = self.expac or ei
                        self.raidsel = self.raidsel or rd
                    end
                end
            end
        end
    end

    breadcrumb:ClearAllPoints()
    breadcrumb:SetPoint("LEFT", backBtn, "RIGHT", 10, 0)

    local mode
    for _, m in ipairs(NC.MODES) do
        if m.key == modeKey then mode = m end
    end
    if not mode then return self:ShowModes() end

    if NC.ModeHasFactions(modeKey) then
        local fac, manual = NC.GetFaction()
        breadcrumb:SetText(mode.label .. "   |cff888888botín de "
            .. NC.FactionLabel(fac) .. (manual and " (fijado)" or "") .. "|r")
    else
        breadcrumb:SetText(mode.label)
    end

    local todos = NC.BOSSES[mode.raid] or {}
    local data  = NC.GetModeLoot(modeKey)

    -- el cofre de homenaje solo existe en heroico: en normal ni se muestra
    local bosses = {}
    for _, b in ipairs(todos) do
        if NC.BossAvailable(b, modeKey) then
            table.insert(bosses, b)
        end
    end

    for i, boss in ipairs(bosses) do
        local btn = GetMenuButton(i)
        btn:SetWidth(450)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(i - 1) * 44)
        btn.icon:Hide()   -- iconos de jefe desactivados (solo texto)

        local list = data and data[boss.name]
        local count = list and table.getn(list) or 0
        btn.label:SetTextColor(1, 1, 1)
        if count > 0 then
            btn:SetText(boss.name .. "   |cff888888(" .. count .. ")|r")
            NC.SetButtonEnabled(btn, true)
        else
            btn:SetText("|cff777777" .. boss.name .. "   (sin datos)|r")
            NC.SetButtonEnabled(btn, false)
        end

        btn:SetScript("OnClick", function() NC.Scanner:ShowItems(modeKey, boss.name) end)
        btn:Show()
    end

    content:SetHeight(table.getn(bosses) * 44 + 10)
    scroll:SetVerticalScroll(0)
end

function NC.Scanner:ShowItems(modeKey, bossName)
    self.view, self.mode, self.boss = "items", modeKey, bossName
    HideAll()
    backBtn:Show()
    breadcrumb:ClearAllPoints()
    breadcrumb:SetPoint("LEFT", backBtn, "RIGHT", 10, 0)
    if NC.ModeHasFactions(modeKey) then
        local fac = NC.GetFaction()
        breadcrumb:SetText(modeKey .. "  >  " .. bossName
            .. "   |cff888888(" .. NC.FactionLabel(fac) .. ")|r")
    else
        breadcrumb:SetText(modeKey .. "  >  " .. bossName)
    end

    local list = NC.GetBossLoot(modeKey, bossName)
    if not list or table.getn(list) == 0 then
        allBtn:Hide()
        content:SetHeight(10)
        NC.SetStatus("No hay datos de botín para " .. bossName .. " en " .. modeKey .. ".", true)
        return
    end

    allBtn:Show()

    local size, pad, cols = CFG.IconSize, CFG.IconPad, CFG.IconCols
    for i, entry in ipairs(list) do
        local btn = GetItemButton(i)
        local col = (i - 1) % cols
        local row = math.floor((i - 1) / cols)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", content, "TOPLEFT", col * (size + pad), -row * (size + pad))
        btn.itemID = entry.id
        btn.fallbackName = entry.name
        btn.icon:SetTexture(NC.ItemIcon(entry.id))
        btn:Show()
        NC.Scanner:RefreshMark(btn)
    end

    content:SetHeight(math.ceil(table.getn(list) / cols) * (size + pad) + 10)
    scroll:SetVerticalScroll(0)
    NC.Scanner:UpdateProgress()
end

function NC.Scanner:Back()
    if self.view == "items" then
        -- de objetos: volver a jefes (misma dificultad)
        self:ShowBosses(self.mode)
    elseif self.view == "bosses" then
        -- de jefes: si la banda tenía varias dificultades, volver al selector
        -- de dificultad; si no, volver a la lista de bandas.
        if self.raidsel and table.getn(self.raidsel.diffs) > 1 then
            self:ShowDiffs(self.raidsel)
        elseif self.expac then
            self:ShowRaids(self.expac)
        else
            self:ShowExpansions()
        end
    elseif self.view == "diffs" then
        -- de dificultad: volver a la lista de bandas
        if self.expac then
            self:ShowRaids(self.expac)
        else
            self:ShowExpansions()
        end
    elseif self.view == "raids" then
        -- de bandas: volver a expansiones
        self:ShowExpansions()
    else
        self:ShowExpansions()
    end
end

------------------------------------------------------------
-- Marcas de resultado
------------------------------------------------------------
function NC.Scanner:RefreshMark(btn)
    local info  = CurrentResult(btn.itemID)
    local state = info and info.state
    if state and MARK[state] then
        btn.mark:SetTexture(MARK[state])
        btn.mark:Show()
        if state == "sold" then
            btn.border:SetVertexColor(1, 0.5, 0, 0.55)   -- naranja: vendido para recuperar
        elseif state == "yes" then
            btn.border:SetVertexColor(0, 1, 0, 0.35)
        elseif state == "no" then
            btn.border:SetVertexColor(1, 0, 0, 0.25)
        else
            btn.border:SetVertexColor(1, 0.8, 0, 0.25)
        end
    else
        btn.mark:Hide()
        btn.border:SetVertexColor(0, 0, 0, 0)
    end
end

function NC.Scanner:RefreshAllMarks()
    for _, btn in ipairs(itemPool) do
        if btn:IsShown() then self:RefreshMark(btn) end
    end
end

local function SetResult(player, itemID, state, place, count)
    if not player or not itemID then return end
    NC.Results[player] = NC.Results[player] or {}
    NC.Results[player][itemID] = {
        state = state,
        place = place,
        count = count,
        time  = GetTime(),
    }
    NC.Scanner:RefreshAllMarks()
    NC.Scanner:UpdateProgress()
end

------------------------------------------------------------
-- Envio de consultas
------------------------------------------------------------
function NC.Scanner:AskItem(itemID, fallbackName)
    local target, err = NC.GetValidTarget()
    if not target then
        NC.SetStatus(err, true)
        return
    end

    SetResult(target, itemID, "pending")

    NC.Send(".player iteminfo " .. itemID, function()
        NC.Scanner.awaiting = {
            id     = itemID,
            name   = fallbackName,
            target = target,
            time   = GetTime(),
        }
        NC.Scanner._itemQueryAt = GetTime()   -- para ocultar el error de "fuera de instancia"
    end)

    if NC.QueueSize() <= 1 then
        local name = NC.ItemName(itemID, fallbackName)
        NC.SetStatus("Preguntando por " .. name .. " a " .. target .. "...")
    end
end

function NC.Scanner:AskAll()
    if self.view ~= "items" or not self.mode or not self.boss then return end

    local target, err = NC.GetValidTarget()
    if not target then
        NC.SetStatus(err, true)
        return
    end

    local list = NC.GetBossLoot(self.mode, self.boss)
    if not list then return end

    for _, entry in ipairs(list) do
        self:AskItem(entry.id, entry.name)
    end

    local n    = table.getn(list)
    local segs = NC.EstimateTime(n)
    NC.SetStatus(n .. " consultas sobre " .. target .. ": tardará unos "
        .. math.ceil(segs / 60) .. " min (el servidor solo admite "
        .. CFG.RateMax .. " cada " .. CFG.RateWindow .. " s). Pulsa Cancelar para parar.", false, 10)
end

------------------------------------------------------------
-- Lectura de la respuesta del servidor
------------------------------------------------------------
function NC.Scanner:OnSystemMessage(msg)
    -- El volcado va antes de cualquier filtro: para depurar necesitamos ver
    -- TODO lo que manda el servidor, no solo lo que esperamos.
    if NC.diagChat then
        NC.Print("|cff888888[sys]|r " .. tostring(msg))
    end
    if NC._rateCapDebug then
        NC.Print("|cffffd100[xprate cap]|r " .. tostring(msg))
    end

    -- caduca la consulta en curso antes de nada, para no atribuir mal
    -- una respuesta tardia sin nombre de jugador
    if self.awaiting and (GetTime() - self.awaiting.time) > CFG.ResultTimeout then
        local a = self.awaiting
        self.awaiting = nil
        if NC.Eye and NC.Eye.Fail then NC.Eye:Fail("Sin respuesta de " .. (a.target or "objetivo") .. ".") end
        if NC.SetStatus then NC.SetStatus("Sin respuesta a la consulta de objeto.") end
    end

    -- El comando .player iteminfo solo funciona dentro de una instancia. Si el
    -- servidor lo rechaza, cancelamos la espera y avisamos (si no, el ojo se
    -- queda "Preguntando…" para siempre).
    if self.awaiting and NC.Normalize
       and string.find(NC.Normalize(msg), "fuera de una mazmorra o banda", 1, true) then
        self.awaiting = nil
        local aviso = "Solo funciona dentro de una mazmorra o banda."
        if NC.Eye and NC.Eye.Fail then NC.Eye:Fail(aviso) end
        if NC.SetStatus then NC.SetStatus(aviso) end
        return
    end

    -- Respuestas de .xprate: actualizan los botones de la pestaña Experiencia.
    local rates = NC.ParseXpRate(msg)
    if rates and NC.XpRates then
        NC.XpRates:OnServerRates(rates)
    end
    -- Registro en consola (punto único, sin duplicar con el filtro):
    -- las líneas de rates se registran como "ocultadas" si el silenciado está ON.
    if NC.IsXpRateLine and NC.IsXpRateLine(msg) and NC.Console then
        if NC.db and NC.db.silenceRates ~= false then
            NC.Console:LogHidden(msg)
        else
            NC.Console:LogReply(msg, "xprate")
        end
    end

    -- Eventos: si es una respuesta de evento y se oculta, se registra.
    if NC.IsEventLine and NC.IsEventLine(msg) and NC.Console then
        if NC.db and NC.db.silenceEvents ~= false then
            NC.Console:LogHidden(msg)
        end
    end

    local id, player, state, place, count = NC.ParseItemInfo(msg)
    if not id then return end

    if NC.Console then
        if NC.db and NC.db.silence then
            NC.Console:LogHidden(msg)
        else
            NC.Console:LogReply(msg, "iteminfo")
        end
    end

    -- El servidor incluye ID y jugador en la respuesta, asi que no dependemos
    -- del orden de la cola: cada linea se asocia sola a su objeto.
    if not player then
        player = self.awaiting and self.awaiting.target
    end
    if not player then return end

    SetResult(player, id, state, place, count)
    if NC.Eye then NC.Eye:OnResult(player, id, state, place, count) end
    if NC.Watch and NC.Watch.Refresh then NC.Watch:Refresh() end

    if self.awaiting and self.awaiting.id == id then
        self.awaiting = nil
    end
end

------------------------------------------------------------
-- Progreso del jefe actual
------------------------------------------------------------
function NC.Scanner:UpdateProgress()
    if not breadcrumb or self.view ~= "items" then return end

    local list = NC.GetBossLoot(self.mode, self.boss)
    if not list then return end

    local target = UnitExists("target") and UnitName("target") or nil
    local done, found = 0, 0
    if target and NC.Results[target] then
        for _, entry in ipairs(list) do
            local info = NC.Results[target][entry.id]
            if info and info.state ~= "pending" then
                done = done + 1
                if info.state == "yes" or info.state == "sold" then found = found + 1 end
            end
        end
    end

    local text = self.mode .. "  >  " .. self.boss
    if target then
        text = text .. "   |cff888888" .. target .. ": " .. done .. "/" .. table.getn(list)
        if found > 0 then
            text = text .. "  |cff55ff55" .. found .. " encontrado(s)|r"
        else
            text = text .. "|r"
        end
    end
    breadcrumb:SetText(text)
end

------------------------------------------------------------
-- Filtro opcional: oculta del chat las respuestas de .player iteminfo
------------------------------------------------------------
if ChatFrame_AddMessageEventFilter then
    -- Filtro para las respuestas de comandos. Los servidores privados responden
    -- a los comandos "." por distintos canales segun el comando, asi que
    -- interceptamos varios. Cada uno: oculta iteminfo silenciado y respuestas
    -- de eventos pedidas por el addon.
    local function commandFilter(self, event, msg)
        if NC.db and NC.db.silence and NC.ParseItemInfo(msg) then
            return true
        end
        -- Error "fuera de una mazmorra o banda": ocultarlo si es respuesta a una
        -- consulta de objeto reciente del addon (el addon ya lo avisa en el ojo).
        if NC.Normalize and NC.Scanner._itemQueryAt
           and (GetTime() - NC.Scanner._itemQueryAt) < 5
           and string.find(NC.Normalize(msg), "fuera de una mazmorra o banda", 1, true) then
            return true
        end
        -- Respuestas de rates (.xprate): oculta TODO el bloque si silenciado ON.
        -- NO registra aquí: el listener (OnSystemMessage) es el único punto de
        -- registro, para no duplicar (el filtro corre una vez por ventana).
        if NC.IsXpRateLine and NC.IsXpRateLine(msg) then
            if NC.db and NC.db.silenceRates ~= false then
                return true
            end
        end
        -- Respuestas de eventos.
        if NC.Events and NC.Events.OnSystemMessage then
            local recognized = NC.Events:OnSystemMessage(msg)
            if recognized and NC.db and NC.db.silenceEvents ~= false then
                return true
            end
        end
        -- Respuestas de .player info / .raid list / .raid info: se procesan
        -- (para pintarlas en la pestaña Información) y se ocultan del chat.
        if NC.Info and NC.Info.OnSystemMessage then
            if NC.Info:OnSystemMessage(msg) then
                return true
            end
        end
        return false
    end
    ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", commandFilter)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL", commandFilter)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", commandFilter)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_MONSTER_SAY", commandFilter)
    -- Las respuestas de .player info / .raid info de OTROS jugadores pueden
    -- llegar por canales de "susurro del servidor" en algunos cores. Los
    -- interceptamos también para no perderlas.
    ChatFrame_AddMessageEventFilter("CHAT_MSG_MONSTER_WHISPER", commandFilter)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", commandFilter)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_BOSS_WHISPER", commandFilter)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_MONSTER_YELL", commandFilter)
end

------------------------------------------------------------
-- Entrada / salida de la pestana
------------------------------------------------------------
function NC.ShowScannerView()
    BuildView()
    container:Show()

    local S = NC.Scanner
    if S.view == "items" and S.mode and S.boss then
        S:ShowItems(S.mode, S.boss)
    elseif S.view == "bosses" and S.mode then
        S:ShowBosses(S.mode)
    elseif S.view == "diffs" and S.raidsel then
        S:ShowDiffs(S.raidsel)
    elseif S.view == "raids" and S.expac then
        S:ShowRaids(S.expac)
    else
        S:ShowExpansions()
    end
end

function NC.HideScannerView()
    if container then container:Hide() end
end
