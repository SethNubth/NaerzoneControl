local ADDON, NC = ...

------------------------------------------------------------
-- Rastreador de PvP (por personaje, persistente en NaerControlCharDB.pvp).
-- Registra por día: honor ganado, muertes de honor (kills), BGs jugadas,
-- victorias y muertes propias en PvP. Guarda un historial de días anteriores.
--
-- Honor y kills se cuentan por DELTA de GetPVPSessionStats (solo incrementos),
-- así es robusto ante relogs y no depende del idioma del cliente.
------------------------------------------------------------

NC.PvP = NC.PvP or {}

local MAX_DAYS = 30

local function today()
    return date("%d-%m-%Y")
end

local function newDay()
    return { date = today(), honor = 0, kills = 0, bgs = 0, wins = 0, losses = 0 }
end

local function db()
    if not NaerControlCharDB then return nil end
    local p = NaerControlCharDB.pvp
    if not p then p = {}; NaerControlCharDB.pvp = p end
    p.days   = p.days   or {}
    p.today  = p.today  or newDay()
    p.totals = p.totals or { honor = 0, kills = 0, bgs = 0, wins = 0, losses = 0 }
    return p
end

-- Cierra el día si cambió la fecha: lo mete al frente del historial y abre uno nuevo.
local function rollover()
    local p = db(); if not p then return end
    if p.today.date ~= today() then
        local d = p.today
        if (d.honor or 0) > 0 or (d.kills or 0) > 0 or (d.bgs or 0) > 0 then
            table.insert(p.days, 1, d)
            while #p.days > MAX_DAYS do table.remove(p.days) end
        end
        p.today = newDay()
    end
end

local baseHK, baseHonor = 0, 0
local function syncBaseline()
    if GetPVPSessionStats then
        local hk, honor = GetPVPSessionStats()
        baseHK, baseHonor = hk or 0, honor or 0
    else
        baseHK, baseHonor = 0, 0
    end
end

-- Suma los incrementos de honor/kills desde la última medición.
local function pollStats()
    local p = db(); if not p then return end
    rollover()
    if not GetPVPSessionStats then return end
    local hk, honor = GetPVPSessionStats()
    hk = hk or 0; honor = honor or 0
    if hk > baseHK then
        local d = hk - baseHK
        p.today.kills  = (p.today.kills  or 0) + d
        p.totals.kills = (p.totals.kills or 0) + d
    end
    if honor > baseHonor then
        local d = honor - baseHonor
        p.today.honor  = (p.today.honor  or 0) + d
        p.totals.honor = (p.totals.honor or 0) + d
    end
    baseHK, baseHonor = hk, honor
end

-- Detección de fin de BG: cuando una cola que estaba "active" deja de estarlo.
local prevStatus = {}
local function onBFStatus()
    local p = db(); if not p then return end
    local maxq = math.max((GetMaxBattlefieldID and GetMaxBattlefieldID()) or 0, 2)
    for i = 1, maxq do
        local status = GetBattlefieldStatus(i)
        if prevStatus[i] == "active" and status ~= "active" then
            p.today.bgs  = (p.today.bgs  or 0) + 1
            p.totals.bgs = (p.totals.bgs or 0) + 1
            if GetBattlefieldWinner and UnitFactionGroup then
                local w = GetBattlefieldWinner()
                local fac = UnitFactionGroup("player")
                if w ~= nil and w >= 0 and fac then
                    local won = (w == 1 and fac == "Alliance") or (w == 0 and fac == "Horde")
                    if won then
                        p.today.wins  = (p.today.wins  or 0) + 1
                        p.totals.wins = (p.totals.wins or 0) + 1
                    else
                        p.today.losses  = (p.today.losses  or 0) + 1
                        p.totals.losses = (p.totals.losses or 0) + 1
                    end
                end
            end
        end
        prevStatus[i] = status
    end
end

local function onDeath_REMOVED() end

-- API para la vista
function NC.PvP.GetToday()  local p = db(); return p and p.today end
function NC.PvP.GetDays()   local p = db(); return (p and p.days) or {} end
function NC.PvP.GetTotals() local p = db(); return p and p.totals end
function NC.PvP.Clear()
    if not NaerControlCharDB then return end
    NaerControlCharDB.pvp = nil
    db()            -- recrea vacío
    syncBaseline()  -- rebasa el contador de sesión para no re-sumar lo ya jugado
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("CHAT_MSG_COMBAT_HONOR_GAIN")
f:RegisterEvent("UPDATE_BATTLEFIELD_STATUS")
f:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        db(); rollover(); syncBaseline()
    elseif event == "CHAT_MSG_COMBAT_HONOR_GAIN" then
        pollStats()
    elseif event == "UPDATE_BATTLEFIELD_STATUS" then
        onBFStatus()
    end
end)

-- Poll lento: recoge honor/kills aunque falte algún evento, y ejecuta rollover.
f.t = 0
f:SetScript("OnUpdate", function(self, e)
    self.t = self.t + (e or 0)
    if self.t < 30 then return end
    self.t = 0
    pollStats()
end)
