local ADDON, NC = ...

------------------------------------------------------------
-- Pestaña "Eventos": lista los eventos activos del servidor con sus fechas.
-- Muestra la caché al instante; refresca activelist al abrir (anti-spam) y
-- pide el detalle de cada evento bajo demanda al pulsarlo.
------------------------------------------------------------

local panel, scroll, content, statusFS
local rows = {}

-- Descripciones de eventos. Clave: nombre del evento (o parte, en minúsculas).
-- El servidor no envía descripción, así que las mantenemos aquí. Se busca por
-- coincidencia parcial en minúsculas, para tolerar variantes del nombre.
-- Rellenar con las descripciones reales de NAERZONE según se vayan conociendo.
local EVENT_DESC = {
    ["luna negra"]   = "Feria ambulante con premios, reputación y minijuegos.",
    ["darkmoon"]     = "Feria ambulante con premios, reputación y minijuegos.",
    ["fishing"]      = "Evento de pesca con recompensas especiales.",
    ["pesca"]        = "Evento de pesca con recompensas especiales.",
    ["arena"]        = "Torneo de arena con reglas o formato especial.",
    ["wrath"]        = "Evento PvP temporal.",
    ["tirion"]       = "Evento de guion: discurso de Tirion (RP/servidor).",
}

-- Busca una descripción para un evento por su nombre (coincidencia parcial).
local function DescFor(name)
    if type(name) ~= "string" then return nil end
    local low = strlower(name)
    for key, desc in pairs(EVENT_DESC) do
        if string.find(low, key, 1, true) then return desc end
    end
    return nil
end

-- Color del tiempo restante según urgencia. Devuelve el código de color.
local function UrgencyColor(sec)
    if not sec then return "cff888888" end       -- gris (desconocido)
    if sec < -3600 then return "cff888888" end    -- gris: fecha ya pasada (recurrente)
    if sec < 0 then return "cffff4444" end        -- rojo: terminando ahora
    if sec < 3 * 3600 then return "cffff4444" end -- rojo: <3h
    if sec < 86400 then return "cffff8800" end    -- naranja: <1 día
    if sec < 3 * 86400 then return "cffffd100" end-- amarillo: <3 días
    return "cff4fdf4f"                            -- verde: holgado
end

local function FmtRemain(sec)
    if not sec then return nil end
    -- fecha ya pasada hace más de una hora: es un recurrente con la fecha del
    -- ciclo anterior; no alarmamos con "terminando".
    if sec < -3600 then return "en curso" end
    if sec < 0 then return "terminando" end
    if sec >= 86400 then
        return string.format("%dd %dh", math.floor(sec / 86400), math.floor((sec % 86400) / 3600))
    elseif sec >= 3600 then
        return string.format("%dh %dm", math.floor(sec / 3600), math.floor((sec % 3600) / 60))
    end
    return string.format("%dm", math.floor(sec / 60))
end

local function BuildPanel()
    if panel then return end
    panel = CreateFrame("Frame", nil, NC.Content)
    panel:SetAllPoints(NC.Content)

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 6, -6)
    title:SetText("|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. "Eventos activos|r")

    statusFS = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    statusFS:SetPoint("TOPLEFT", 8, -32)
    statusFS:SetTextColor(0.6, 0.6, 0.65)

    scroll, content = NC.CreateScroll(panel)
    scroll:SetPoint("TOPLEFT", 4, -52)
    scroll:SetPoint("BOTTOMRIGHT", -26, 8)
    content:SetWidth(560)
end

-- Alturas del acordeón: colapsada (tarjeta normal) y contenido extra al abrir.
local COLLAPSED_H = 80    -- altura de la tarjeta cerrada
local EXPAND_H    = 88    -- alto extra de la zona expandida (3 líneas + margen)
local CARD_GAP    = 8     -- separación entre tarjetas
local IMG_W, IMG_H = 200, 112   -- hueco de imagen (16:9 aprox)

local function GetRow(i)
    if rows[i] then return rows[i] end
    local r = CreateFrame("Button", nil, content)
    -- La posición y la altura se fijan en RefreshList (layout acumulativo,
    -- porque las tarjetas expandidas cambian de alto).
    r:SetHeight(COLLAPSED_H)

    -- Fondo de tarjeta con borde sutil
    r:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets   = { left = 0, right = 0, top = 0, bottom = 0 },
    })
    r:SetBackdropColor(0.10, 0.12, 0.16, 0.85)
    r:SetBackdropBorderColor(0.25, 0.30, 0.40, 0.8)

    -- Franja de color a la izquierda (urgencia). Se recolorea por evento.
    r.stripe = r:CreateTexture(nil, "ARTWORK")
    r.stripe:SetTexture("Interface\\Buttons\\WHITE8X8")
    r.stripe:SetPoint("TOPLEFT", 0, 0)
    r.stripe:SetPoint("BOTTOMLEFT", 0, 0)
    r.stripe:SetWidth(3)

    -- Resaltado al pasar el ratón
    local hl = r:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetTexture("Interface\\Buttons\\WHITE8X8")
    hl:SetVertexColor(0.4, 0.6, 0.9, 0.10)

    -- Nombre (arriba, izquierda). Una sola línea para no invadir la descripción;
    -- si es muy largo, la fuente lo recorta en su ancho.
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    r.name:SetPoint("TOPLEFT", 12, -9)
    r.name:SetPoint("RIGHT", r, "RIGHT", -80, 0)  -- deja hueco para el badge
    r.name:SetJustifyH("LEFT")
    r.name:SetHeight(20)
    if r.name.SetMaxLines then r.name:SetMaxLines(1) end
    r.name:SetWordWrap(false)

    -- Badge de estado (arriba, derecha): fondo + texto
    r.badge = CreateFrame("Frame", nil, r)
    r.badge:SetSize(58, 18)
    r.badge:SetPoint("TOPRIGHT", -10, -8)
    r.badge:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
    })
    r.badgeText = r.badge:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.badgeText:SetPoint("CENTER")

    -- Descripción (bajo el nombre)
    r.desc = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.desc:SetPoint("TOPLEFT", 12, -34)
    r.desc:SetWidth(520); r.desc:SetJustifyH("LEFT")
    r.desc:SetWordWrap(false)
    r.desc:SetTextColor(0.70, 0.72, 0.78)

    -- Línea de fechas (abajo)
    r.dates = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.dates:SetPoint("BOTTOMLEFT", 12, 10)
    r.dates:SetWidth(400); r.dates:SetJustifyH("LEFT")

    -- Tiempo restante destacado (abajo, derecha)
    r.remain = r:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    r.remain:SetPoint("BOTTOMRIGHT", -12, 9)

    -- ---- Zona expandida (oculta por defecto) ----
    -- Se muestra al pulsar la tarjeta: info completa y hueco para imagen futura.
    r.exp = CreateFrame("Frame", nil, r)
    r.exp:SetPoint("TOPLEFT", r, "TOPLEFT", 12, -COLLAPSED_H + 6)
    r.exp:SetPoint("RIGHT", r, "RIGHT", -12, 0)
    r.exp:Hide()

    -- separador superior de la zona expandida
    r.expSep = r.exp:CreateTexture(nil, "ARTWORK")
    r.expSep:SetTexture("Interface\\Buttons\\WHITE8X8")
    r.expSep:SetVertexColor(0.3, 0.35, 0.45, 0.5)
    r.expSep:SetPoint("TOPLEFT", 0, 0)
    r.expSep:SetPoint("TOPRIGHT", 0, 0)
    r.expSep:SetHeight(1)

    -- hueco reservado para imagen (a la derecha de la info)
    r.expImg = r.exp:CreateTexture(nil, "ARTWORK")
    r.expImg:SetPoint("TOPRIGHT", 0, -10)
    r.expImg:SetSize(IMG_W, IMG_H)
    r.expImg:Hide()   -- se mostrará cuando haya imagen

    -- texto de info completa (fechas de inicio/fin, ocurrencia, duración)
    r.expInfo = r.exp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.expInfo:SetPoint("TOPLEFT", 0, -10)
    r.expInfo:SetWidth(360); r.expInfo:SetJustifyH("LEFT")
    r.expInfo:SetSpacing(4)
    r.expInfo:SetTextColor(0.8, 0.82, 0.88)

    rows[i] = r
    return r
end

-- Id del evento actualmente expandido (acordeón: solo uno a la vez). nil = ninguno.
local expandedId = nil

-- Construye la info de la zona expandida. Muestra SOLO lo que no aparece ya
-- en la tarjeta cerrada (descripción y "termina el" ya se ven arriba): cuándo
-- empezó, cada cuánto se repite y cuánto dura.
local function BuildExpandedInfo(ev)
    local lines = {}
    if ev.startD then
        local d = NC.Events:LongDate(ev.startD)
        if d then table.insert(lines, "|cff888888Empieza:|r  |cffffffff" .. d .. "|r") end
    end
    if ev.occurrence then
        table.insert(lines, "|cff888888Cada:|r  |cffffffff" .. ev.occurrence .. " días|r")
    end
    if ev.length then
        table.insert(lines, "|cff888888Dura:|r  |cffffffff" .. ev.length .. " días|r")
    end
    if not ev.active and ev.nextChange then
        local d = NC.Events:LongDate(ev.nextChange)
        if d then table.insert(lines, "|cff888888Próxima aparición:|r  |cffffffff" .. d .. "|r") end
    end
    if table.getn(lines) == 0 then
        table.insert(lines, "|cff707070Pidiendo detalles al servidor…|r")
    end
    return table.concat(lines, "\n")
end

-- Estado de "actualizando" (ya no hay botón; la lista se pide sola al servidor).
local requesting = false
local requestAt  = 0
local function DoRequest()
    if NC.Events and NC.Events:RequestList(false) then
        requesting = true
        requestAt  = GetTime()
    end
end

-- Actualiza SOLO el tiempo restante de las tarjetas visibles (cada segundo),
-- sin re-ordenar ni re-maquetar (eso lo hace RefreshList cada pocos segundos).
local function TickRemains()
    for _, r in ipairs(rows) do
        if r:IsShown() and r._ev and not r._perm and not r._exp then
            local sec = NC.Events:SecondsToChange(r._ev)
            local rem = FmtRemain(sec)
            r.remain:SetText(rem and ("|" .. UrgencyColor(sec) .. rem .. "|r") or "")
        end
    end
end

-- Cabecera "Pasados" que separa activos de caducados (se crea una vez).
local function GetPastHeader()
    if not content.pastHdr then
        local h = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        h:SetText("|cff707070— Pasados —|r")
        content.pastHdr = h
    end
    return content.pastHdr
end

local function RefreshList()
    if not NC.Events then return end
    local activos, pasados = NC.Events:FullList()

    -- Orden por urgencia: lo que termina antes, arriba; lo que no tiene fecha
    -- de fin ("sin fin"), al final del bloque de activos.
    table.sort(activos, function(a, b)
        local pa, pb = NC.Events:IsPermanent(a), NC.Events:IsPermanent(b)
        if pa ~= pb then return not pa end
        local sa, sb = NC.Events:SecondsToChange(a), NC.Events:SecondsToChange(b)
        if not sa and not sb then return (a.id or 0) < (b.id or 0) end
        if not sa then return false end
        if not sb then return true end
        return sa < sb
    end)

    for _, r in ipairs(rows) do r:Hide() end

    -- si ha pasado el margen sin respuesta, se cierra el estado "actualizando"
    if requesting and (GetTime() - requestAt) > 6 then requesting = false end

    if table.getn(activos) == 0 and table.getn(pasados) == 0 then
        statusFS:SetText(requesting and "Actualizando…" or "Sin datos todavía; se piden solos en unos segundos.")
        if content.pastHdr then content.pastHdr:Hide() end
        return
    end
    local txt = "|cff" .. ((NC.ThemeHex and NC.ThemeHex("accent")) or "7ec8e3") .. table.getn(activos) .. "|r eventos activos"
    if table.getn(pasados) > 0 then
        txt = txt .. "   |cff707070·  " .. table.getn(pasados) .. " pasados|r"
    end
    if requesting then txt = txt .. "   |cffffd100· actualizando…|r" end
    statusFS:SetText(txt)

    -- lista combinada: activos primero, luego caducados (marcados)
    local events = {}
    for _, e in ipairs(activos) do table.insert(events, e) end
    for _, e in ipairs(pasados) do table.insert(events, e) end

    local yOffset = 0
    local pastShown = false
    for i, ev in ipairs(events) do
        local expired = not ev.active
        local r = GetRow(i)
        local permanent = NC.Events:IsPermanent(ev)
        local sec = (not permanent) and NC.Events:SecondsToChange(ev) or nil
        local isExpanded = (expandedId == ev.id)
        r._ev, r._perm, r._exp = ev, permanent, expired
        local modern = NC.Theme and NC.Theme.name == "modern"
        local ac = (NC.Theme and NC.Theme.accent) or { 0.49, 0.78, 0.89 }

        -- Separador "Pasados" al empezar el bloque de caducados
        if expired and not pastShown then
            pastShown = true
            local hdr = GetPastHeader()
            hdr:ClearAllPoints()
            hdr:SetPoint("TOPLEFT", content, "TOPLEFT", 6, -yOffset - 2)
            hdr:Show()
            yOffset = yOffset + 22
        end

        -- Nombre
        r.name:SetText(tostring(ev.name or ("Evento " .. ev.id)))
        if expired then
            r.name:SetTextColor(0.55, 0.55, 0.58)   -- atenuado
        elseif modern then
            r.name:SetTextColor(ac[1], ac[2], ac[3])   -- azul (acento) en Moderno
        else
            r.name:SetTextColor(1, 0.9, 0.5)
        end

        -- Fondo: apagado si es un evento pasado
        if expired then
            r:SetBackdropColor(0.08, 0.08, 0.10, 0.75)
            r:SetBackdropBorderColor(0.20, 0.20, 0.24, 0.7)
        else
            r:SetBackdropColor(0.10, 0.12, 0.16, 0.85)
            r:SetBackdropBorderColor(0.25, 0.30, 0.40, 0.8)
        end

        -- Descripción (de la tabla); si no hay, se oculta la línea.
        local desc = DescFor(ev.name)
        if desc then
            r.desc:SetText(desc); r.desc:Show()
        else
            r.desc:Hide()
        end

        -- Badge de estado y franja de urgencia
        if expired then
            r.badgeText:SetText("pasado")
            r.badgeText:SetTextColor(0.6, 0.6, 0.62)
            r.badge:SetBackdropColor(0.15, 0.15, 0.17, 0.9)
            r.badge:SetBackdropBorderColor(0.4, 0.4, 0.45, 0.7)
            r.stripe:SetVertexColor(0.4, 0.4, 0.45, 0.8)
        elseif permanent then
            r.badgeText:SetText("activo")
            if modern then
                r.badgeText:SetTextColor(ac[1], ac[2], ac[3])
                r.badge:SetBackdropColor(ac[1] * 0.22, ac[2] * 0.28, ac[3] * 0.34, 0.9)
                r.badge:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.85)
                r.stripe:SetVertexColor(ac[1], ac[2], ac[3], 0.95)
            else
                r.badgeText:SetTextColor(0.6, 1, 0.6)
                r.badge:SetBackdropColor(0.12, 0.28, 0.14, 0.9)
                r.badge:SetBackdropBorderColor(0.35, 0.75, 0.4, 0.8)
                r.stripe:SetVertexColor(0.31, 0.87, 0.31, 0.9)
            end
        else
            r.badgeText:SetText("activo")
            if modern then
                r.badgeText:SetTextColor(ac[1], ac[2], ac[3])
                r.badge:SetBackdropColor(ac[1] * 0.22, ac[2] * 0.28, ac[3] * 0.34, 0.9)
                r.badge:SetBackdropBorderColor(ac[1], ac[2], ac[3], 0.85)
            else
                r.badgeText:SetTextColor(0.6, 1, 0.6)
                r.badge:SetBackdropColor(0.12, 0.28, 0.14, 0.9)
                r.badge:SetBackdropBorderColor(0.35, 0.75, 0.4, 0.8)
            end
            local col = UrgencyColor(sec)
            if col == "cff888888" then r.stripe:SetVertexColor(0.5, 0.5, 0.5, 0.9)
            elseif col == "cffff4444" then r.stripe:SetVertexColor(1, 0.27, 0.27, 0.9)
            elseif col == "cffff8800" then r.stripe:SetVertexColor(1, 0.53, 0, 0.9)
            elseif col == "cffffd100" then r.stripe:SetVertexColor(1, 0.82, 0, 0.9)
            else r.stripe:SetVertexColor(0.31, 0.87, 0.31, 0.9) end
        end

        -- Fechas destacadas + tiempo restante
        if expired then
            -- evento pasado: mostrar cuándo se vio activo por última vez
            local fecha = ev.nextChange and NC.Events:LongDate(ev.nextChange)
            if fecha then
                r.dates:SetText("|cff707070Última fecha: " .. fecha .. "|r")
            else
                r.dates:SetText("|cff707070Ya no está activo|r")
            end
            r.remain:SetText("|cff707070caducado|r")
        elseif permanent then
            r.dates:SetText("|cff9fd98fSin fecha de fin|r")
            r.remain:SetText("")
        elseif ev.nextChange then
            local epoch = NC.Events:EffectiveChange(ev)
            if epoch and epoch > time() then
                local fecha = NC.Events:LongDateEpoch(epoch)
                r.dates:SetText(fecha and ("Termina el |cffffffff" .. fecha .. "|r") or "")
                local rem = FmtRemain(sec)
                r.remain:SetText(rem and ("|" .. UrgencyColor(sec) .. rem .. "|r") or "")
            else
                -- fecha ya pasada y sin recurrencia para avanzar: en curso
                r.dates:SetText("|cff9fd98fEn curso|r")
                r.remain:SetText("")
            end
        else
            r.dates:SetText("|cff888888Pulsa para ver las fechas|r")
            r.remain:SetText("")
        end

        -- Layout acumulativo: colocar la tarjeta bajo la anterior
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -yOffset)
        r:SetPoint("TOPRIGHT", content, "TOPRIGHT", 0, -yOffset)

        -- Altura según esté expandida o no
        local h = COLLAPSED_H
        if isExpanded then
            r.expInfo:SetText(BuildExpandedInfo(ev))
            r.exp:Show()
            -- la stripe se estira a toda la tarjeta expandida (ya está anclada
            -- TOP/BOTTOM, así que se ajusta sola al cambiar la altura)
            h = COLLAPSED_H + EXPAND_H
        else
            r.exp:Hide()
        end
        r:SetHeight(h)
        yOffset = yOffset + h + CARD_GAP

        -- Interacción: clic expande/colapsa (acordeón)
        r._id = ev.id
        r:SetScript("OnClick", function(self)
            if expandedId == self._id then
                expandedId = nil          -- clic en la abierta: cerrar
            else
                expandedId = self._id      -- abrir esta, cerrar el resto
                if NC.Events then NC.Events:RequestInfo(self._id) end
            end
            RefreshList()
        end)
        r:Show()
    end
    if not pastShown and content.pastHdr then content.pastHdr:Hide() end
    content:SetHeight(math.max(COLLAPSED_H, yOffset))
end

-- callback que el modulo de eventos llama cuando cambian los datos
function NC.Events_OnChanged()
    requesting = false
    if panel and panel:IsShown() then RefreshList() end
end

function NC.ShowEventsView()
    BuildPanel()
    -- conecta el callback de refresco
    if NC.Events then NC.Events.OnChanged = NC.Events_OnChanged end
    RefreshList()
    panel:Show()

    -- pide la lista al abrir (con anti-spam interno) y muestra "actualizando…"
    DoRequest()
    RefreshList()

    if not panel._ticking then
        panel._ticking = true
        panel:SetScript("OnUpdate", function(self, elapsed)
            if not self:IsShown() then return end
            self._sec  = (self._sec or 0) + (elapsed or 0)
            self._full = (self._full or 0) + (elapsed or 0)
            if self._sec >= 1 then
                self._sec = 0
                pcall(TickRemains)      -- cuenta atrás en vivo (ligero)
            end
            if self._full >= 15 then
                self._full = 0
                pcall(function() DoRequest(); RefreshList() end)
            end
        end)
    end
end

function NC.HideEventsView()
    if panel then panel:Hide() end
end
