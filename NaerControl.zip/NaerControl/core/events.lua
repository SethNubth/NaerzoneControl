local ADDON, NC = ...

------------------------------------------------------------
-- Eventos del servidor.
--
-- Tabla en memoria GLOBAL (NaerControlDB.events) con los eventos activos y
-- sus fechas (de .event info). Al abrir la pestaña se muestra la caché al
-- instante; en segundo plano se refresca activelist (1 envío, con anti-spam)
-- y el detalle de cada evento se pide bajo demanda al pulsarlo.
--
-- Las respuestas que PIDE el addon se ocultan del chat para no molestar; las
-- que el jugador escribe a mano se ven normales.
------------------------------------------------------------

NC.Events = {}

local LIST_COOLDOWN = 30   -- no repetir activelist si se hizo hace <30s

local function Store()
    NaerControlDB.events = NaerControlDB.events or { list = {}, updated = 0 }
    return NaerControlDB.events
end

-- Marca que esperamos ocultar la próxima respuesta de este tipo.
-- pending.list / pending.info[id] = true cuando el addon lo pidió.
NC.Events.pending = { info = {} }

------------------------------------------------------------
-- Consultas
------------------------------------------------------------

-- Pide la lista de eventos activos (con anti-spam). silentHide = ocultar la
-- respuesta del chat.
function NC.Events:RequestList(force)
    local st = Store()
    local haveData = next(st.list) ~= nil
    -- si no tenemos ningún dato, forzamos aunque el cooldown lo impediría
    if not force and haveData and (time() - (st.updated or 0)) < LIST_COOLDOWN then
        return false
    end
    if NC.QueueSize and NC.QueueSize() > 0 then
        return false   -- hay cola, reintentará al reabrir
    end
    self.pending.list = true
    self._listSentAt = time()
    self._sweepPending = true   -- tras esta ronda, barrer los caducados
    NC.Send(".event activelist")
    return true
end

-- Barrido de caducados: los eventos que estaban activos pero NO han aparecido
-- en la última ronda de activelist (su "seen" es anterior a la petición) han
-- dejado de estar activos. Los marcamos inactivos y anotamos cuándo caducaron.
-- Se llama de forma diferida tras recibir la lista (ver el watchdog en tab_events).
function NC.Events:SweepExpired()
    if not self._sweepPending or not self._listSentAt then return end
    self._sweepPending = false
    local st = Store()
    local changed = false
    for id, ev in pairs(st.list) do
        if ev.active and (ev.seen or 0) < self._listSentAt then
            ev.active = false
            ev.expiredAt = time()
            changed = true
        end
    end
    if changed and NC.Events.OnChanged then NC.Events.OnChanged() end
end

-- Pide el detalle de un evento (solo si no está cacheado o está viejo).
function NC.Events:RequestInfo(id)
    local st = Store()
    local ev = st.list[id]
    if ev and ev.startD then return false end   -- ya tenemos sus fechas
    if NC.QueueSize and NC.QueueSize() > 0 then return false end
    self.pending.info[id] = true
    NC.Send(".event info " .. id)
    return true
end

------------------------------------------------------------
-- Recepción de respuestas del servidor
------------------------------------------------------------

-- Devuelve true si el mensaje era una respuesta de eventos que pedimos
-- (y por tanto debe ocultarse del chat).
function NC.Events:OnSystemMessage(msg)
    local st = Store()

    -- ¿línea de activelist? El formato "N - [Nombre] [active]" es muy
    -- específico. Capturamos los datos y devolvemos true (reconocido) para
    -- que el filtro decida si ocultar según la opción de silenciado.
    local id, name, active = NC.ParseEventListLine(msg)
    if id then
        st.list[id] = st.list[id] or {}
        st.list[id].id = id
        st.list[id].name = name
        st.list[id].active = active
        st.list[id].seen = time()
        st.list[id].expiredAt = nil   -- vuelve a estar activo: limpiar caducidad
        st.updated = time()
        -- reprogramar el barrido: 2s tras la última línea recibida, asumimos
        -- que la lista ha terminado de llegar y barremos los caducados.
        self._sweepAt = GetTime() + 2
        if NC.Events.OnChanged then NC.Events.OnChanged() end
        return true   -- reconocido
    end

    -- ¿respuesta de .event info?
    local info = NC.ParseEventInfo(msg)
    if info then
        if info.kind == "header" then
            self._infoId = info.id
            st.list[info.id] = st.list[info.id] or {}
            st.list[info.id].id = info.id
            st.list[info.id].name = info.name
            st.list[info.id].active = info.active
        elseif info.kind == "dates" and self._infoId then
            local ev = st.list[self._infoId]
            if ev then
                ev.startD = info.startD; ev.endD = info.endD
                ev.occurrence = info.occurrence; ev.length = info.length
            end
        elseif info.kind == "next" and self._infoId then
            local ev = st.list[self._infoId]
            if ev then ev.nextChange = info.nextChange end
            self._infoId = nil
        end
        st.updated = time()
        if NC.Events.OnChanged then NC.Events.OnChanged() end
        return true   -- reconocido
    end

    return false
end

------------------------------------------------------------
-- Datos para la vista
------------------------------------------------------------

-- Lista de eventos activos, ordenada por id.
function NC.Events:ActiveList()
    local st = Store()
    local out = {}
    for id, ev in pairs(st.list) do
        if ev.active then table.insert(out, ev) end
    end
    table.sort(out, function(a, b) return (a.id or 0) < (b.id or 0) end)
    return out
end

-- Epoch del próximo cambio de estado. Para eventos recurrentes cuyo
-- "Next state change" quedó en el pasado (el servidor da la fecha del ciclo
-- anterior), avanza en múltiplos de 'occurrence' días hasta la próxima fecha
-- futura. Así no se muestran fechas de fin ya pasadas.
function NC.Events:EffectiveChange(ev)
    if not ev or not ev.nextChange then return nil end
    local epoch = NC.EventDateToEpoch(ev.nextChange)
    if not epoch then return nil end
    local now = time()
    if epoch < now and ev.occurrence and ev.occurrence > 0 and ev.occurrence < 1000 then
        local period = ev.occurrence * 86400
        local n = math.ceil((now - epoch) / period)
        epoch = epoch + n * period
    end
    return epoch
end

-- Para un evento activo, "Next state change" es cuándo TERMINA; para uno
-- inactivo, cuándo EMPIEZA. Devuelve segundos restantes o nil.
function NC.Events:SecondsToChange(ev)
    local epoch = self:EffectiveChange(ev)
    if not epoch then return nil end
    return epoch - time()
end

-- ¿Es un evento permanente (sin fin)? El servidor los marca con valores
-- especiales: recurrencia/duración enormes o sin cambio de estado próximo.
function NC.Events:IsPermanent(ev)
    if not ev then return false end
    if not ev.nextChange then return true end
    -- valores absurdamente grandes = "sin fin" (Arena Season, sistemas...)
    if ev.occurrence and ev.occurrence >= 1000 then return true end
    if ev.length and ev.length >= 365 then return true end
    return false
end

local MESES = {
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
}

-- Fecha larga en español: "25 de agosto de 2026". Recibe "2026-08-25_..."
function NC.Events:LongDate(dateStr)
    if type(dateStr) ~= "string" then return nil end
    local y, mo, d = string.match(dateStr, "(%d+)%-(%d+)%-(%d+)")
    if not y then return nil end
    local mes = MESES[tonumber(mo)] or ("mes " .. mo)
    return string.format("%d de %s de %d", tonumber(d), mes, tonumber(y))
end

-- Igual que LongDate pero desde un epoch (para fechas ya recalculadas).
function NC.Events:LongDateEpoch(epoch)
    if not epoch then return nil end
    local t = date("*t", epoch)
    local mes = MESES[t.month] or ("mes " .. t.month)
    return string.format("%d de %s de %d", t.day, mes, t.year)
end

-- Cuántos eventos hay en caché.
function NC.Events:Count()
    return table.getn(self:ActiveList())
end

-- ------------------------------------------------------------------
-- Watchdog del barrido de caducados. Cuando _sweepAt está fijado (tras
-- recibir líneas de activelist), espera a que pase ese instante y ejecuta
-- el barrido una sola vez. Así detectamos los eventos que ya no aparecen.
-- ------------------------------------------------------------------
local sweepWatch = CreateFrame("Frame")
sweepWatch:SetScript("OnUpdate", function(self, elapsed)
    local ev = NC.Events
    if ev and ev._sweepAt and GetTime() >= ev._sweepAt then
        ev._sweepAt = nil
        ev:SweepExpired()
    end
end)

-- Lista completa para la UI: activos primero (por id), luego caducados al
-- final (por fecha de caducidad, el más reciente arriba dentro de los pasados).
function NC.Events:FullList()
    local st = Store()
    local activos, pasados = {}, {}
    for id, e in pairs(st.list) do
        if e.active then table.insert(activos, e)
        else table.insert(pasados, e) end
    end
    table.sort(activos, function(a, b) return (a.id or 0) < (b.id or 0) end)
    table.sort(pasados, function(a, b) return (a.expiredAt or 0) > (b.expiredAt or 0) end)
    return activos, pasados
end
