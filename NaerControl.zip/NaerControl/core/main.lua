local ADDON, NC = ...

local COL = NC.COL

------------------------------------------------------------
-- Base de datos
------------------------------------------------------------
local function InitDB()
    NaerControlDB     = NaerControlDB     or {}
    NaerControlCharDB = NaerControlCharDB or {}

    for k, v in pairs(NC.DEFAULTS) do
        if NaerControlDB[k] == nil then
            NaerControlDB[k] = v
        end
    end

    NaerControlDB.diagChat = nil   -- ajuste retirado: era persistente por error

    -- Al actualizar a la version con el ojo por defecto, lo mostramos una
    -- vez aunque una sesion anterior lo hubiera ocultado. A partir de ahi
    -- se respeta lo que decida el usuario con /nc ojo.
    if not NaerControlDB.eyeDefaultApplied then
        NaerControlDB.eyeDefaultApplied = true
        NaerControlDB.eyeShown = true
    end

    -- El envio por defecto pasa a SAY (confirmado en NAERZONE). Se aplica
    -- una sola vez; despues respeta /nc modo.
    if not NaerControlDB.sayDefaultApplied then
        NaerControlDB.sayDefaultApplied = true
        NaerControlDB.sendMode = "SAY"
        NaerControlDB.warnedSend = nil
    end
    -- Versionado de SavedVariables: sella la versión y deja sitio para
    -- migraciones si cambia la estructura entre versiones.
    local dbv = NaerControlDB.version or 0
    if dbv < (NC.DB_VERSION or 1) then
        -- (futuras migraciones entre versiones irían aquí)
        NaerControlDB.version = NC.DB_VERSION or 1
    end

    NC.db  = NaerControlDB
    NC.cdb = NaerControlCharDB
end

------------------------------------------------------------
-- Modo de envio
------------------------------------------------------------
function NC.SetSendMode(mode)
    mode = string.upper(mode or "")
    if mode ~= "SAY" and mode ~= "WHISPER" then return false end
    NC.db.sendMode = mode
    if mode == "SAY" then
        NC.Print("Modo de envío: " .. COL.warn .. "decir (/say)" .. COL.r
            .. ". Si el comando no existe en el servidor, se verá en voz alta.")
    else
        NC.Print("Modo de envío: " .. COL.ok .. "susurro a ti mismo" .. COL.r .. ".")
    end
    return true
end

function NC.ToggleSendMode()
    NC.SetSendMode(NC.db.sendMode == "SAY" and "WHISPER" or "SAY")
end

------------------------------------------------------------
-- Diagnostico
------------------------------------------------------------
local function Diag(arg)
    if arg == "chat" then
        NC.diagChat = not NC.diagChat
        NC.Print("Volcado de mensajes del sistema: "
            .. (NC.diagChat and (COL.ok .. "activado") or (COL.soft .. "desactivado")) .. COL.r
            .. " (no se guarda: siempre arranca apagado)")
        return
    end

    NC.Print("--- diagnóstico ---")
    NC.Print("Versión: " .. NC.VERSION .. "  |  Envío: " .. NC.db.sendMode
        .. "  |  Skin: " .. NC.db.skin)
    local pend, espera = NC.QueueInfo()
    NC.Print("Cola: " .. pend .. " pendientes · siguiente en " .. string.format("%.1f", espera) .. " s")
    local fac, manual = NC.GetFaction()
    NC.Print("Facción para el Coliseo: " .. NC.FactionLabel(fac)
        .. (manual and " (fijada)" or " (detectada)"))
    NC.Print("Límite del servidor: " .. NC.CFG.RateMax .. " consultas cada " .. NC.CFG.RateWindow .. " s")
    NC.Print("Volcado de sistema (/nc diag chat): " .. tostring(NC.diagChat or false))
    NC.Print("Respuestas ocultas del chat (/nc silencio): " .. tostring(NC.db.silence))
    local prueba = "Objeto encontrado en inventario/banco: ID 50457, Cantidad 1, Jugador: Odnel"
    local pid, pjug, pest = NC.ParseItemInfo(prueba)
    NC.Print("Analizador de respuestas: " .. (pid and (COL.ok .. "correcto") or (COL.warn .. "FALLA")) .. COL.r
        .. " (id=" .. tostring(pid) .. ", jugador=" .. tostring(pjug) .. ", estado=" .. tostring(pest) .. ")")

    local problems = NC.CheckData()
    if table.getn(problems) == 0 then
        NC.Print(COL.ok .. "data.lua: sin incidencias." .. COL.r)
    else
        NC.Print(COL.warn .. "data.lua: " .. table.getn(problems) .. " incidencia(s)" .. COL.r)
        for i = 1, math.min(table.getn(problems), 12) do
            NC.Print("  " .. COL.soft .. problems[i] .. COL.r)
        end
    end
end

------------------------------------------------------------
-- Comandos de barra
------------------------------------------------------------
SLASH_NAERCONTROL1 = "/naer"
SLASH_NAERCONTROL2 = "/nc"
SLASH_NAERCONTROL3 = "/naercontrol"

-- Alias directo al filtro de chat, por costumbre de NaerChat.
SLASH_NAERCHATALIAS1 = "/filtros"
SLASH_NAERCHATALIAS2 = "/nchat"
SlashCmdList["NAERCHATALIAS"] = function(msg)
    if NC.Chat and NC.Chat.RunCommand then
        NC.Chat.RunCommand(msg or "")
    end
end

SlashCmdList["NAERCONTROL"] = function(msg)
    msg = string.lower(string.gsub(msg or "", "^%s*(.-)%s*$", "%1"))
    local cmd, rest = string.match(msg, "^(%S*)%s*(.*)$")

    if cmd == "" then
        NC.ToggleWindow()

    elseif cmd == "diag" then
        Diag(rest)

    elseif cmd == "infodiag" then
        NC._infoDiag = not NC._infoDiag
        NC.Print("Diagnóstico de info: " .. (NC._infoDiag and "ON (mira la consola y consulta un personaje)" or "OFF"))

    elseif cmd == "bgtest" then
        NC._bgTest = not NC._bgTest
        if not NC._bgTest then NC._bgQueue = nil end
        NC.Print("Test de cola (Campos de Batalla): " .. (NC._bgTest and "ON (abre la pestaña para verlo)" or "OFF"))
        if NC.RefreshBGStatus then NC.RefreshBGStatus() end

    elseif cmd == "bgdiag" then
        local n = (GetMaxBattlefieldID and GetMaxBattlefieldID()) or 0
        NC.Print("BG diag — GetMaxBattlefieldID = " .. n)
        for i = 1, (n > 0 and n or 3) do
            local st, mp = GetBattlefieldStatus(i)
            NC.Print("  [" .. i .. "] status=" .. tostring(st) .. "  map=" .. tostring(mp))
        end
        NC.Print("  UnitInBattleground = " .. tostring(UnitInBattleground and UnitInBattleground("player")))

    elseif cmd == "bgcap" then
        NC._bgCapDebug = not NC._bgCapDebug
        NC.Print("Captura de mensajes de cola: " .. (NC._bgCapDebug and "ON (apúntate y mira el chat)" or "OFF"))

    elseif cmd == "ratecap" then
        NC._rateCapDebug = not NC._rateCapDebug
        NC.Print("Captura de respuesta de rates: " .. (NC._rateCapDebug and "ON (pulsa Consultar y pega aquí lo que salga)" or "OFF"))

    elseif cmd == "bgq" then
        local q = NC._bgQueue
        if q then
            NC.Print("bgQueue: name=" .. tostring(q.name) .. " nivel=" .. tostring(q.minL)
                .. " ally=" .. tostring(q.allyQ) .. " horde=" .. tostring(q.hordeQ))
        else
            NC.Print("bgQueue = nil (no se ha capturado nada)")
        end
        NC.Print("prevInQ=" .. tostring(NC._prevInQ) .. "  GetBattlefieldStatus(1)=" .. tostring(GetBattlefieldStatus(1)))

    elseif cmd == "trad" then
        -- Volcado de nombres de instancias. Sin argumento: nombres esES REALES
        -- del DBC del cliente (vía GetLFGDungeonInfo, incluye las de bajo nivel
        -- que el Buscador no muestra). "/nc trad tabla": mi tabla EN->ES.
        -- "/nc trad <texto>": prueba la traducción de un nombre concreto.
        local out
        if NC.Console and NC.Console.LogInfo then
            if NC.Console.Show then NC.Console:Show() end
            out = function(s) NC.Console:LogInfo(s) end
        else
            out = function(s) NC.Print(s) end
        end
        if rest == "tabla" or rest == "table" then
            out("=== Mi tabla de instancias (EN -> ES) ===")
            local keys = {}
            for k in pairs(NC.INSTANCE_ES or {}) do keys[#keys + 1] = k end
            table.sort(keys)
            for _, k in ipairs(keys) do out("  " .. k .. "  =  " .. NC.INSTANCE_ES[k]) end
            out("Total: " .. #keys .. " entradas.")
        elseif rest ~= "" then
            NC.Print("'" .. rest .. "'  ->  "
                .. tostring(NC.LocalizeInstance and NC.LocalizeInstance(rest) or rest))
        else
            out("=== Nombres del DBC del cliente (ES, [nivel]) ===")
            if not GetLFGDungeonInfo then
                out("  GetLFGDungeonInfo no disponible en este cliente.")
            else
                local seen, n = {}, 0
                for id = 1, 3000 do
                    local name, _typeID, _subID, minL, maxL = GetLFGDungeonInfo(id)
                    if name and name ~= "" and maxL and maxL > 0 and not seen[name]
                       and not string.find(name, "leatori") then   -- descarta "Aleatoria..."
                        seen[name] = true
                        n = n + 1
                        out(string.format("  [%d-%d] %s", minL or 0, maxL or 0, name))
                    end
                end
                out("Total: " .. n .. " instancias en el DBC.  (usa /nc trad tabla para ver la mía)")
            end
        end

    elseif cmd == "probe" then
        if NC.ToggleProbe then NC.ToggleProbe() end

    elseif cmd == "modo" then
        if rest == "say" or rest == "decir" then
            NC.SetSendMode("SAY")
        elseif rest == "susurro" or rest == "whisper" then
            NC.SetSendMode("WHISPER")
        else
            NC.Print("Uso: /nc modo say  |  /nc modo susurro   (actual: " .. NC.db.sendMode .. ")")
        end

    elseif cmd == "skin" then
        NC.db.skin = (NC.db.skin == "naer") and "blizzard" or "naer"
        NC.ApplySkin()
        NC.Print("Skin: " .. NC.db.skin)

    elseif cmd == "parar" then
        local n = NC.ClearQueue()
        NC.Print(n > 0 and ("Cola vaciada: " .. n .. " consultas descartadas.")
                        or "No había nada en la cola.")

    elseif cmd == "silencio" then
        NC.db.silence = not NC.db.silence
        NC.Print("Respuestas de objeto en el chat: "
            .. (NC.db.silence and (COL.soft .. "ocultas") or (COL.ok .. "visibles")) .. COL.r)

    elseif cmd == "icono" then
        NC.ToggleMinimapButton()

    elseif cmd == "faccion" or cmd == "facción" then
        if rest == "alianza" or rest == "alliance" then
            NC.db.faction = "Alliance"
        elseif rest == "horda" or rest == "horde" then
            NC.db.faction = "Horde"
        elseif rest == "auto" then
            NC.db.faction = nil
        else
            local f, manual = NC.GetFaction()
            NC.Print("Botín del Coliseo: " .. COL.accent .. NC.FactionLabel(f) .. COL.r
                .. (manual and " (fijado a mano)" or " (detectado)")
                .. ".  Uso: /nc faccion alianza|horda|auto")
            return
        end
        NC.ResetIconCache()
        local f, manual = NC.GetFaction()
        NC.Print("Botín del Coliseo: " .. COL.accent .. NC.FactionLabel(f) .. COL.r
            .. (manual and " (fijado)" or " (automático)"))
        if NC.Frame:IsShown() then NC.ShowTab(NC.db.lastTab) end

    elseif cmd == "consola" or cmd == "console" then
        if NC.Console then NC.Console:Toggle() end

    elseif cmd == "flotante" or cmd == "float" then
        NC.ToggleFloatButton()

    elseif cmd == "rates" and rest == "chat" then
        NC.db.silenceRates = (NC.db.silenceRates == false)
        if NC.db.silenceRates == false then
            NC.Print("Respuestas de rates |cffffd100visibles|r en el chat.")
        else
            NC.Print("Respuestas de rates |cffffd100ocultas|r del chat.")
        end

    elseif cmd == "eventos" and rest == "chat" then
        NC.db.silenceEvents = (NC.db.silenceEvents == false)
        if NC.db.silenceEvents == false then
            NC.Print("Respuestas de eventos |cffffd100visibles|r en el chat.")
        else
            NC.Print("Respuestas de eventos |cffffd100ocultas|r del chat.")
        end

    elseif cmd == "eventdiag" then
        if rest == "stop" then
            NC.EventDiag:Stop()
        else
            NC.EventDiag:Start()
        end

    elseif cmd == "instdiag" then
        if rest == "stop" then
            NC.InstDiag:Stop()
        elseif rest == "dump" then
            NC.InstDiag:Dump()
        elseif rest == "clear" then
            NC.InstDiag:Clear()
        else
            NC.InstDiag:Start()
        end

    elseif cmd == "escala" or cmd == "scale" then
        if rest == "auto" or rest == "automatico" or rest == "automático" then
            NC.ResetScaleAuto()
        else
            NC.SetScale(rest)
        end

    elseif cmd == "chat" or cmd == "filtros" then
        if NC.Chat and NC.Chat.RunCommand then
            NC.Chat.RunCommand(rest)
        end

    elseif cmd == "iconos" then
        NC.ShowIconCheck()

    elseif cmd == "ojo" then
        NC.ToggleEye()

    elseif cmd == "vigilados" then
        NC.Watch:Toggle()

    elseif cmd == "reset" then
        NC.cdb.winX, NC.cdb.winY = nil, nil
        NC.cdb.eyeX, NC.cdb.eyeY = nil, nil
        NC.cdb.watchX, NC.cdb.watchY = nil, nil
        NC.db.minimapAngle = 220
        NC.Frame:ClearAllPoints()
        NC.Frame:SetPoint("CENTER")
        NC.Print("Posiciones restablecidas.")

    elseif cmd == "test" then
        NC.Send(".xprate")
        NC.Print("Enviado " .. COL.accent .. ".xprate" .. COL.r
            .. " en modo " .. NC.db.sendMode .. ". Si no responde nada, prueba /nc modo "
            .. (NC.db.sendMode == "SAY" and "susurro" or "say") .. ".")

    else
        NC.Print("Comandos: " .. COL.accent
            .. "/nc" .. COL.r .. " (abrir), "
            .. COL.accent .. "/nc test" .. COL.r .. ", "
            .. COL.accent .. "/nc modo say|susurro" .. COL.r .. ", "
            .. COL.accent .. "/nc skin" .. COL.r .. ", "
            .. COL.accent .. "/nc faccion" .. COL.r .. ", "
            .. COL.accent .. "/nc iconos" .. COL.r .. ", "
            .. COL.accent .. "/nc ojo" .. COL.r .. ", "
            .. COL.accent .. "/nc vigilados" .. COL.r .. ", "
            .. COL.accent .. "/nc icono" .. COL.r .. ", "
            .. COL.accent .. "/nc silencio" .. COL.r .. ", "
            .. COL.accent .. "/nc parar" .. COL.r .. ", "
            .. COL.accent .. "/nc diag [chat]" .. COL.r .. ", "
            .. COL.accent .. "/nc trad [tabla]" .. COL.r .. ", "
            .. COL.accent .. "/nc bgtest" .. COL.r .. ", "
            .. COL.accent .. "/nc reset" .. COL.r)
    end
end

------------------------------------------------------------
-- Integración con el chat: shift+click en un nombre -> al campo de Información,
-- y entrada "Información" en el menú contextual del nombre de jugador.
------------------------------------------------------------
function NC.SetupChatIntegration()
    -- (1) Shift+click en un nombre de jugador del chat -> rellena el campo.
    if type(SetItemRef) == "function" and not NC._hookedSetItemRef then
        NC._hookedSetItemRef = true
        hooksecurefunc("SetItemRef", function(link)
            if not IsShiftKeyDown() then return end
            if type(link) ~= "string" then return end
            local name = string.match(link, "^player:([^:]+)")
            if name and name ~= "" and NC.SetInfoSearch then
                NC.SetInfoSearch(name, false)
            end
        end)
    end

    -- (2) Entrada "Información" en el menú contextual del nombre de jugador.
    if UnitPopupButtons and UnitPopupMenus then
        UnitPopupButtons["NAERCONTROL_INFO"] = { text = "Información", dist = 0 }
        -- IMPORTANTE (fix 1.0.2): NO tocar los menus de marcos de unidad
        -- (PLAYER, PARTY, RAID, RAID_PLAYER). Insertar en ellos contamina
        -- (taint) el menu y bloquea "Fijar foco" (FocusUnit es protegida);
        -- en BG los enemigos usan el menu PLAYER. Solo menus de chat/lista,
        -- que no contienen acciones protegidas.
        local menus = {
            "FRIEND", "FRIEND_OFFLINE", "CHAT_ROSTER", "GUILD", "GUILD_OFFLINE",
        }
        for _, m in ipairs(menus) do
            local menu = UnitPopupMenus[m]
            if menu then
                local found = false
                for _, v in ipairs(menu) do if v == "NAERCONTROL_INFO" then found = true break end end
                if not found then
                    table.insert(menu, #menu, "NAERCONTROL_INFO")   -- justo antes de "Cancelar"
                end
            end
        end
        if type(UnitPopup_OnClick) == "function" and not NC._hookedUnitPopup then
            NC._hookedUnitPopup = true
            hooksecurefunc("UnitPopup_OnClick", function(self)
                if not self or self.value ~= "NAERCONTROL_INFO" then return end
                local dd = UIDROPDOWNMENU_INIT_MENU
                local name = dd and dd.name
                if (not name or name == "") and dd and dd.unit then name = UnitName(dd.unit) end
                if name and name ~= "" and NC.SetInfoSearch then
                    NC.SetInfoSearch(name, true)
                end
            end)
        end
    end
end

------------------------------------------------------------
-- Eventos
------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_SYSTEM")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:RegisterEvent("PLAYER_LEVEL_UP")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")

ev:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON then return end
        InitDB()
        NC.ApplySkin()
        NC.ApplyScale()
        if NC.SyncScaleSlider then NC.SyncScaleSlider() end
        NC.RestoreWindowPos()
        if NC.Chat and NC.Chat.Init then NC.Chat.Init() end
        self:UnregisterEvent("ADDON_LOADED")

    elseif event == "PLAYER_LOGIN" then
        NC.CreateMinimapButton()
        NC.CreateEye()
        -- Los modulos secundarios se protegen: si uno falla, no debe
        -- tumbar la interfaz principal.
        pcall(function() NC.SetupChatIntegration() end)
        pcall(function() if NC.ApplyTheme then NC.ApplyTheme(NC.db and NC.db.theme or "classic") end end)
        pcall(function() if NC.ApplyOpacity then NC.ApplyOpacity(NC.db and NC.db.opacity or 1) end end)
        pcall(function() if NC.InstDiag and NC.InstDiag.Resume then NC.InstDiag:Resume() end end)
        pcall(function() if NC.Dungeons and NC.Dungeons.Init then NC.Dungeons:Init() end end)
        if NC.Chat and NC.Chat.OnLogin then
            local ap, tot = NC.Chat.OnLogin()
            NC.Print("cargado. " .. COL.accent .. "/naer" .. COL.r
                .. " (loot) · " .. COL.accent .. "/naer chat" .. COL.r
                .. " (filtro: " .. ap .. "/" .. tot .. ").")
        else
            NC.Print("cargado. Escribe " .. COL.accent .. "/naer" .. COL.r .. " para abrir.")
        end

    elseif event == "CHAT_MSG_SYSTEM" then
        pcall(function() NC.Scanner:OnSystemMessage(arg1) end)

    elseif event == "PLAYER_TARGET_CHANGED" then
        pcall(function()
            NC.Scanner:RefreshAllMarks()
            NC.Scanner:UpdateProgress()
            NC.Watch:OnTargetChanged()
        end)

    elseif event == "PLAYER_REGEN_ENABLED" then
        pcall(function() NC.Watch:OnCombatEnd() end)

    elseif event == "PLAYER_LEVEL_UP" then
        pcall(function() NC.RefreshCommandsView() end)
    end
end)
