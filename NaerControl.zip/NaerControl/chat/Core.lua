-- Core.lua
-- Motor de filtrado: coincidencia de texto + anti-flood.
local ADDON, NC = ...
NC.Chat = NC.Chat or {}
local NS = NC.Chat

-- Cache del anti-flood.
-- Cada entrada: { shown = <ultimo instante MOSTRADO>, decT = <instante de la ultima
-- decision>, decHide = <bool de esa decision> }.
-- El campo decT/decHide sirve para dar la MISMA respuesta a todas las llamadas del
-- mismo mensaje: WoW invoca el filtro una vez por cada ventana de chat (mismo GetTime),
-- y sin esto la 1a llamada mostraria y las siguientes ocultarian el mismo mensaje.
local CACHE = {}

local function CleanCache()
    local db = NaerChatDB
    if not db then return end
    local now = GetTime()
    local ttl = (db.antiSpamTime or 60) + 5
    for key, rec in pairs(CACHE) do
        local ref = rec.last or rec.decT or 0
        if now - ref > ttl then
            CACHE[key] = nil
        end
    end
end

local function IsRepeat(message, sender, scope)
    local db = NaerChatDB
    if not db then return false end
    if not message or not sender or sender == "" then return false end

    local now = GetTime()
    local window = db.antiSpamTime or 60
    -- La clave incluye el CANAL: las repeticiones se cuentan por canal, si no
    -- un mensaje visto en otro sitio ocultaria la primera copia de Taberna.
    -- El texto se compara NORMALIZADO (sin signos ni mayusculas), asi
    -- "GENTE PARA FOSO" y "GENTE PARA FOSO?" cuentan como el mismo mensaje.
    local body = message
    if NS.CleanText then body = NS.CleanText(body) end
    if NS.Normalize then body = NS.Normalize(body) end
    body = string.gsub(body, "[^%w]", "")
    if body == "" then body = message end
    local key = tostring(scope or "?") .. "|" .. sender .. "|" .. body
    local rec = CACHE[key]

    -- Misma entrega (otra ventana de chat, mismo instante): repetir decision.
    if rec and rec.decT == now then
        return rec.decHide
    end

    CleanCache()
    rec = CACHE[key]

    local hide = false
    if rec and rec.last and (now - rec.last) < window then
        -- Misma racha: se permiten las 2 primeras copias, se oculta desde la 3a.
        rec.seen = (rec.seen or 1) + 1
        if rec.seen >= 3 then
            hide = true
            NS.lastRepeatAge = math.floor(now - (rec.first or rec.last) + 0.5)
        end
    else
        -- Nueva racha (o primera vez): contador a cero.
        if not rec then rec = {}; CACHE[key] = rec end
        rec.seen = 1
        rec.first = now
    end

    rec.last = now          -- ultima vez vista (mide la racha)
    rec.decT = now
    rec.decHide = hide
    return hide
end

-- Devuelve el TEXTO del filtro que coincide (o nil si ninguno).
-- Guard: se ignoran filtros vacios (un "" coincidiria con TODO mensaje).
-- Nota: en 3.3.5a string.lower NO baja acentos ni la ñ, asi que "ignorar mayusculas"
-- funciona con texto ASCII (los filtros por defecto) pero es parcial con acentos.
local function TextMatchReason(message)
    local db = NaerChatDB
    if not db then return nil end

    local ignoreCase = db.ignoreCase
    local hay = ignoreCase and string.lower(message) or message

    if db.textFilters then
        for f, on in pairs(db.textFilters) do
            if on and f ~= "" then
                local needle = ignoreCase and string.lower(f) or f
                if string.find(hay, needle, 1, true) then
                    return f
                end
            end
        end
    end

    if db.customFilters then
        for f, on in pairs(db.customFilters) do
            if on and f ~= "" then
                local needle = ignoreCase and string.lower(f) or f
                if string.find(hay, needle, 1, true) then
                    return f
                end
            end
        end
    end

    return nil
end

-- Devuelve la palabra/frase de aviso que coincide (o nil).
-- Modo B: coincide si el mensaje contiene TODAS las palabras de la frase (en
-- cualquier orden y posicion). Los avisos son SIEMPRE insensibles a mayusculas
-- (independiente de la casilla global). Nota 3.3.5a: string.lower no baja acentos ni ñ.
local function AlertMatchReason(message)
    local db = NaerChatDB
    if not db or not db.alertFilters then return nil end
    local hay = string.lower(message)
    for phrase, on in pairs(db.alertFilters) do
        if on and phrase ~= "" then
            local allFound = true
            for word in string.gmatch(string.lower(phrase), "%S+") do
                if not string.find(hay, word, 1, true) then
                    allFound = false
                    break
                end
            end
            if allFound then
                return phrase
            end
        end
    end
    return nil
end

-- Dispara el aviso: sonido + linea destacada (el mensaje se muestra igualmente).
local function FireAlert(who, keyword)
    pcall(PlaySound, "RaidWarning")
    local w = (who and who ~= "") and who or "(sistema)"
    DEFAULT_CHAT_FRAME:AddMessage("|cffff44ff[NaerChat] Aviso:|r " .. w .. " menciono \"" .. keyword .. "\"")
end

-- Utilidades de cache expuestas al resto del addon.
function NS.ClearCache()
    local n = 0
    for _ in pairs(CACHE) do n = n + 1 end
    CACHE = {}
    return n
end

function NS.CacheCount()
    local n = 0
    for _ in pairs(CACHE) do n = n + 1 end
    return n
end

-- Estado de efectos secundarios (debug/contadores): WoW llama al filtro 1 vez
-- por cada ventana de chat, asi que se procesa 1 sola vez por mensaje real.
local sideTime = 0
local sideSeen = {}

-- Contadores de sesion (se reinician al recargar). Clave = filtro o "__antiflood".
NS.counts = {}

function NS.CountFor(key)
    return NS.counts[key] or 0
end

-- ¿El mensaje viene del canal Taberna? (por nombre, no por numero de canal).
local function IsTabernaChannel(channelArg)
    if type(channelArg) ~= "string" then return false end
    local want = (NaerChatDB and NaerChatDB.channelName) or "taberna"
    return string.find(string.lower(channelArg), string.lower(want), 1, true) ~= nil
end

-- Devuelve la clave de grupo del anti-flood para este mensaje (o nil).
local function AntiFloodGroup(event, channelArg)
    if event == "CHAT_MSG_CHANNEL" then
        if IsTabernaChannel(channelArg) then return "taberna" end
        return nil
    elseif event == "CHAT_MSG_SAY" or event == "CHAT_MSG_YELL" then
        return "say"
    elseif event == "CHAT_MSG_EMOTE" or event == "CHAT_MSG_TEXT_EMOTE" then
        return "emote"
    end
    return nil
end

-- Filtro principal registrado en ChatFrame_AddMessageEventFilter.
-- Etiqueta legible de cada filtro por categoria (para el registro).
local CAT_LABEL = {
    trade   = "comercio",
    pve     = "pve",
    pvp     = "pvp",
    guild   = "reclutamiento",
    links   = "enlaces",
    faction = "faccion",
    junk    = "molestias",
}

-- Devuelve true para OCULTAR el mensaje.
local function Filter(self, event, ...)
    local a1, a2, a3, a4, a5, a6, a7, a8, a9 = ...
    local message = a1

    -- Diagnostico: vuelca los datos crudos del proximo mensaje de canal.
    if NS.diagArm and event == "CHAT_MSG_CHANNEL" then
        NS.diagArm = false
        local cf = DEFAULT_CHAT_FRAME
        cf:AddMessage("|cff33ff99[NaerChat diag]|r evento = " .. tostring(event))
        cf:AddMessage("  arg1 (texto)  : " .. tostring(a1))
        cf:AddMessage("  arg2 (emisor) : " .. tostring(a2))
        cf:AddMessage("  arg3 (idioma) : " .. tostring(a3))
        cf:AddMessage("  arg9 (canal)  : " .. tostring(a9))
        return false
    end

    if not message or type(message) ~= "string" or message == "" then
        return false
    end
    if not NaerChatDB then return false end

    -- No tocar las respuestas de .player iteminfo: son para el escaner de
    -- loot de NaerControl. Si NaerChat las ocultara, el escaner se quedaria
    -- sin leerlas. (NC.ParseItemInfo vive en el nucleo de NaerControl.)
    if event == "CHAT_MSG_SYSTEM" and NC.ParseItemInfo then
        local id = NC.ParseItemInfo(message)
        if id then return false end
    end

    local sender = a2
    if not sender or type(sender) ~= "string" then sender = "" end

    -- Ambito para el anti-flood: canal concreto o tipo de evento.
    local scope = (event == "CHAT_MSG_CHANNEL") and ("ch:" .. tostring(a9))
        or ("ev:" .. tostring(event))

    -- Nunca se ocultan los mensajes propios.
    local isMine = (sender ~= "" and sender == (NS.playerName or ""))

    -- WoW llama al filtro 1 vez por cada ventana de chat: los efectos
    -- (avisos, contadores, registro) solo se hacen en la PRIMERA llamada.
    local now = GetTime()
    if now ~= sideTime then sideTime = now; wipe(sideSeen) end
    local skey = tostring(event) .. "|" .. sender .. "|" .. message
    local first = not sideSeen[skey]
    if first then sideSeen[skey] = true end

    local reason, countKey, cat, doAlert

    if isMine then
        if first and NS.logging and NS.LogAdd then
            local isTab = (event == "CHAT_MSG_CHANNEL") and IsTabernaChannel(a9)
            if isTab then pcall(NS.LogAdd, false, "propio", sender, message) end
        end
        return false
    end

    -- AVISOS: solo mensajes de JUGADORES (se excluye sistema y sin emisor).
    -- Prioridad sobre los filtros de ocultar, pero NO sobre repeticiones.
    local isSystem = (event == "CHAT_MSG_SYSTEM") or (sender == "")
    local aok, akey
    if not isSystem then
        aok, akey = pcall(AlertMatchReason, message)
    end

    if aok and akey then
        local rok, rep = pcall(IsRepeat, message, sender, scope)
        if rok and rep then
            reason, countKey, cat = "anti-flood", "__antiflood", "repetido"
        else
            doAlert = (sender ~= (NS.playerName or ""))
            cat = "aviso"
        end
    else
        -- Filtros de anuncios (texto): GLOBALES.
        local ok, matched = pcall(TextMatchReason, message)
        if ok and matched then
            reason, countKey, cat = "filtro: " .. matched, matched, "anuncio"
        end

        -- Canal permitido segun "Aplicar a:".
        local group = AntiFloodGroup(event, a9)
        local chanOK = group and NaerChatDB.antiSpamChannels
            and NaerChatDB.antiSpamChannels[group]

        -- Filtros por categoria (comercio / PvE / PvP / faccion / molestias).
        if not reason and chanOK and NS.ExtraMatch then
            local ok3, key = pcall(NS.ExtraMatch, message, a3)
            if ok3 and key then
                reason   = "filtro " .. key
                countKey = "__" .. key
                cat      = CAT_LABEL[key] or key
            end
        end

        -- Anti-flood (repetidos).
        if not reason and sender ~= "" and NaerChatDB.antiSpamEnabled and chanOK then
            local ok2, isrep = pcall(IsRepeat, message, sender, scope)
            if ok2 and isrep then
                reason, countKey, cat = "anti-flood", "__antiflood", "repetido"
            end
        end
    end

    -- En PAUSA no se oculta nada, pero se sigue analizando: asi el chat va
    -- en crudo y el registro dice que se habria filtrado (para comparar).
    local hide = (reason ~= nil)
    if NS.paused then hide = false end

    if first then
        if not NS.paused and doAlert then
            pcall(FireAlert, sender, akey)
            NS.counts["__alert"] = (NS.counts["__alert"] or 0) + 1
        end
        if hide and countKey then
            NS.counts[countKey] = (NS.counts[countKey] or 0) + 1
        end

        -- Registro: todo lo de Taberna, mas cualquier mensaje ocultado.
        if NS.logging and NS.LogAdd then
            local isTab = (event == "CHAT_MSG_CHANNEL") and IsTabernaChannel(a9)
            if isTab or reason then
                local label = cat or "otro"
                if label == "repetido" and NS.lastRepeatAge then
                    label = "repetido +" .. NS.lastRepeatAge .. "s"
                end
                pcall(NS.LogAdd, reason ~= nil, label, sender, message)
            end
        end
    end

    return hide
end

-- Eventos de chat a los que se registra el filtro.
NS.MESSAGE_TYPES = {
    "CHAT_MSG_SYSTEM",
    "CHAT_MSG_SAY",
    "CHAT_MSG_YELL",
    "CHAT_MSG_GUILD",
    "CHAT_MSG_PARTY",
    "CHAT_MSG_RAID",
    "CHAT_MSG_RAID_LEADER",
    "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_CHANNEL",
    "CHAT_MSG_WHISPER",
    "CHAT_MSG_EMOTE",
    "CHAT_MSG_TEXT_EMOTE",
    "CHAT_MSG_BATTLEGROUND",
    "CHAT_MSG_BATTLEGROUND_LEADER",
}

function NS.SetupFilters()
    local applied = 0
    for _, t in ipairs(NS.MESSAGE_TYPES) do
        local ok = pcall(ChatFrame_AddMessageEventFilter, t, Filter)
        if ok then applied = applied + 1 end
    end
    return applied, #NS.MESSAGE_TYPES
end

-- Reporte de estado en el chat.
function NS.PrintReport()
    local db = NaerChatDB
    local cf = DEFAULT_CHAT_FRAME
    if not db then return end

    cf:AddMessage("|cff33ff99=== NaerChat ===|r")

    if NS.paused then
        cf:AddMessage("  |cffff8040PAUSADO|r (no se esta filtrando nada)")
    end

    local nd = 0
    for k, on in pairs(db.textFilters or {}) do
        if on then
            nd = nd + 1
            cf:AddMessage("  |cff40ff40[x]|r " .. k .. "  |cff888888(ocultados: " .. NS.CountFor(k) .. ")|r")
        end
    end

    local nc = 0
    for k, on in pairs(db.customFilters or {}) do
        if on then
            nc = nc + 1
            cf:AddMessage("  |cff40ff40[x]|r (pers.) " .. k .. "  |cff888888(ocultados: " .. NS.CountFor(k) .. ")|r")
        end
    end

    cf:AddMessage("  Filtros de anuncios activos: |cff40ff40" .. nd .. "|r")
    cf:AddMessage("  Filtros personalizados activos: |cff40ff40" .. nc .. "|r")

    if db.antiSpamEnabled then
        -- Lista de canales activos del anti-flood.
        local chans = {}
        for _, c in ipairs(NS.AF_CHANNELS) do
            if db.antiSpamChannels and db.antiSpamChannels[c.key] then
                table.insert(chans, c.label)
            end
        end
        local chanStr = (#chans > 0) and table.concat(chans, ", ") or "ninguno"
        cf:AddMessage("  |cff40ff40[x]|r Anti-flood: " .. (db.antiSpamTime or 60)
            .. "s en |cffffd100" .. chanStr .. "|r  |cff888888(ocultados: " .. NS.CountFor("__antiflood") .. ")|r")
    else
        cf:AddMessage("  |cffff8040[ ]|r Anti-flood desactivado")
    end

    cf:AddMessage("  No distinguir mayusculas: " .. (db.ignoreCase and "si" or "no"))

    local na = 0
    for _, on in pairs(db.alertFilters or {}) do
        if on then na = na + 1 end
    end
    cf:AddMessage("  Palabras de aviso activas: |cffff44ff" .. na .. "|r  |cff888888(avisos: " .. NS.CountFor("__alert") .. ")|r")
end

-- Arranque del modulo de chat. Lo invoca NaerControl desde su propio
-- ADDON_LOADED / PLAYER_LOGIN, para que haya un solo punto de entrada.
function NS.Init()
    NS.InitDB()
    if NS.BuildLog then NS.BuildLog() end
    -- La UI de configuracion la construye NaerControl al abrir su pestaña.
end

function NS.OnLogin()
    NS.playerName = UnitName("player")
    NS.playerFaction = UnitFactionGroup("player")   -- "Alliance" / "Horde"
    local applied, total = NS.SetupFilters()
    return applied, total
end
