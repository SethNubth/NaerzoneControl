-- UI.lua
-- Interfaz de configuracion (estilo oscuro, rejilla de dos columnas).
local ADDON, NC = ...
NC.Chat = NC.Chat or {}
local NS = NC.Chat

local function SectionHeader(parent, text, x, y)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("TOPLEFT", x, y)
    fs:SetText(text)
    fs:SetTextColor(1, 0.82, 0)
    return fs
end

local function Divider(parent, y)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetTexture(1, 1, 1, 0.12)
    t:SetHeight(1)
    t:SetPoint("TOPLEFT", 20, y)
    t:SetPoint("TOPRIGHT", -20, y)
    return t
end

local function VDivider(parent, x, yTop, yBottom)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetTexture(1, 1, 1, 0.12)
    t:SetWidth(1)
    t:SetHeight(yTop - yBottom)
    t:SetPoint("TOPLEFT", x, yTop)
    return t
end

local function MakeCheck(parent, x, y, text)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", x, y)
    cb:SetSize(22, 22)
    local lbl = cb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    lbl:SetText(text)
    lbl:SetTextColor(0.9, 0.9, 0.9)
    if NC.SkinCheckbox then NC.SkinCheckbox(cb) end
    return cb
end

-- Panel de lista de filtros (input + boton + scroll) sobre una tabla de la DB.
-- Devuelve la funcion de refresco.
local function MakeFilterPanel(parent, x, yTop, headerText, panelW, dbField, scrollName, SetStatus)
    SectionHeader(parent, headerText, x, yTop)

    local input = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    input:SetSize(panelW - 78, 20)
    input:SetPoint("TOPLEFT", x + 8, yTop - 24)
    input:SetAutoFocus(false)
    input:SetMaxLetters(60)
    -- Register filters with the same link router used by the other tabs.
    input:SetScript("OnEditFocusGained", function(self) NS.linkTarget = self end)
    input:SetScript("OnEditFocusLost", function(self)
        if NS.linkTarget == self then NS.linkTarget = nil end
    end)
    NC.RegisterLinkTarget(input, true)

    local addBtn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    addBtn:SetSize(58, 22)
    addBtn:SetPoint("LEFT", input, "RIGHT", 8, 0)
    addBtn:SetText("Añadir")

    local bg = CreateFrame("Frame", nil, parent)
    bg:SetSize(panelW, 86)
    bg:SetPoint("TOPLEFT", x, yTop - 50)
    bg:SetBackdrop({
        bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    bg:SetBackdropColor(0, 0, 0, 0.4)
    bg:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.8)

    -- IMPORTANTE: el ScrollFrame necesita NOMBRE para que la barra/flechas se
    -- cableen (la plantilla busca "<nombre>ScrollBar"). Sin nombre, no hay scroll.
    local scroll = CreateFrame("ScrollFrame", scrollName, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", bg, "TOPLEFT", 6, -6)
    scroll:SetSize(panelW - 36, 74)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local sb = _G[scrollName .. "ScrollBar"]
        if sb then
            sb:SetValue(sb:GetValue() - delta * 20)
        end
    end)
    if NC.SkinScrollOf then NC.SkinScrollOf(scroll) end

    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(panelW - 44, 1)
    scroll:SetScrollChild(content)

    local items = {}
    local refresh
    refresh = function()
        for _, it in ipairs(items) do
            it:Hide()
            it:SetParent(nil)
        end
        wipe(items)

        local t = NaerChatDB[dbField]
        local keys = {}
        for k in pairs(t) do table.insert(keys, k) end
        table.sort(keys)

        local yy, h = 0, 24
        for _, key in ipairs(keys) do
            local row = CreateFrame("Frame", nil, content)
            row:SetSize(panelW - 52, h)
            row:SetPoint("TOPLEFT", 2, -yy)

            local cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
            cb:SetPoint("LEFT", 0, 0)
            cb:SetSize(20, 20)
            cb:SetChecked(t[key] == true)
            cb:SetScript("OnClick", function(self)
                t[key] = (self:GetChecked() == 1)
            end)
            if NC.SkinCheckbox then NC.SkinCheckbox(cb) end

            local lbl = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            lbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
            lbl:SetPoint("RIGHT", row, "RIGHT", -30, 0)
            lbl:SetJustifyH("LEFT")
            lbl:SetText(key)
            lbl:SetTextColor(1, 1, 1)

            local del = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            del:SetSize(24, 18)
            del:SetPoint("RIGHT", 0, 0)
            del:SetText("X")
            del:SetScript("OnClick", function()
                t[key] = nil
                SetStatus("Eliminado: " .. key, 1, 0.85, 0.2)
                refresh()
            end)

            table.insert(items, row)
            yy = yy + h + 4
        end

        content:SetHeight(math.max(1, yy))
        scroll:UpdateScrollChildRect()

        if #items == 0 then
            if not content.empty then
                content.empty = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                content.empty:SetPoint("TOP", 0, -8)
                content.empty:SetTextColor(0.6, 0.6, 0.6)
            end
            content.empty:SetText("(vacío)")
            content.empty:Show()
        elseif content.empty then
            content.empty:Hide()
        end
    end

    local function add()
        local txt = input:GetText()
        txt = txt and strtrim(txt) or ""
        if string.len(txt) < 3 then
            SetStatus("Texto muy corto (min. 3)", 1, 0.5, 0.2)
            return
        end
        if NaerChatDB[dbField][txt] ~= nil then
            SetStatus("Ya existe: " .. txt, 1, 0.85, 0.2)
            return
        end
        NaerChatDB[dbField][txt] = true
        input:SetText("")
        SetStatus("Añadido: " .. txt, 0.4, 1, 0.4)
        refresh()
    end
    addBtn:SetScript("OnClick", add)
    input:SetScript("OnEnterPressed", function() add() end)
    input:SetScript("OnEscapePressed", function(self) self:SetText(""); self:ClearFocus() end)

    return refresh
end

-- Only the visible, focused filter may consume a player link.
local function LinkTargetReady()
    local tgt = NS.linkTarget
    if not tgt or not tgt:IsVisible() or not tgt:HasFocus() then return nil end
    if NC.IsBlizzardLinkInputActive() then return nil end
    return tgt
end

function NS.BuildUI(parent)
    -- Player links bypass ChatEdit_InsertLink when the chat is closed.
    -- Intercept only the CHATLINK gesture; normal/right clicks keep their
    -- original whisper/menu behavior. Object links use the shared router.
    if not NS._playerLinkHooked and type(SetItemRef) == "function" then
        NS._playerLinkHooked = true
        local origSetItemRef = SetItemRef
        SetItemRef = function(link, text, button, chatFrame, ...)
            if button ~= "RightButton" and type(IsModifiedClick) == "function"
                and IsModifiedClick("CHATLINK") and type(link) == "string" then
                local tgt = LinkTargetReady()
                if tgt then
                    local name = string.match(link, "^player:([^:]+)")
                        or string.match(link, "^playerGM:([^:]+)")
                    if name and name ~= "" then
                        tgt:Insert(name)
                        return
                    end
                end
            end
            return origSetItemRef(link, text, button, chatFrame, ...)
        end
    end

    -- Incrustada como pestana de NaerControl: 'f' es un panel hijo del
    -- contenedor de contenido, no una ventana flotante propia.
    local f = CreateFrame("Frame", "NaerChatConfig", parent or UIParent)
    if parent then
        -- Incrustada: ocupa el area de contenido. La ventana de NaerControl
        -- es lo bastante ancha para las dos columnas, asi que no hace falta
        -- scroll. Se sube ~86px para reaprovechar el hueco de la cabecera.
        f:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 60)
        f:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", 0, 30)
    else
        f:SetSize(640, 668)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetBackdrop({
            bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 16, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 },
        })
        f:SetBackdropColor(0.05, 0.05, 0.07, 0.95)
        f:SetMovable(true)
        f:EnableMouse(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        f:SetClampedToScreen(true)
        table.insert(UISpecialFrames, "NaerChatConfig")
        f:Hide()
    end

    -- Cabecera. Incrustada en NaerControl, su ventana ya aporta titulo y
    -- boton de cerrar, asi que aqui no se pintan (evita la doble cabecera).
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -18)
    title:SetText("NaerChat")

    local subtitle = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    subtitle:SetPoint("TOP", 0, -40)
    subtitle:SetText("Filtro de chat de Naerzone")
    subtitle:SetTextColor(0.6, 0.6, 0.65)

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    if parent then
        title:Hide()
        subtitle:Hide()
        close:Hide()
    end

    local status = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    status:SetPoint("TOP", 0, -62)
    status:SetText("")

    f.statusExpiry = 0
    f:SetScript("OnUpdate", function(self)
        if self.statusExpiry > 0 and GetTime() > self.statusExpiry then
            self.statusExpiry = 0
            status:SetText("")
        end
    end)

    local function SetStatus(txt, r, g, b)
        status:SetText(txt)
        status:SetTextColor(r or 0.4, g or 1, b or 0.4)
        f.statusExpiry = GetTime() + 3
    end

    -- Dos columnas (la UI cabe porque NaerControl se ensancha para ella).
    local RX, RCX, RDY = 328, 334, 0
    VDivider(f, 312, -88, -604)

    -- =====================================================
    -- BANDA A / IZQUIERDA: FILTROS DE ANUNCIOS
    -- =====================================================
    SectionHeader(f, "Filtros de anuncios", 20, -92)

    local defaultChecks = {}
    local y = -114
    for _, key in ipairs(NS.DEFAULT_FILTERS) do
        local cb = MakeCheck(f, 26, y, key)
        cb.key = key
        cb:SetScript("OnClick", function(self)
            local on = (self:GetChecked() == 1)
            NaerChatDB.textFilters[self.key] = on
            if on then
                SetStatus("Activado: " .. self.key, 0.4, 1, 0.4)
            else
                SetStatus("Desactivado: " .. self.key, 1, 0.85, 0.2)
            end
            PlaySound("igMainMenuOptionCheckBoxOn")
        end)
        cb:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(self.key)
            local d = NS.FILTER_DESC and NS.FILTER_DESC[self.key]
            if d then GameTooltip:AddLine(d, 1, 1, 1, true) end
            GameTooltip:AddLine("Ocultados esta sesión: " .. NS.CountFor(self.key), 0.6, 1, 0.6)
            GameTooltip:Show()
        end)
        cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
        defaultChecks[key] = cb
        y = y - 24
    end

    -- =====================================================
    -- BANDA A / DERECHA: OPCIONES (incluye canales del anti-flood)
    -- =====================================================
    SectionHeader(f, "Opciones", RX, -92 + RDY)

    -- (La casilla "Mostrar botón en el minimapa" se movio a la pestana Ajustes de NaerControl.)

    local caseCb = MakeCheck(f, RCX, -138 + RDY, "No distinguir mayusculas")
    caseCb:SetScript("OnClick", function(self)
        NaerChatDB.ignoreCase = (self:GetChecked() == 1)
        SetStatus("No distinguir mayusculas " .. (NaerChatDB.ignoreCase and "activado" or "desactivado"), 0.4, 1, 1)
    end)
    caseCb:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("No distinguir mayusculas")
        GameTooltip:AddLine("Los filtros comparan pasando todo a minusculas, así coinciden sin importar mayusculas/minusculas. No cambia como se ve el chat. Aviso: en 3.3.5a no afecta a acentos ni a la ñ.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    caseCb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Sub-titulo + toggles de canal del anti-flood.
    local afLbl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    afLbl:SetPoint("TOPLEFT", RX, -166 + RDY)
    afLbl:SetText("Aplicar a:")
    afLbl:SetTextColor(0.7, 0.7, 0.75)

    local channelChecks = {}
    local cy = -186 + RDY
    for _, c in ipairs(NS.AF_CHANNELS) do
        local cb = MakeCheck(f, RCX, cy, c.label)
        cb.chanKey = c.key
        cb:SetScript("OnClick", function(self)
            local on = (self:GetChecked() == 1)
            NaerChatDB.antiSpamChannels[self.chanKey] = on
            NS.ClearCache()
            SetStatus("Anti-flood en " .. c.label .. ": " .. (on and "si" or "no"), 0.4, 1, 1)
        end)
        channelChecks[c.key] = cb
        cy = cy - 24
    end

    Divider(f, -262)

    -- =====================================================
    -- BANDA B / IZQUIERDA: ANTI-FLOOD
    -- =====================================================
    SectionHeader(f, "Anti-flood", 20, -278)

    local spamCb = MakeCheck(f, 26, -300, "Ocultar repetidos")
    spamCb:SetScript("OnClick", function(self)
        local on = (self:GetChecked() == 1)
        NaerChatDB.antiSpamEnabled = on
        if not on then NS.ClearCache() end
        SetStatus("Anti-flood " .. (on and "activado" or "desactivado"), 0.4, 1, 1)
    end)
    spamCb:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Anti-repeticion")
        GameTooltip:AddLine("Cuando alguien repite el MISMO mensaje, se muestra 1 copia y se ocultan las siguientes durante los segundos indicados. Actua solo en los canales marcados en Opciones.", 1, 1, 1, true)
        GameTooltip:AddLine("Ocultados esta sesión: " .. NS.CountFor("__antiflood"), 0.6, 1, 0.6)
        GameTooltip:Show()
    end)
    spamCb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local timeLbl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    timeLbl:SetPoint("TOPLEFT", 30, -330)
    timeLbl:SetText("Mostrar de nuevo tras (seg):")
    timeLbl:SetTextColor(0.8, 0.8, 0.8)

    local timeInput = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    timeInput:SetSize(50, 20)
    timeInput:SetPoint("LEFT", timeLbl, "RIGHT", 12, 0)
    timeInput:SetAutoFocus(false)
    timeInput:SetNumeric(true)
    timeInput:SetMaxLetters(3)
    timeInput:SetScript("OnEnterPressed", function(self)
        local v = tonumber(self:GetText())
        if v and v > 0 and v <= 999 then
            NaerChatDB.antiSpamTime = v
            NS.ClearCache()
            SetStatus("Tiempo anti-flood: " .. v .. "s", 0.4, 1, 0.4)
        else
            self:SetText(tostring(NaerChatDB.antiSpamTime or 60))
            SetStatus("Valor invalido", 1, 0.5, 0.2)
        end
        self:ClearFocus()
    end)
    timeInput:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

    -- Molestias (debajo del anti-flood).
    local junkCb = MakeCheck(f, 26, -356, "Ocultar molestias")
    junkCb:SetScript("OnClick", function(self)
        local on = (self:GetChecked() == 1)
        NaerChatDB.extraFilters.junk = on
        SetStatus("Molestias: " .. (on and "ocultando" or "desactivado"), 0.4, 1, 1)
        PlaySound("igMainMenuOptionCheckBoxOn")
    end)
    junkCb:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Molestias")
        GameTooltip:AddLine(NS.JUNK_DESC, 1, 1, 1, true)
        GameTooltip:AddLine("Ocultados esta sesión: " .. NS.CountFor("__junk"), 0.6, 1, 0.6)
        GameTooltip:Show()
    end)
    junkCb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- =====================================================
    -- BANDA B / DERECHA: MAS FILTROS (categorias)
    -- =====================================================
    SectionHeader(f, "Mas filtros", RX, -278 + RDY)

    local extraChecks = {}
    local ey = -300 + RDY
    for _, ef in ipairs(NS.EXTRA_FILTERS) do
        local cb = MakeCheck(f, RCX, ey, ef.label)
        cb.efKey = ef.key
        cb:SetScript("OnClick", function(self)
            local on = (self:GetChecked() == 1)
            NaerChatDB.extraFilters[self.efKey] = on
            SetStatus(ef.label .. ": " .. (on and "ocultando" or "desactivado"), 0.4, 1, 1)
            PlaySound("igMainMenuOptionCheckBoxOn")
        end)
        cb:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(ef.label)
            GameTooltip:AddLine(ef.desc, 1, 1, 1, true)
            GameTooltip:AddLine("Solo actua en los canales de 'Aplicar a:'", 0.7, 0.7, 0.7, true)
            GameTooltip:AddLine("Ocultados esta sesión: " .. NS.CountFor("__" .. ef.key), 0.6, 1, 0.6)
            GameTooltip:Show()
        end)
        cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
        extraChecks[ef.key] = cb
        ey = ey - 24
    end

    Divider(f, -452)

    -- =====================================================
    -- BANDA C: PERSONALIZADOS (izq: ocultar / der: avisar)
    -- =====================================================
    local refreshHide  = MakeFilterPanel(f, 20,  -468, "Ocultar mensajes",   282, "customFilters", "NaerChatHideScroll",  SetStatus)
    local refreshAlert = MakeFilterPanel(f, 326, -468, "Avisar de mensajes", 296, "alertFilters",  "NaerChatAlertScroll", SetStatus)

    Divider(f, -606)

    -- =====================================================
    -- BOTONES DE ACCION
    -- En modo incrustado NO se anclan a 'f' (que scrollea): se exponen
    -- para que NaerControl los coloque en su barra inferior, a tamano
    -- normal, sin que les afecte el scroll de los filtros.
    -- =====================================================
    function NS.MakeActionButtons(bar)
        local resetBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
        resetBtn:SetSize(96, 22)
        resetBtn:SetText("Resetear")
        resetBtn:SetScript("OnClick", function()
            NS.ResetDB()
            NS.ClearCache()
            local onShow = f:GetScript("OnShow")
            if onShow then onShow(f) end
            SetStatus("Configuracion reseteada", 0.4, 1, 1)
        end)

        local logBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
        logBtn:SetSize(96, 22)
        logBtn:SetText("Registro")
        logBtn:SetScript("OnClick", function()
            if NS.ToggleLog then NS.ToggleLog() end
        end)
        logBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine("Registro de Taberna")
            GameTooltip:AddLine("Abre una ventana con el canal SIN filtrar, marcando en color lo que el addon oculta. El chat normal sigue filtrado.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        logBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

        local pauseBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
        pauseBtn:SetSize(96, 22)
        pauseBtn:SetText(NS.paused and "Reanudar" or "Pausar")
        pauseBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine("Pausar el filtrado")
            GameTooltip:AddLine("Deja la Taberna en crudo, igual que sin addon. El registro sigue funcionando y te dice que se habria filtrado, para comparar.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        pauseBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        pauseBtn:SetScript("OnClick", function(self)
            NS.paused = not NS.paused
            self:SetText(NS.paused and "Reanudar" or "Pausar")
            if NS.paused then
                SetStatus("Filtrado en PAUSA (chat en crudo)", 1, 0.6, 0.2)
            else
                SetStatus("Filtrado reanudado", 0.4, 1, 0.4)
            end
        end)

        local reportBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
        reportBtn:SetSize(96, 22)
        reportBtn:SetText("Reporte")
        reportBtn:SetScript("OnClick", function()
            NS.PrintReport()
        end)

        -- fila horizontal, centrada en la barra
        resetBtn:SetPoint("LEFT", bar, "LEFT", 8, 0)
        logBtn:SetPoint("LEFT", resetBtn, "RIGHT", 6, 0)
        pauseBtn:SetPoint("LEFT", logBtn, "RIGHT", 6, 0)
        reportBtn:SetPoint("LEFT", pauseBtn, "RIGHT", 6, 0)

        NS.pauseBtn = pauseBtn
        return { resetBtn, logBtn, pauseBtn, reportBtn }
    end

    -- Version flotante (sin incrustar): botones dentro del propio marco.
    if not parent then
        local btns = NS.MakeActionButtons(f)
        btns[1]:ClearAllPoints(); btns[1]:SetPoint("BOTTOMLEFT", 20, 20)
        btns[4]:ClearAllPoints(); btns[4]:SetPoint("BOTTOMRIGHT", -20, 20)
    end
    local pauseBtn = NS.pauseBtn

    -- =====================================================
    -- SINCRONIZAR AL MOSTRAR
    -- =====================================================
    f:SetScript("OnShow", function(self)
        for key, cb in pairs(defaultChecks) do
            cb:SetChecked(NaerChatDB.textFilters[key] == true)
        end
        spamCb:SetChecked(NaerChatDB.antiSpamEnabled == true)
        timeInput:SetText(tostring(NaerChatDB.antiSpamTime or 60))
        caseCb:SetChecked(NaerChatDB.ignoreCase == true)
        for key, cb in pairs(channelChecks) do
            cb:SetChecked(NaerChatDB.antiSpamChannels[key] == true)
        end
        for key, cb in pairs(extraChecks) do
            cb:SetChecked(NaerChatDB.extraFilters[key] == true)
        end
        junkCb:SetChecked(NaerChatDB.extraFilters.junk == true)
        if NS.pauseBtn then NS.pauseBtn:SetText(NS.paused and "Reanudar" or "Pausar") end
        refreshHide()
        refreshAlert()
        status:SetText("")
        f.statusExpiry = 0
    end)

    f:SetScript("OnHide", function(self)
        NS.linkTarget = nil
    end)

    return f
end
