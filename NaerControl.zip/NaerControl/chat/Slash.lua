-- Slash.lua
-- Comandos de barra del addon.
local ADDON, NC = ...
NC.Chat = NC.Chat or {}
local NS = NC.Chat

-- La suite integrada enruta "/naer chat ..." hasta aqui. Ya no registra
-- comandos propios: NaerControl es el unico duenno de la barra.
function NS.RunCommand(msg)
    local rawmsg = strtrim(msg or "")
    msg = string.lower(rawmsg)
    local cf = DEFAULT_CHAT_FRAME

    if msg == "status" or msg == "estado" then
        NS.PrintReport()

    elseif msg == "clear" or msg == "limpiar" then
        local n = NS.ClearCache()
        cf:AddMessage("|cff33ff99[NaerChat]|r cache limpiada (" .. n .. ")")

    elseif msg == "reset" then
        NS.ResetDB()
        NS.ClearCache()
        if NS.configFrame and NS.configFrame:IsShown() then
            NS.configFrame:GetScript("OnShow")(NS.configFrame)
        end
        cf:AddMessage("|cff33ff99[NaerChat]|r configuracion reseteada")

    elseif msg == "minimap" then
        NaerChatDB.minimap.hide = not NaerChatDB.minimap.hide
        if NS.UpdateMinimapButton then NS.UpdateMinimapButton() end
        if NS.configFrame and NS.configFrame:IsShown() then
            NS.configFrame:GetScript("OnShow")(NS.configFrame)
        end
        cf:AddMessage("|cff33ff99[NaerChat]|r botón de minimapa " .. (NaerChatDB.minimap.hide and "oculto" or "visible"))

    elseif msg == "channel" or msg == "canal" then
        cf:AddMessage("|cff33ff99[NaerChat]|r canal del anti-flood: |cffffd100" .. tostring(NaerChatDB.channelName) .. "|r")
        cf:AddMessage("  Para cambiarlo: |cffffd100/nchat channel <nombre>|r")

    elseif string.sub(msg, 1, 8) == "channel " or string.sub(msg, 1, 6) == "canal " then
        local name = strtrim(string.match(msg, "%s(.+)$") or "")
        if name ~= "" then
            NaerChatDB.channelName = name
            NS.ClearCache()
            cf:AddMessage("|cff33ff99[NaerChat]|r canal del anti-flood ahora: |cffffd100" .. name .. "|r")
        end

    elseif msg == "pause" or msg == "pausar" then
        NS.paused = not NS.paused
        if NS.configFrame and NS.configFrame:IsShown() then
            NS.configFrame:GetScript("OnShow")(NS.configFrame)
        end
        if NS.paused then
            cf:AddMessage("|cff33ff99[NaerChat]|r filtrado |cffff8040EN PAUSA|r (ves el chat en crudo). Repite el comando para reanudar.")
        else
            cf:AddMessage("|cff33ff99[NaerChat]|r filtrado reanudado.")
        end

    elseif string.sub(msg, 1, 5) == "test " then
        local texto = strtrim(string.sub(rawmsg or msg, 6))
        if texto == "" then
            cf:AddMessage("|cff33ff99[NaerChat]|r uso: |cffffd100/nchat test <mensaje>|r")
        else
            local cat = NS.ExtraMatch and NS.ExtraMatch(texto) or nil
            cf:AddMessage("|cff33ff99[NaerChat test]|r " .. texto)
            if cat then
                cf:AddMessage("  veredicto: |cffff5555SE OCULTA|r (" .. cat .. ")")
            else
                cf:AddMessage("  veredicto: |cff40ff40pasa|r (ningún filtro coincide)")
            end
            if NS.Explain then
                local hits, total = NS.Explain(texto)
                cf:AddMessage("  palabras: " .. total)
                if #hits == 0 then
                    cf:AddMessage("  senales: ninguna")
                else
                    for i = 1, #hits do cf:AddMessage("  " .. hits[i]) end
                end
            end
            -- Estado que puede impedir que se aplique en el juego.
            local ex = NaerChatDB.extraFilters or {}
            local act = {}
            for _, e in ipairs(NS.EXTRA_FILTERS or {}) do
                if ex[e.key] then act[#act + 1] = e.key end
            end
            if ex.junk then act[#act + 1] = "junk" end
            cf:AddMessage("  categorías activas: " .. ((#act > 0) and table.concat(act, ", ") or "|cffff5555ninguna|r"))
            local tab = NaerChatDB.antiSpamChannels and NaerChatDB.antiSpamChannels.taberna
            cf:AddMessage("  'Aplicar a: Taberna': " .. (tab and "|cff40ff40si|r" or "|cffff5555NO (por eso no filtra)|r"))
            if NS.paused then cf:AddMessage("  |cffff8040ojo: filtrado en PAUSA|r") end
        end

    elseif msg == "log" or msg == "registro" or msg == "debug" then
        if NS.ToggleLog then
            local open = NS.ToggleLog()
            if open then
                cf:AddMessage("|cff33ff99[NaerChat]|r registro abierto: el chat sigue filtrado y aquí ves Taberna sin filtrar, en color lo que se oculta.")
            else
                cf:AddMessage("|cff33ff99[NaerChat]|r registro cerrado.")
            end
        end

    elseif msg == "diag" then
        NS.diagArm = true
        cf:AddMessage("|cff33ff99[NaerChat]|r Diagnostico armado: escribe algo en un canal (p.ej. Taberna) y verás sus datos crudos.")

    elseif msg == "escala" or msg == "scale" or string.sub(msg, 1, 7) == "escala "
        or string.sub(msg, 1, 6) == "scale " then
        local arg = strtrim(string.match(msg, "%s(.+)$") or "")
        if arg == "" or arg == "auto" then
            if NC.db then NC.db.chatScale = nil end
            cf:AddMessage("|cff33ff99[NaerChat]|r escala de la pestana: |cffffd100automática|r (segun tu resolucion).")
        else
            local v = tonumber(arg)
            if v and v >= 0.5 and v <= 1.0 then
                if NC.db then NC.db.chatScale = v end
                cf:AddMessage("|cff33ff99[NaerChat]|r escala de la pestana fijada a |cffffd100" .. v .. "|r.")
            else
                cf:AddMessage("|cff33ff99[NaerChat]|r uso: |cffffd100/naer chat escala <0.5-1.0>|r  o  |cffffd100auto|r")
            end
        end
        -- reaplica al momento si la pestana esta abierta
        if NC.Frame and NC.Frame:IsShown() and NC.ChatScale then
            NC.Frame:SetScale(NC.ChatScale())
        end

    elseif msg == "help" or msg == "ayuda" then
        cf:AddMessage("|cff33ff99[NaerChat]|r comandos:")
        cf:AddMessage("  |cffffd100/nchat|r  abrir/cerrar la ventana")
        cf:AddMessage("  |cffffd100/nchat test <texto>|r  probar un mensaje y ver por que se filtra")
        cf:AddMessage("  |cffffd100/nchat status|r  ver estado")
        cf:AddMessage("  |cffffd100/nchat clear|r  limpiar cache anti-flood")
        cf:AddMessage("  |cffffd100/nchat pause|r  pausar/reanudar el filtrado")
        cf:AddMessage("  |cffffd100/nchat minimap|r  mostrar/ocultar el botón del minimapa")
        cf:AddMessage("  |cffffd100/nchat channel <nombre>|r  canal del anti-flood (por defecto: taberna)")
        cf:AddMessage("  |cffffd100/nchat log|r  abrir el registro (Taberna sin filtrar)")
        cf:AddMessage("  |cffffd100/nchat diag|r  inspeccionar el proximo mensaje de canal")
        cf:AddMessage("  |cffffd100/naer chat escala <0.5-1.0|auto>|r  tamaño de la pestana")
        cf:AddMessage("  |cffffd100/nchat reset|r  restaurar valores por defecto")

    else
        -- sin subcomando: abrir NaerControl en la pestana de chat
        if NC.OpenChatTab then NC.OpenChatTab() end
    end
end
