-- Filters.lua
-- Filtros por categoria (comercio, PvE, PvP, faccion, molestias).
-- Todo se compara sobre texto NORMALIZADO: minusculas y sin acentos ni ñ,
-- porque en 3.3.5a string.lower no baja acentos.
local ADDON, NC = ...
NC.Chat = NC.Chat or {}
local NS = NC.Chat

-- =====================================================
-- NORMALIZACION
-- =====================================================
-- Secuencias UTF-8 (el cliente 3.3.5a usa UTF-8 en el chat).
local ACCENTS = {
    ["\195\161"] = "a", ["\195\129"] = "a",  -- a A
    ["\195\169"] = "e", ["\195\137"] = "e",  -- e E
    ["\195\173"] = "i", ["\195\141"] = "i",  -- i I
    ["\195\179"] = "o", ["\195\147"] = "o",  -- o O
    ["\195\186"] = "u", ["\195\154"] = "u",  -- u U
    ["\195\188"] = "u", ["\195\156"] = "u",  -- u dieresis
    ["\195\177"] = "n", ["\195\145"] = "n",  -- ñ Ñ
    ["\195\160"] = "a", ["\195\168"] = "e",  -- a e graves
    ["\195\172"] = "i", ["\195\178"] = "o", ["\195\185"] = "u",
}

-- Quita los codigos de WoW (color, enlaces, texturas) dejando el nombre visible.
-- Sin esto, "|cff..|Hitem:45245:..|h[Coraza]|h|rv" se trocea como
-- "cffa335ee | hitem | 45245 | .. | rv" y se pierde la "v" de venta.
function NS.CleanText(s)
    if type(s) ~= "string" then return "" end
    s = string.gsub(s, "|c%x%x%x%x%x%x%x%x", "")
    s = string.gsub(s, "|H.-|h", "")
    s = string.gsub(s, "|T.-|t", "")
    s = string.gsub(s, "|h", "")
    s = string.gsub(s, "|r", "")
    s = string.gsub(s, "|n", " ")
    return s
end

function NS.Normalize(s)
    if type(s) ~= "string" then return "" end
    s = string.gsub(s, "\195[\128-\191]", function(c)
        return ACCENTS[c] or c
    end)
    return string.lower(s)
end

-- Conjunto de palabras del mensaje. Ademas de la palabra completa, se anaden
-- los trozos de las palabras PEGADAS con numeros ("icc10normal" -> icc, 10,
-- normal; "sr10n" -> sr, 10). Solo trozos de 2+ caracteres, para no generar
-- ruido ("2v2" conserva su forma y no aporta "v").
local function Tokenize(norm)
    local words = {}
    for w in string.gmatch(norm, "[%w]+") do
        words[w] = true
        if string.find(w, "%a") and string.find(w, "%d") then
            for part in string.gmatch(w, "%a+") do
                if string.len(part) >= 2 then words[part] = true end
            end
            for part in string.gmatch(w, "%d+") do
                if string.len(part) >= 2 then words[part] = true end
            end
        end
    end
    return words
end

-- Un termino con espacios se busca como frase; sin espacios, palabra completa.
local function Has(norm, words, term)
    if string.find(term, " ", 1, true) then
        return string.find(norm, term, 1, true) ~= nil
    end
    return words[term] == true
end

local function HasAny(norm, words, list)
    for i = 1, #list do
        if Has(norm, words, list[i]) then return true end
    end
    return false
end

-- =====================================================
-- LISTAS
-- =====================================================

-- COMERCIO ------------------------------------------------
-- Fuertes: bastan por si solas.
local TRADE_STRONG = {
    "compro", "compra", "compran", "vendo", "vende", "venden", "venta",
    "vendiendo", "vend", "wts", "wtb",
    "subasta", "subasto", "precio", "precios", "cambio", "trafi", "tranfi",
    "transfi", "remato", "remate", "rematando", "liquido", "liquidacion",
    "ofrezco", "traspaso",
    -- profesiones (es / en / abreviadas)
    "sastreria", "herreria", "joyeria", "alquimia", "ingenieria",
    "encantamiento", "encantamientos", "encantar", "encanto", "encantador",
    "encantadores", "peleteria", "inscripcion", "mineria", "herboristeria",
    "desuello", "cocina",
    "sastre", "sastres", "herrero", "herreros", "joyero", "joyeros",
    "alquimista", "alquimistas", "ingeniero", "ingenieros",
    "peletero", "peleteros", "escriba", "escribas", "minero", "mineros",
    "herbolario", "herbolarios", "cocinero", "desollador", "desolladores",
    "hoyero", "hoyeros", "joyeri", "joieria",
    "inscriptor", "inscritor", "inscriptores", "inscritores",
    "gema", "gemas", "glifo", "glifos", "transmutar", "transmutacion",
    "tailoring", "blacksmithing", "jewelcrafting", "alchemy", "engineering",
    "enchanting", "enchant", "enchants", "ench", "leatherworking",
    "inscription", "mining", "herbalism", "skinning", "cooking",
    "gem", "gems", "glyph", "glyphs", "transmute",
    "enchanter", "blacksmith", "jewelcrafter", "alchemist", "engineer",
}
-- Debiles: solo cuentan si el mensaje lleva un objeto enlazado.
local TRADE_WEAK = {
    "v", "c", "cu", "pack", "barato", "barata", "pago", "oferta", "busco", "lvl",
    "doy", "cambio", "permuto", "intercambio", "trueque", "por",
}

-- Precio en oro: "350g", "350 g", "1.5k", "2k", "350 oro", "350 gold".
-- Se usa junto con un objeto enlazado: enlace + precio = venta casi segura.
local function HasPrice(norm)
    if string.find(norm, "%d%s*[gk]%f[%A]") then return true end
    if string.find(norm, "%d%s*oro") then return true end
    if string.find(norm, "%d%s*gold") then return true end
    if string.find(norm, "%d%s*monedas") then return true end
    return false
end

-- PvE -----------------------------------------------------
-- Fuertes: nombre de instancia/banda inequivoco (es / en).
local PVE_STRONG = {
    "icc", "ciudadela", "corona de hielo", "icecrown",
    "naxx", "naxxramas", "ulduar", "onyxia", "malygos",
    "santuario obsidiana", "santuario de obsidiana", "obsidian sanctum",
    "santuario rubi", "santuario de rubi", "ruby sanctum",
    "sagrario", "sagrario rubi", "sagrario de rubi",
    "sartharion", "sarth", "sarthar",
    "camara de archavon", "vault of archavon", "archa", "archavon", "voa",
    "prueba del cruzado", "prueba del gran cruzado",
    "trial of the crusader", "trial of the grand crusader",
    "coliseo", "coliseum",
    "salones del reflejo", "halls of reflection",
    "sima de saron", "foso de saron", "pit of saron",
    "fragua de las almas", "forge of souls",
    "mazmorra violeta", "violet hold",
    "utgarde", "pinaculo", "pinnacle",
    "azjol", "ahnkahet", "reino antiguo", "old kingdom",
    "gundrak", "draktharon", "drak tharon",
    "nexo", "nexus", "oculo", "oculus",
    "purga de stratholme", "culling of stratholme",
    "camaras del corazon", "halls of stone", "halls of lightning",
    "salon de la piedra", "salon del rayo",
    "lanza del dragon", "drak theron",
    "invernalia", "hallazgo",
    -- TBC / clasico (lista cerrada, no crece sola)
    "magtheridon", "gruul", "karazhan", "zulaman", "zul aman",
    "hyjal", "templo oscuro", "black temple", "sunwell", "plateau del sol",
    "castillo de la tempestad", "caverna del santuario", "santuario serpiente",
    "molten core", "guarida de gruul", "guarida de magtheridon",
}
-- Ambiguos: necesitan una segunda senal (formato, verbo o rol).
local PVE_WEAK = {
    "toc", "tog", "os", "rs", "sr", "voa", "hor", "pos", "fos", "vh",
    "pdc", "pcn", "pgc", "cos", "uk", "up", "an", "ak", "hos", "hol",
    "lk", "lich", "putricida", "sindragosa", "profesor", "valithria",
    "foso", "fosos", "forja", "forjas", "fragua", "fraguas", "reflejo",
    "salones", "purga", "aleatoria", "tempestad", "mision", "misiones",
    "diaria", "diarias", "semanal", "semanales", "mazmorra", "mazmorras",
    "banda", "raid", "heroica", "heroicas", "instancia", "wipe", "loot",
}
local PVE_FORMAT = {
    "10n", "25n", "10hc", "25hc", "10", "25", "hc", "nm",
    "heroico", "normal", "hm", "10m", "25m",
}
-- ROLES de grupo (tank / heal / dps). Dos roles DISTINTOS en un mensaje
-- corto son un anuncio de grupo, sin necesidad de verbo.
local PVE_ROLE = {
    "heal", "heals", "healer", "healers", "heler", "helers", "heller",
    "helear", "healear", "hiler", "sanador", "sanadores", "curador",
    "tank", "tanks", "tanke", "tankes", "tanque", "tanques", "tnk",
    "dps", "dd", "caster", "casters", "melee", "ranged",
    "ot", "mt",
}
-- CLASES: acompanan, pero NO cuentan como rol ("yo tengo dk tank" es charla).
local PVE_CLASS = {
    "pala", "paladin", "sacer", "chaman", "brujo", "mago", "druida",
    "dudu", "picaro", "pica", "cazador", "caza", "guerrero", "guerre",
    "dk", "warri", "warrior", "priest", "hunter", "mage", "rogue",
    "warlock", "shaman", "druid",
}
local PVE_VERB = {
    "armo", "armamos", "arma", "arman", "armando", "monto", "montamos",
    "busco", "buscamos", "buscando", "need", "necesito", "necesitamos",
    "faltan", "falta", "lfm", "lf", "invito", "invita", "apuntarse",
    "nito", "nesesito", "gente para", "gente pa", "gente x",
    "algun", "alguna", "algunos", "alguien", "hace falta", "hacen falta",
    "anote", "anoten", "anota", "anotar", "anotarse", "anotense",
    "apunte", "apunten", "apunta", "apuntar", "apuntense",
    "gs", "gearscore", "compa", "compañero", "compania",
    "farmeo", "farmear", "farmeando", "farmeamos", "farmea", "farm", "farmeos",
}

-- PvP -----------------------------------------------------
local PVP_TERMS = {
    "2v2", "3v3", "5v5", "2vs2", "3vs3", "5vs5",
    "2c2", "3c3", "5c5", "2s2", "3s3", "5s5", "2x2", "3x3", "5x5",
    "rbg", "rbgs", "rated", "ratedbg",
    "bg", "bgs", "go bg", "campo de batalla", "campos de batalla",
    "arena", "arenas", "conquista", "isla de la conquista",
    "invasion", "invasiones", "pvp",
    "alterac", "arathi", "cuenca de arathi",
    "garganta", "grito de guerra", "warsong",
    "ojo de la tormenta", "eots", "wsg",
    "playa de los ancestros", "strand",
    "lago del azote", "wintergrasp",
    "ruinas de lordaeron", "circulo del valor", "arena de nagrand",
    "filospada", "dalaran sewers",
}
-- Debiles: necesitan compania (verbo o formato de arena).
local PVP_WEAK = { "honor", "mmr", "rating", "puntos" }

-- RECLUTAMIENTO DE HERMANDAD ------------------------------
local GUILD_STRONG = {
    "recluta", "reclutan", "reclutamos", "reclutando", "reclutamiento",
    "reclutar", "reclutas", "roster",
}
local GUILD_WEAK = {
    "hermandad", "guild", "players", "avance", "loteo", "dados",
    "comprometida", "comprometido", "comprometidos", "requisitos",
    "progreso", "core", "discord", "teamspeak", "ts3", "raideo", "raideo",
}

-- FACCION (por idioma del mensaje) ------------------------
local LANG_HORDE = {
    "orco", "orcish", "taurahe", "trol", "troll", "darkspear",
    "gutterspeak", "lengua vil", "thalassian", "thalassiano", "zandali",
}
local LANG_ALLIANCE = {
    "comun", "common", "enano", "dwarvish", "draenei",
    "gnomo", "gnomish", "darnassiano", "darnassian",
}

-- Palabras cortas con significado: no se consideran molestias pese a ser breves.
local JUNK_ALLOW = {
    ok = true, oki = true, si = true, no = true, ya = true, va = true,
    gg = true, wp = true, gj = true, ty = true, thx = true, xd = true,
    np = true, ns = true, nc = true, yes = true, yep = true, aja = true,
    hi = true, hey = true, ea = true, eso = true, voy = true, jej = true,
    jaj = true, ah = true, oh = true, uf = true, ff = true, gl = true,
    hf = true, brb = true, afk = true, wow = true, ptm = true, dps = true,
}

local function InList(list, value)
    for i = 1, #list do
        if list[i] == value then return true end
    end
    return false
end

-- =====================================================
-- COMPROBACIONES
-- =====================================================

-- Secuencias de teclado (teclazos tipo "ASDASDSAD").
local KEYMASH = {
    "asd", "sdf", "dfg", "fgh", "ghj", "hjk", "jkl",
    "qwe", "wer", "ert", "rty", "tyu", "yui", "uio", "iop",
    "zxc", "xcv", "cvb", "vbn", "bnm",
    "lkj", "kjh", "poi", "oiu", "mnb",
}

-- Molestias: numeros/simbolos solos, mensajes muy cortos, letra repetida 3+,
-- teclazos de teclado y mensajes con mucha repeticion interna.
function NS.CheckJunk(message)
    local s = strtrim(message or "")
    if s == "" then return false end
    -- Si lleva un objeto enlazado, no es basura.
    if string.find(s, "|H", 1, true) then return false end
    -- Sin ninguna letra (solo numeros/simbolos): "12312314", "!!!!"
    if not string.find(s, "%a") then return true end

    local norm = NS.Normalize(s)

    -- Muy corto (3 caracteres o menos): "a", "kk", "gaa".
    -- Se respetan las respuestas cortas con significado ("ok", "gg", "si"...).
    if string.len(s) <= 3 then
        local w = string.gsub(norm, "[^%w]", "")
        if JUNK_ALLOW[w] then return false end
        return true
    end

    -- Misma letra repetida 3 o mas veces seguidas: "gaaa", "holaaaa".
    if string.find(norm, "(%a)%1%1") then return true end

    -- Teclazo: una sola palabra larga con secuencias de teclado ("asdasdsad").
    if not string.find(norm, "%s") and string.len(norm) >= 5 then
        for i = 1, #KEYMASH do
            if string.find(norm, KEYMASH[i], 1, true) then return true end
        end
    end

    -- Teclazo por consonantes: 5+ consonantes seguidas es imposible en
    -- espanol ("LAKHSDKSHJADAS"). Cubre variantes infinitas sin listarlas.
    for w in string.gmatch(norm, "%a+") do
        if string.find(w, "[bcdfghjklmnpqrstvwxyz][bcdfghjklmnpqrstvwxyz][bcdfghjklmnpqrstvwxyz][bcdfghjklmnpqrstvwxyz][bcdfghjklmnpqrstvwxyz]") then
            return true
        end
    end

    -- Dominado por relleno: "- ------- ------ 1 dps" (casi todo guiones).
    -- Se mide la PROPORCION, para no tocar mensajes largos con "//" o "!!".
    local nchars = string.len(s)
    if nchars >= 8 then
        local letters = 0
        for _ in string.gmatch(s, "%a") do letters = letters + 1 end
        if (letters * 10) < (nchars * 3) then return true end   -- menos del 30%
    end

    -- Repeticion interna: mensaje largo con muy pocas palabras distintas
    -- (copiar y pegar la misma frase varias veces en un solo mensaje).
    local total, uniq = 0, 0
    local seen = {}
    for w in string.gmatch(norm, "[%w]+") do
        total = total + 1
        if not seen[w] then seen[w] = true; uniq = uniq + 1 end
    end
    if total >= 8 and uniq <= (total * 0.4) then return true end

    return false
end

-- Un anuncio es corto y telegrafico; la conversacion es larga y diluida.
-- En mensajes largos se exige que las senales sean una parte real del texto,
-- para que hablar SOBRE una banda no se confunda con anunciar grupo.
local function Diluted(total, signals)
    if not total or total <= 8 then return false end
    -- Un anuncio largo acumula muchas senales aunque el texto sea extenso
    -- (los de hermandad son asi): a partir de 4 no se considera conversacion.
    if signals >= 4 then return false end
    return (signals * 5) < total          -- menos del 20% de palabras son senales
end

local function CountAny(norm, words, list)
    local n = 0
    for i = 1, #list do
        if Has(norm, words, list[i]) then n = n + 1 end
    end
    return n
end

-- Enlaces web / publicidad de streams y servidores.
local WEB = {
    "http", "www.", ".com", ".net", ".org", ".gg", ".tv", ".es/",
    "discord", "twitch", "youtube", "youtu.be", "kick.com", "tiktok",
}
function NS.CheckLinks(norm)
    for i = 1, #WEB do
        if string.find(norm, WEB[i], 1, true) then return true end
    end
    return false
end

function NS.CheckTrade(norm, words, hasLink, total, linkCount)
    -- Dos o mas objetos enlazados: lista de venta o trueque ("Doy X por Y").
    if (linkCount or 0) >= 2 then return true end
    -- Objeto enlazado + precio: senal inequivoca, no depende del verbo.
    if hasLink and HasPrice(norm) then return true end
    if hasLink and HasAny(norm, words, TRADE_WEAK) then return true end
    local n = CountAny(norm, words, TRADE_STRONG)
    if n > 0 then
        if hasLink then return true end
        return not Diluted(total, n)
    end
    return false
end

function NS.CheckPvE(norm, words, total)
    local strong = CountAny(norm, words, PVE_STRONG)

    local fmt   = HasAny(norm, words, PVE_FORMAT)
    local roles = CountAny(norm, words, PVE_ROLE)   -- cuantos roles DISTINTOS
    local role  = roles > 0
    local class = HasAny(norm, words, PVE_CLASS)
    local verb  = HasAny(norm, words, PVE_VERB)

    -- Cuantos terminos ambiguos aparecen (toc, diaria, heroica, banda...).
    local weak = 0
    for i = 1, #PVE_WEAK do
        if Has(norm, words, PVE_WEAK[i]) then weak = weak + 1 end
    end

    -- Total de senales del mensaje (para medir densidad).
    local signals = strong + weak + roles
        + (fmt and 1 or 0) + (verb and 1 or 0) + (class and 1 or 0)
    if Diluted(total, signals) then return false end

    -- Dos roles DISTINTOS ("tank y dps", "heler y dps"): anuncio de grupo.
    -- No aplica a una sola mencion ("yo tengo dk tank" es conversacion).
    if roles >= 2 then return true end
    -- Enumeracion de 3+ clases distintas ("mago caza brujo"): listar clases
    -- es pedir gente para grupo; nadie enumera 3 clases en charla normal.
    if CountAny(norm, words, PVE_CLASS) >= 3 then return true end
    -- Nombre de instancia inequivoco.
    if strong > 0 then return true end
    -- Ambiguo + una segunda senal: "armo toc 25n".
    if weak >= 1 and (fmt or role or verb) then return true end
    -- Dos ambiguos juntos: "la diaria heroica", "banda semanal".
    if weak >= 2 then return true end
    -- Verbo + rol, clase o formato: "busco heal", "algun dudu", "armo 25n".
    if verb and (role or fmt or class) then return true end
    return false
end

function NS.CheckGuild(norm, words, total)
    -- "recluta/reclutamos/roster" casi nunca aparecen en charla normal,
    -- y los anuncios de hermandad son largos por naturaleza: no se diluyen.
    if HasAny(norm, words, GUILD_STRONG) then return true end
    -- Dos senales debiles juntas: "hermandad ... loteo", "players ... avance".
    local n = 0
    for i = 1, #GUILD_WEAK do
        if Has(norm, words, GUILD_WEAK[i]) then n = n + 1 end
    end
    return n >= 2
end

function NS.CheckPvP(norm, words, total)
    local n = CountAny(norm, words, PVP_TERMS)
    if n > 0 and not Diluted(total, n) then return true end
    if HasAny(norm, words, PVP_WEAK) and HasAny(norm, words, PVE_VERB) then
        return true
    end
    return false
end

-- Faccion: se detecta por el IDIOMA del mensaje (arg3) o por una etiqueta
-- entre corchetes en el texto ("[Orco]", "[Common]"...).
function NS.CheckEnemyFaction(language, norm)
    local mine = NS.playerFaction   -- "Alliance" / "Horde"
    if not mine then return false end

    local lang = NS.Normalize(language or "")
    local found

    if lang ~= "" then
        if InList(LANG_HORDE, lang) then found = "Horde"
        elseif InList(LANG_ALLIANCE, lang) then found = "Alliance" end
    end

    if not found and norm then
        for tag in string.gmatch(norm, "%[(.-)%]") do
            tag = strtrim(tag)
            if InList(LANG_HORDE, tag) then found = "Horde" break
            elseif InList(LANG_ALLIANCE, tag) then found = "Alliance" break end
        end
    end

    if not found then return false end
    return found ~= mine
end

-- Punto de entrada: devuelve la clave del filtro que oculta el mensaje, o nil.
function NS.ExtraMatch(message, language)
    local db = NaerChatDB
    if not db or not db.extraFilters then return nil end
    local ex = db.extraFilters

    local clean   = NS.CleanText(message)
    local norm    = NS.Normalize(clean)
    local words   = Tokenize(norm)
    local hasLink = string.find(message, "|H", 1, true) ~= nil
    local linkCount = 0
    for _ in string.gmatch(message, "|H") do linkCount = linkCount + 1 end

    -- Numero de palabras reales (ya sin codigos de enlace).
    local total = 0
    for _ in string.gmatch(norm, "[%w]+") do total = total + 1 end

    if ex.faction and NS.CheckEnemyFaction(language, norm) then return "faction" end
    if ex.links   and NS.CheckLinks(norm)                   then return "links"   end
    if ex.trade   and NS.CheckTrade(norm, words, hasLink, total, linkCount) then return "trade" end
    -- Reclutamiento antes que PvP/PvE: es mas especifico.
    if ex.guild   and NS.CheckGuild(norm, words, total)     then return "guild"   end
    -- PvP antes que PvE: sus terminos son mas especificos ("busco 2v2").
    if ex.pvp     and NS.CheckPvP(norm, words, total)       then return "pvp"     end
    if ex.pve     and NS.CheckPvE(norm, words, total)       then return "pve"     end
    -- Molestias al final: asi un anuncio repetido se etiqueta por su categoria.
    if ex.junk    and NS.CheckJunk(message)                then return "junk"    end

    return nil
end

-- =====================================================
-- DIAGNOSTICO: explica que senales ve el filtro en un texto
-- =====================================================
local GROUPS = {
    { "comercio",  TRADE_STRONG }, { "comercio(debil)", TRADE_WEAK },
    { "instancia", PVE_STRONG },   { "ambiguo",  PVE_WEAK },
    { "formato",   PVE_FORMAT },   { "rol",      PVE_ROLE },
    { "clase",     PVE_CLASS },    { "verbo",    PVE_VERB },
    { "pvp",       PVP_TERMS },    { "hermandad", GUILD_STRONG },
    { "hermandad(debil)", GUILD_WEAK },
}

function NS.Explain(message)
    local clean = NS.CleanText(message)
    local norm  = NS.Normalize(clean)
    local words = Tokenize(norm)
    local total = 0
    for _ in string.gmatch(norm, "[%w]+") do total = total + 1 end

    local out = {}
    for i = 1, #GROUPS do
        local name, list = GROUPS[i][1], GROUPS[i][2]
        local hits = {}
        for j = 1, #list do
            if Has(norm, words, list[j]) then hits[#hits + 1] = list[j] end
        end
        if #hits > 0 then
            out[#out + 1] = name .. ": " .. table.concat(hits, ", ")
        end
    end

    local links = 0
    for _ in string.gmatch(message, "|H") do links = links + 1 end
    if links > 0 then out[#out + 1] = "objetos enlazados: " .. links end
    if HasPrice(norm) then out[#out + 1] = "precio en oro: si" end

    return out, total
end
