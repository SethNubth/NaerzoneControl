-- LogWindow.lua
-- Ventana de registro: muestra Taberna EN CRUDO y marca lo que el addon oculta,
-- mientras el chat real sigue filtrado. Sirve para comparar y afinar filtros.
local ADDON, NC = ...
NC.Chat = NC.Chat or {}
local NS = NC.Chat

local MAX_LINES = 300

-- Color por categoria (r, g, b) y etiqueta corta.
local CAT = {
    comercio   = { 1.00, 0.82, 0.20 },
    pve        = { 0.40, 1.00, 0.45 },
    pvp        = { 1.00, 0.45, 0.30 },
    reclutamiento = { 0.95, 0.70, 0.40 },
    enlaces    = { 0.45, 0.90, 0.90 },
    propio     = { 0.75, 0.75, 0.80 },
    faccion    = { 0.80, 0.50, 1.00 },
    molestias  = { 0.60, 0.60, 0.60 },
    repetido   = { 0.35, 0.85, 1.00 },
    anuncio    = { 0.45, 0.65, 1.00 },
    aviso      = { 1.00, 0.35, 1.00 },
}

NS.logLines = {}

local frame, msgFrame, onlyHiddenCb, pauseBtn, infoFS

local function ColorFor(cat)
    local base = string.match(cat or "", "^(%a+)") or cat
    local c = CAT[cat] or CAT[base]
    if c then return c[1], c[2], c[3] end
    return 1, 0.5, 0.5
end

local function Redraw()
    if not msgFrame then return end
    msgFrame:Clear()
    local onlyHidden = NaerChatDB and NaerChatDB.logOnlyHidden
    local shown = 0
    for i = 1, #NS.logLines do
        local L = NS.logLines[i]
        if not (onlyHidden and not L.hidden) then
            shown = shown + 1
            if L.hidden then
                local r, g, b = ColorFor(L.cat)
                msgFrame:AddMessage("|cff888888" .. L.time .. "|r [" .. L.cat .. "] "
                    .. L.sender .. ": " .. L.text, r, g, b)
            else
                msgFrame:AddMessage("|cff888888" .. L.time .. "|r |cff44ff44[ok]|r "
                    .. L.sender .. ": " .. L.text, 0.9, 0.9, 0.9)
            end
        end
    end
    if infoFS then
        infoFS:SetText(shown .. " / " .. #NS.logLines .. " líneas")
    end
end

-- Anade una linea al registro. hidden = true si el addon lo oculto.
function NS.LogAdd(hidden, cat, sender, text)
    if not NS.logging then return end
    if NS.logPaused then return end

    table.insert(NS.logLines, {
        hidden = hidden and true or false,
        cat    = cat or "?",
        sender = (sender ~= "" and sender) or "(sistema)",
        text   = text or "",
        time   = date("%H:%M:%S"),
    })
    while #NS.logLines > MAX_LINES do
        table.remove(NS.logLines, 1)
    end

    if frame and frame:IsShown() then
        local onlyHidden = NaerChatDB and NaerChatDB.logOnlyHidden
        local L = NS.logLines[#NS.logLines]
        if onlyHidden and not L.hidden then
            -- no se pinta, pero actualizamos el contador
            if infoFS then infoFS:SetText(infoFS:GetText()) end
            return
        end
        if L.hidden then
            local r, g, b = ColorFor(L.cat)
            msgFrame:AddMessage("|cff888888" .. L.time .. "|r [" .. L.cat .. "] "
                .. L.sender .. ": " .. L.text, r, g, b)
        else
            msgFrame:AddMessage("|cff888888" .. L.time .. "|r |cff44ff44[ok]|r "
                .. L.sender .. ": " .. L.text, 0.9, 0.9, 0.9)
        end
    end
end

function NS.BuildLog()
    if frame then return frame end

    frame = CreateFrame("Frame", "NaerChatLog", UIParent)
    frame:SetSize(600, 380)
    frame:SetPoint("CENTER", 200, 0)
    frame:SetFrameStrata("DIALOG")
    frame:SetBackdrop({
        bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 16, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    frame:SetBackdropColor(0.04, 0.04, 0.06, 0.95)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetClampedToScreen(true)
    frame:Hide()

    table.insert(UISpecialFrames, "NaerChatLog")

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -18)
    title:SetText("Registro de Taberna (sin filtrar)")

    local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hint:SetPoint("TOP", 0, -38)
    hint:SetText("El chat sigue filtrado; aquí ves todo y en color lo que se oculta")
    hint:SetTextColor(0.6, 0.6, 0.65)

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    -- Area de mensajes.
    local bg = CreateFrame("Frame", nil, frame)
    bg:SetPoint("TOPLEFT", 20, -58)
    bg:SetPoint("BOTTOMRIGHT", -20, 54)
    bg:SetBackdrop({
        bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    bg:SetBackdropColor(0, 0, 0, 0.5)
    bg:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.8)

    msgFrame = CreateFrame("ScrollingMessageFrame", "NaerChatLogMessages", frame)
    msgFrame:SetPoint("TOPLEFT", bg, "TOPLEFT", 8, -8)
    msgFrame:SetPoint("BOTTOMRIGHT", bg, "BOTTOMRIGHT", -8, 8)
    msgFrame:SetFontObject(GameFontHighlightSmall)
    msgFrame:SetJustifyH("LEFT")
    msgFrame:SetMaxLines(MAX_LINES)
    msgFrame:SetFading(false)
    msgFrame:EnableMouseWheel(true)
    msgFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then
            if IsShiftKeyDown() then self:ScrollToTop() else self:ScrollUp() end
        else
            if IsShiftKeyDown() then self:ScrollToBottom() else self:ScrollDown() end
        end
    end)

    -- Controles inferiores.
    onlyHiddenCb = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    onlyHiddenCb:SetPoint("BOTTOMLEFT", 20, 20)
    onlyHiddenCb:SetSize(22, 22)
    local ohLbl = onlyHiddenCb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ohLbl:SetPoint("LEFT", onlyHiddenCb, "RIGHT", 4, 0)
    ohLbl:SetText("Solo ocultados")
    ohLbl:SetTextColor(0.9, 0.9, 0.9)
    onlyHiddenCb:SetScript("OnClick", function(self)
        NaerChatDB.logOnlyHidden = (self:GetChecked() == 1)
        Redraw()
    end)

    infoFS = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    infoFS:SetPoint("BOTTOM", 0, 26)
    infoFS:SetText("0 / 0 líneas")
    infoFS:SetTextColor(0.6, 0.6, 0.65)

    pauseBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    pauseBtn:SetSize(96, 22)
    pauseBtn:SetPoint("BOTTOMRIGHT", -124, 20)
    pauseBtn:SetText("Pausar")
    pauseBtn:SetScript("OnClick", function(self)
        NS.logPaused = not NS.logPaused
        self:SetText(NS.logPaused and "Reanudar" or "Pausar")
    end)

    local clearBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    clearBtn:SetSize(96, 22)
    clearBtn:SetPoint("BOTTOMRIGHT", -20, 20)
    clearBtn:SetText("Limpiar")
    clearBtn:SetScript("OnClick", function()
        wipe(NS.logLines)
        Redraw()
    end)

    frame:SetScript("OnShow", function()
        NS.logging = true
        onlyHiddenCb:SetChecked(NaerChatDB.logOnlyHidden == true)
        pauseBtn:SetText(NS.logPaused and "Reanudar" or "Pausar")
        Redraw()
        msgFrame:ScrollToBottom()
    end)
    frame:SetScript("OnHide", function()
        NS.logging = false
    end)

    return frame
end

function NS.ToggleLog()
    if not frame then NS.BuildLog() end
    if frame:IsShown() then frame:Hide() else frame:Show() end
    return frame:IsShown()
end
