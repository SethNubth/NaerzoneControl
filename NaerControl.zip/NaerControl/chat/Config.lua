-- Config.lua
-- Valores por defecto e inicializacion de la base de datos guardada.
local ADDON, NC = ...
NC.Chat = NC.Chat or {}
local NS = NC.Chat

NS.ADDON_NAME = "NaerChat"
NS.VERSION    = "1.0.2"
NS.DB_VERSION = 8

-- Filtros por categoria (columna "Mas filtros"). Solo actuan en los canales
-- marcados en "Aplicar a:". Desactivados por defecto.
NS.EXTRA_FILTERS = {
    {
        key = "trade", label = "Comercio",
        desc = "Oculta compra/venta: 'compro', 'vendo', 'wts', profesiones, y objetos enlazados junto a 'v', 'c/u', 'pack', etc.",
    },
    {
        key = "pve", label = "PvE (grupos/bandas)",
        desc = "Oculta busqueda de grupo: nombres de mazmorra y banda (es e ingles), formatos 10n/25hc y verbos con rol ('armo... need heal').",
    },
    {
        key = "pvp", label = "PvP",
        desc = "Oculta 'go bg', arenas 2v2/3v3, conquista, invasiones y nombres de campos de batalla.",
    },
    {
        key = "guild", label = "Reclutamiento",
        desc = "Oculta anuncios de hermandades: 'recluta', 'players', 'avance', 'loteo a dados', requisitos y horarios.",
    },
    {
        key = "links", label = "Enlaces / publicidad",
        desc = "Oculta mensajes con direcciones web (kick, twitch, youtube, discord, http, www...).",
    },
    {
        key = "faction", label = "Faccion contraria",
        desc = "Oculta mensajes en idioma enemigo (Orco/Orcish si eres Alianza; Comun/Common si eres Horda).",
    },
}

NS.JUNK_DESC = "Oculta mensajes sin contenido: solo números ('12312314'), de 3 caracteres o menos, o con una letra repetida 3+ veces ('gaaa')."

-- Orden en que se muestran los filtros de anuncios en la interfaz.
NS.DEFAULT_FILTERS = {
    "RAID INFO",
    "BG Queue Announcer",
    "Anuncio de Cola de Arena",
    "Event Message",
    "[Anuncio de RatedBG]",
    "[Anuncio de Cola de RatedBG]",
}

-- Descripcion breve de cada filtro (para el tooltip de su casilla).
NS.FILTER_DESC = {
    ["RAID INFO"]                    = "Avisos automaticos de información de raids/eventos.",
    ["BG Queue Announcer"]           = "Anuncios de cola de campos de batalla.",
    ["Anuncio de Cola de Arena"]     = "Avisos de gente entrando a la cola de arena.",
    ["Event Message"]                = "Mensajes automaticos de eventos del servidor.",
    ["[Anuncio de RatedBG]"]         = "Resultados de partidas de RatedBG.",
    ["[Anuncio de Cola de RatedBG]"] = "Grupos entrando a la cola de RatedBG.",
}

-- Canales a los que se puede aplicar el anti-flood (orden de la UI).
NS.AF_CHANNELS = {
    { key = "taberna", label = "Taberna" },
    { key = "say",     label = "Decir / gritar" },
    { key = "emote",   label = "Emociones" },
}

NS.DEFAULTS = {
    dbVersion = 5,
    textFilters = {
        ["RAID INFO"]                    = true,
        ["BG Queue Announcer"]           = true,
        ["Anuncio de Cola de Arena"]     = true,
        ["Event Message"]                = true,
        ["[Anuncio de RatedBG]"]         = true,   -- nuevo (resultados de RatedBG)
        ["[Anuncio de Cola de RatedBG]"] = true,   -- nuevo (grupos entrando a cola)
    },
    customFilters   = {},
    alertFilters    = {},       -- palabras que disparan aviso (prioridad, no se ocultan)
    -- Filtros por categoria: desactivados por defecto (son agresivos).
    extraFilters    = {
        trade   = false,
        pve     = false,
        pvp     = false,
        guild   = false,
        links   = false,
        faction = false,
        junk    = false,
    },
    antiSpamEnabled = true,
    antiSpamTime    = 60,        -- ventana del anti-flood: 1 copia por minuto
    ignoreCase      = true,
    logOnlyHidden   = false,    -- en el registro, mostrar solo lo ocultado
    channelName     = "taberna", -- nombre del canal Taberna (por nombre, no numero)
    -- Canales donde actua el anti-flood (solo Taberna por defecto).
    antiSpamChannels = {
        taberna = true,
        say     = false,
        emote   = false,
    },
    minimap         = { angle = 210, hide = false },
}

-- Inicializa NaerChatDB rellenando solo lo que falte (no pisa lo del usuario).
function NS.InitDB()
    if not NaerChatDB then NaerChatDB = {} end
    local db = NaerChatDB

    -- Version con la que se guardo la DB. nil = instalacion limpia (sin migraciones).
    local prevVersion = db.dbVersion

    if db.textFilters == nil then
        db.textFilters = {}
        for k, v in pairs(NS.DEFAULTS.textFilters) do
            db.textFilters[k] = v
        end
    else
        -- Si en el futuro se anaden nuevos filtros por defecto, se agregan
        -- sin tocar el estado (on/off) de los que el usuario ya tiene.
        for k, v in pairs(NS.DEFAULTS.textFilters) do
            if db.textFilters[k] == nil then
                db.textFilters[k] = v
            end
        end
    end

    if db.customFilters   == nil then db.customFilters   = {} end
    if db.alertFilters    == nil then db.alertFilters    = {} end

    -- Filtros por categoria: rellenar los que falten sin pisar la eleccion previa.
    if db.extraFilters == nil then db.extraFilters = {} end
    for k, v in pairs(NS.DEFAULTS.extraFilters) do
        if db.extraFilters[k] == nil then
            db.extraFilters[k] = v
        end
    end
    if db.antiSpamEnabled == nil then db.antiSpamEnabled = NS.DEFAULTS.antiSpamEnabled end
    if db.antiSpamTime    == nil then db.antiSpamTime    = NS.DEFAULTS.antiSpamTime end
    if db.ignoreCase      == nil then db.ignoreCase      = NS.DEFAULTS.ignoreCase end
    if db.logOnlyHidden   == nil then db.logOnlyHidden   = NS.DEFAULTS.logOnlyHidden end
    if db.channelName     == nil then db.channelName     = NS.DEFAULTS.channelName end

    if db.minimap == nil then db.minimap = {} end
    if db.minimap.angle == nil then db.minimap.angle = NS.DEFAULTS.minimap.angle end
    if db.minimap.hide  == nil then db.minimap.hide  = NS.DEFAULTS.minimap.hide end

    -- Canales del anti-flood: rellenar los que falten sin pisar la eleccion del usuario.
    if db.antiSpamChannels == nil then db.antiSpamChannels = {} end
    for k, v in pairs(NS.DEFAULTS.antiSpamChannels) do
        if db.antiSpamChannels[k] == nil then
            db.antiSpamChannels[k] = v
        end
    end

    -- Migraciones: SOLO para bases de datos ya existentes de versiones anteriores.
    -- En una instalacion limpia (prevVersion == nil) los defaults ya son correctos.
    if prevVersion then
        -- v2: el default antiguo (60) era muy largo -> se bajo a 5.
        if prevVersion < 2 and db.antiSpamTime == 60 then
            db.antiSpamTime = 5
        end
        -- v3: anti-flood solo en Taberna, ventana mas amplia (5 -> 30).
        if prevVersion < 3 and db.antiSpamTime == 5 then
            db.antiSpamTime = 30
        end
        -- v4: se sube la ventana (30 -> 60) para agrupar reenvios mas espaciados.
        if prevVersion < 4 and db.antiSpamTime == 30 then
            db.antiSpamTime = 60
        end
    end

    db.dbVersion = NS.DB_VERSION
end

-- Restaura por completo la configuracion por defecto.
function NS.ResetDB()
    NaerChatDB = {}
    NS.InitDB()
end
